/**
 * 
 */
package common;

import java.math.BigDecimal;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;

/**
 * @author 明兴网络
 * 
 */
public class CommonMethod {
	// 常量
	/**
	 * 道路
	 */
	public final static Integer RUSHHOUR_BELONG_ROAD = 1;
	/**
	 * 路段
	 */
	public final static Integer RUSHHOUR_BELONG_ROADSECTION = 2;
	/**
	 * 路口
	 */
	public final static Integer RUSHHOUR_BELONG_CROSSING = 3;

	/**
	 * 获取当前时间
	 * 
	 * @return yyyy-MM-dd HH:mm:ss
	 */
	public static String getDate() {
		String returnStr = null;
		returnStr = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
				.format(new Date());
		return returnStr;
	}

	/**
	 * 获取当前时间
	 * 
	 * @return yyyy-MM-dd HH:mm:ss
	 */
	public static Date getTime() {
		String returnStr = null;
		returnStr = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
				.format(new Date());
		// System.out.println(returnStr);
		try {
			return new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse(returnStr);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}
	}

	/**
	 * 获取当前时间
	 * 
	 * @return yyyy-MM-dd
	 */
	public static String getCurrentDate() {
		String returnStr = null;
		returnStr = new SimpleDateFormat("yyyy-MM-dd").format(new Date());
		// System.out.println(returnStr);
		try {
			return returnStr;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}
	}

	/**
	 * 获取当前时间
	 * 
	 * @return yyyy-MM-dd HH:mm:ss
	 */
	public final static java.sql.Timestamp getTimeStamp() {
		java.sql.Timestamp dateTime = new java.sql.Timestamp(getTime()
				.getTime());// Timestamp类型,timeDate.getTime()返回一个long型
		return dateTime;
	}

	/**
	 * 将时间转换为字段
	 * 
	 * @param s
	 * @return
	 * @throws ParseException
	 */
	public static Date stringToDate(String s) throws ParseException {
		if (s == null)
			s = "";
		return !s.trim().equals("") ? new SimpleDateFormat("yyyy-MM-dd")
				.parse(s) : null;
	}

	/**
	 * method 将字符串类型的日期转换为一个timestamp（时间戳记java.sql.Timestamp）
	 * 
	 * @param dateString
	 *            需要转换为timestamp的字符串
	 * @return dataTime timestamp
	 */
	public final static java.sql.Timestamp string2Time(String dateString) {
		try {
			DateFormat dateFormat;
			dateFormat = new SimpleDateFormat("yyyy-MM-dd kk:mm:ss.SSS",
					Locale.ENGLISH);// 设定格式
			// dateFormat = new SimpleDateFormat("yyyy-MM-dd kk:mm:ss",
			// Locale.ENGLISH);
			dateFormat.setLenient(false);
			java.util.Date timeDate = dateFormat.parse(dateString);// util类型
			java.sql.Timestamp dateTime = new java.sql.Timestamp(
					timeDate.getTime());// Timestamp类型,timeDate.getTime()返回一个long型
			return dateTime;
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			return null;
		}
	}

	/**
	 * method 将字符串类型的日期转换为一个Date（java.sql.Date）
	 * 
	 * @param dateString
	 *            需要转换为Date的字符串
	 * @return dataTime Date
	 */
	public final static java.sql.Date string2Date(String dateString) {
		try {
			DateFormat dateFormat;
			dateFormat = new SimpleDateFormat("yyyy-MM-dd", Locale.ENGLISH);
			dateFormat.setLenient(false);
			java.util.Date timeDate = dateFormat.parse(dateString);// util类型
			java.sql.Date dateTime = new java.sql.Date(timeDate.getTime());// sql类型
			return dateTime;
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			return null;
		}
	}

	public final static java.sql.Date stringToDate(String dateString,
			String formart) {
		try {
			DateFormat dateFormat;
			dateFormat = new SimpleDateFormat(formart, Locale.ENGLISH);
			dateFormat.setLenient(false);
			java.util.Date timeDate = dateFormat.parse(dateString);// util类型
			java.sql.Date dateTime = new java.sql.Date(timeDate.getTime());// sql类型
			return dateTime;
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			return null;
		}
	}

	public static String dateToString(Date d) {
		String result = null;
		if (d != null) {
			SimpleDateFormat bartDateFormat = new SimpleDateFormat("yyyy-MM-dd");
			result = bartDateFormat.format(d);
		}
		return result;
	}

	public static String dateToString(Date d, String format) {
		String result = null;
		if (d != null) {
			SimpleDateFormat bartDateFormat = new SimpleDateFormat(format);
			result = bartDateFormat.format(d);
		}
		return result;
	}

	/**
	 * 
	 * @param input
	 * @return 空返回true，非空返回false
	 */
	public static boolean isNull(String input) {
		if (input != null && !input.equals("")) {
			return false;
		} else {
			return true;
		}
	}

	/**
	 * 时间增加n天
	 * 
	 * @param s
	 *            初始时间
	 * @param n
	 *            增加天数
	 * @return
	 */
	public static String addDay(String s, int n) {
		try {
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");

			Calendar cd = Calendar.getInstance();
			cd.setTime(sdf.parse(s));
			cd.add(Calendar.DATE, n);// 增加一天
			// cd.add(Calendar.MONTH, n);//增加一个月
			return sdf.format(cd.getTime());
		} catch (Exception e) {
			return null;
		}

	}

	public static List getSelectList(String listName) {
		HashMap<String, List> hs = new HashMap<String, List>();
		if (hs.get(listName) == null) {
			setSelectList(listName);
		}
		return hs.get(listName);
	}

	private static void setSelectList(String listName) {

	}

	/**
	 * 
	 * @param hj
	 *            被加数字，会被修改
	 * @param obj
	 *            加数 不会被修改
	 * @return 和
	 */
	public static BigDecimal getSumByDecimal(BigDecimal hj, Object obj) {
		if (obj != null && !obj.equals("")) {
			hj = hj.add(new BigDecimal(obj.toString()));
		}
		return hj;
	}

	/**
	 * 验证是否整数
	 * 
	 * @param str
	 * @return
	 */
	public static boolean isNumber(String str) {
		if (java.lang.Character.isDigit(str.charAt(0))) {
			return true;
		}
		return false;
	}

	public static List copyObject(List target, List source) {
		for (int i = 0; i < source.size(); i++) {
			target.add(source.get(i));
		}
		return target;
	}

	/**
	 * 根据用户区号区分用户等级是县、市、省
	 * 
	 * @param areacode
	 * @return
	 */
	public static Integer getUserLevelByAreaCode(String areacode) {
		if (areacode == null && areacode.equals("")) {
			throw new RuntimeException("请确认你的是否有权限执行当前操作");
		}
		if (areacode.equals("510000")) {
			return 1;
		} else if (areacode.substring(4, 6).equals("01")) {
			return 2;
		} else {
			return 3;
		}
	}

	public static String getRealCodeFromHtml(String htmlcode) {
		String s = htmlcode;
		String[] ss = s.split("&#");
		String rts = "";
		for (int i = 0; i < ss.length; i++) {
			rts += ss[i];
		}
		ss = rts.split(";");
		rts = "";
		for (int i = 0; i < ss.length; i++) {
			try {
				int ri = Integer.parseInt(ss[i]);
				char x = (char) ri;
				rts += x;
			} catch (Exception e) {
				rts += ss[i];
			}
		}
		return rts;
	}

	public static void main(String[] args) {
		System.out.println(CommonMethod
				.getRealCodeFromHtml("fengkuang&#161zai&#178"));
	}
}
