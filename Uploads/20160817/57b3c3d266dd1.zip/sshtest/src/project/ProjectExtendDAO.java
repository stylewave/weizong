                            package dao.project;

import org.springframework.stereotype.Repository;
import common.dao.AbstractQueryDAO;
import dao.generated.Project;

@Repository("projectDAO")
public class ProjectExtendDAO extends AbstractQueryDAO<Project> implements IProjectDAO {
		

}