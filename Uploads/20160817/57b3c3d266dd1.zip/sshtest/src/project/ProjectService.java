package service.project;

import common.service.BaseService;
import dao.generated.Project;

public interface ProjectService extends BaseService<Project> {

}