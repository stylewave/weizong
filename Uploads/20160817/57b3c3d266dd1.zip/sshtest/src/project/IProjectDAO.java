package dao.project;

import common.dao.IBaseDAO;
import dao.generated.Project;

public interface IProjectDAO extends IBaseDAO<Project> {

}