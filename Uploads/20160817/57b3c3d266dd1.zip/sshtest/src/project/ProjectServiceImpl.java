package service.project;

import javax.annotation.Resource;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Order;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import common.action.PaginationSupport;
import common.dao.IBaseDAO;
import common.service.AbstractService;
import dao.generated.Project;
import dao.project.IProjectDAO;

@Service("projectService")
public class ProjectServiceImpl extends AbstractService<Project> implements	ProjectService {
	
	@Autowired
	private IProjectDAO projectDAO;

	@Override
	@Resource(name = "projectDAO")
	protected void initBaseDAO(IBaseDAO<Project> baseDAO) {
		setBaseDAO(baseDAO);
	}

	@Override
	public PaginationSupport<Project> findPageByCriteria(
			PaginationSupport<Project> ps, Project t) {
		DetachedCriteria dc = DetachedCriteria.forClass(Project.class);
		return projectDAO.findPageByCriteria(ps, Order.asc("projectId"), dc);
	}

	@Override
	public void save(Project t) {
		projectDAO.save(t);
	}
}