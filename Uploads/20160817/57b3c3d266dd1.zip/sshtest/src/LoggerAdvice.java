package common;

import java.lang.reflect.Method;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.log4j.Logger;
import org.springframework.aop.AfterReturningAdvice;
import org.springframework.aop.MethodBeforeAdvice;

public class LoggerAdvice implements MethodBeforeAdvice, AfterReturningAdvice {

	public void before(Method method, Object[] args, Object target)
			throws Throwable {
		// web.xml(spring + log4j)
		Logger logger = Logger.getLogger(target.getClass());
		logger.debug("+Class : " + target.getClass().getName());
		logger.debug("+-------Method : " + method.getName());
		for (int i = 0; i < args.length; i++) {
			logger.debug(" +-arg" + i + " : " + args[i].toString());
		}
	}

	public void afterReturning(Object retuVal, Method method, Object[] args,
			Object target) throws Throwable {
		// common-logging + log4j
		Log log = LogFactory.getLog(target.getClass());
		if (retuVal != null) {
			log.debug("+-------Return : " + retuVal.toString());
		}
	}
}
