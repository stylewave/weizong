package common;

import java.util.Map;
import com.opensymphony.xwork2.ActionInvocation;
import com.opensymphony.xwork2.interceptor.AbstractInterceptor;

public class CheckLoginInterceptor extends AbstractInterceptor {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Override
	public String intercept(ActionInvocation actionInvocation) throws Exception {
		// 检查Session中是否存在user
		Map session = actionInvocation.getInvocationContext().getSession();
		Integer userId = (Integer) session.get("userId");
		if (userId != null) {
			// 存在的情况下进行后续操作。
			// System.out.println(userId);
			return actionInvocation.invoke();
		} else {
			// 否则终止后续操作，返回LOGIN
			String msg = "重新登录";
			throw new Exception(msg);
			// return "login";
		}
	}

}
