package action.timer;

import dao.generated.TabInformationSource;
import java.io.IOException;
import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Property;
import service.information.InformationService;
import service.managers.ManagersService;
import service.sitetimewords.SiteTimeWordsService;
import service.tabInformationSource.TabInformationSourceService;
import service.textinfo.TextInfoService;

public class TisTask extends Thread
{
	private TabInformationSourceService tabInformationSourceService;
	private InformationService informationService;
	private ManagersService managersService;
	private TextInfoService textinfoService;
	private SiteTimeWordsService siteTimeWordsService;
	public boolean TaskStatues=true;
	private Logger logger = Logger.getLogger("yuqinglogger");

	public void run()
	{
    	for (;;)
	    { 
    		try
    		{
		        this.logger.debug("主线开始");
		        List<TabInformationSource> tabInformationSources = this.tabInformationSourceService.findAll();
		        if ((tabInformationSources != null) && (tabInformationSources.size() > 0)) 
		        {
		        	for (int i = 0; i < tabInformationSources.size(); i++)
		        	{
		        		TabInformationSource tabInformationSource = (TabInformationSource)tabInformationSources.get(i);
		        		tabInformationSource.setState(Integer.valueOf(2));//状态值
		        		this.tabInformationSourceService.attachDirty(tabInformationSource);
		        	}
		        }
		        DetachedCriteria dc = DetachedCriteria.forClass(TabInformationSource.class);
		        dc.add(Property.forName("state").eq(Integer.valueOf(2)));
		        dc.addOrder(Order.desc("creationTime"));
		        List<TabInformationSource> list = this.tabInformationSourceService.findByCriteria(dc);
		        if ((list != null) && (list.size() > 0)) 
		        {
		        	for (int i = 0; i < list.size(); i++)
		        	{
		        		TabInformationSource tabInformationSource = (TabInformationSource)list.get(i);
		        		if ((tabInformationSource.getLimitSearch() == null) || (tabInformationSource.getLimitSearch().intValue() == 0))
		        		{
		        			this.logger.debug("源搜索开始");//news.so.com/
		        			//tabInformationSource.setState(Integer.valueOf(1));
		        			//this.tabInformationSourceService.attachDirty(tabInformationSource);
		        			if (tabInformationSource.getUrl().contains("news.baidu.com")) {
		        				new Baidu(this.informationService, this.textinfoService).begin();              
		        			} else if (tabInformationSource.getUrl().contains("weibo.com")) {
		        				new SinaWeibo(this.informationService, this.textinfoService).begin();
		        			} else if (tabInformationSource.getUrl().contains("blog.sina.com")) {
		        				new SinaBlogSearch( this.informationService, this.textinfoService).begin();
		        			}else if (tabInformationSource.getUrl().contains("search.sina.com")) {
		        				new SinaNewsSearch(this.informationService, this.textinfoService).begin();
		        			}else if (tabInformationSource.getUrl().contains("news.so.com")) {
	        				new Qihu360(this.informationService, this.textinfoService).begin();
		        			}
		        		}
		        	}
		        }
		        sleep(60*1000);
		        if ((list != null) && (list.size() > 0))
		        {
		        	this.logger.debug("开始循环抓取源链接");
		        	for (int i = 0; i < list.size(); i++)
		        	{
			            TabInformationSource tabInformationSource = (TabInformationSource)list.get(i);
			            if(tabInformationSource.getUrl().contains("news.baidu.com")||tabInformationSource.getUrl().contains("weibo.com")||
			            		tabInformationSource.getUrl().contains("blog.sina.com")||tabInformationSource.getUrl().contains("search.sina.com")
			            		||tabInformationSource.getUrl().contains("news.so.com"))
			            {
			            	continue;
			            }
			            IsTask isTask = new IsTask();
			            isTask.setInformationService(this.informationService);
			            isTask.setTextInfoService(textinfoService);
			            isTask.setTabInformationSource(tabInformationSource);
			            
			        	System.out.println("总线程数：" + ThreadPool.threadPoolExecutor.getCorePoolSize());
			            System.out.println("当前线程数：" + ThreadPool.threadPoolExecutor.getPoolSize());
			            
			            while(ThreadPool.threadPoolExecutor.getActiveCount()>=ThreadPool.threadPoolExecutor.getCorePoolSize());
		            	try
			            {
		            		ThreadPool.threadPoolExecutor.execute(isTask);//装入线程池
			            }
			            catch (Exception e)
			            {
			                this.logger.debug("抓取信息原网页时出现错误，进入睡眠状态");
			            }
		            	System.out.println("总线程数：" + ThreadPool.threadPoolExecutor.getPoolSize());
		            }
		        }
		        this.logger.debug("主线程配置完成");
		        int timeoutcnt=0;
		        while (ThreadPool.threadPoolExecutor.getActiveCount() > 0)//等待所有线程跑完
		        {
		        	printThreadPool();
		        	long cnt= Long.valueOf(ThreadPool.threadPoolExecutor.getTaskCount())-Long.valueOf(ThreadPool.threadPoolExecutor.getCompletedTaskCount());
		        	
		        	sleep(60000);//每一分钟输出一次线程状态
		        	if(ThreadPool.threadPoolExecutor.getActiveCount()<=2 && cnt==2)
		        	{
		        		if(Boolean.valueOf(ThreadPool.threadPoolExecutor.isTerminated()))
			        	{
			        		timeoutcnt++;
			        		if(timeoutcnt>20)
			        		{
			        			break;
			        		}
			        	}
		        	}
		        }
		        this.logger.debug("主线程已完成");
		        try
		        {
		            Runtime.getRuntime().exec("taskkill /f /FI \"IMAGENAME eq chromedriver.exe\"");
		            Runtime.getRuntime().exec("taskkill /f /FI \"IMAGENAME eq chrome.exe\"");
		        }
		        catch (IOException e)
		        {
		            e.printStackTrace();
		        }
		        for (int i = 0; i < list.size(); i++)
		        {
		            TabInformationSource tabInformationSource = (TabInformationSource)list.get(i);
		            tabInformationSource.setState(Integer.valueOf(2));
		            this.tabInformationSourceService.attachDirty(tabInformationSource);
		        }
		        this.logger.debug("主线程睡眠 3分钟");
		        TaskStatues=false;
		        for (int k = 3; k > 0; k--)
		        {
		            printThreadPool();
		            this.logger.info("距离启动还有:" + k + "分钟");
		            sleep(60000);
		        }
	    	}
	    	catch (Exception e)
	    	{
				e.printStackTrace();
				this.logger.debug("主线线程异常");
				TaskStatues=false;
			}  
	    }
	}
  
  private void printThreadPool()
  {
      System.out.println(
      String.format("[monitor] [%d/%d] Active: %d, Completed: %d, Task: %d, isShutdown: %s, isTerminated: %s", new Object[] {
      Integer.valueOf(ThreadPool.threadPoolExecutor.getPoolSize()), 
      Integer.valueOf(ThreadPool.threadPoolExecutor.getCorePoolSize()), 
      Integer.valueOf(ThreadPool.threadPoolExecutor.getActiveCount()), 
      Long.valueOf(ThreadPool.threadPoolExecutor.getCompletedTaskCount()), 
      Long.valueOf(ThreadPool.threadPoolExecutor.getTaskCount()), 
      Boolean.valueOf(ThreadPool.threadPoolExecutor.isShutdown()), 
      Boolean.valueOf(ThreadPool.threadPoolExecutor.isTerminated()) }));
  }
  
  public TabInformationSourceService getTabInformationSourceService()
  {
      return this.tabInformationSourceService;
  }
  
  public void setTabInformationSourceService(TabInformationSourceService tabInformationSourceService)
  {
      this.tabInformationSourceService = tabInformationSourceService;
  }
  
  public InformationService getInformationService()
  {
      return this.informationService;
  }
  
  public void setInformationService(InformationService informationService)
  {
      this.informationService = informationService;
  }

  public ManagersService getManagersService()
  {
      return this.managersService;
  }
  
  public void setManagersService(ManagersService managersService)
  {
      this.managersService = managersService;
  }
  
  public TextInfoService getTextInfoService()
  {
      return this.textinfoService;
  }
  
  public void setTextInfoService(TextInfoService textinfoService)
  {
      this.textinfoService = textinfoService;
  }
  
  public SiteTimeWordsService setSiteTimeWordsService()
  {
      return this.siteTimeWordsService;
  }
  
  public void setSiteTimeWordsService(SiteTimeWordsService siteTimeWordsService)
  {
      this.siteTimeWordsService = siteTimeWordsService;
  }
  public static void main(String[] args)
  {
	  TabInformationSourceService tabInformationSourceService = null;
	  DetachedCriteria dc = DetachedCriteria.forClass(TabInformationSourceService.class);
	  dc.addOrder(Order.desc("id"));
	  @SuppressWarnings("null")
	  List<TabInformationSource> list = tabInformationSourceService.findByCriteria(dc);
	  System.out.println(((TabInformationSource)list.get(0)).getSiteName());
  }
}
