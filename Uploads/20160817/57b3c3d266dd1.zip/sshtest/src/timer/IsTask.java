/**
 * 
 */
package action.timer;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import common.Configuration;
import common.search.getPage.GetPage;
import common.search.getPage.ReadPageData;

import dao.generated.Project;
import dao.generated.TabInformationSource;
import service.information.InformationService;
import service.textinfo.TextInfoService;

/**
 * @author 黄聪
 * 
 */
public class IsTask extends Thread {
	private InformationService informationService;
	private TabInformationSource tabInformationSource;
	private TextInfoService textinfoService;
	private boolean isSleep = true;

	private Logger logger = Logger.getLogger("yuqinglogger");

	public void run() {
		try {
			String keyword = tabInformationSource.getKeyword();
			List<String> urlList = informationService.saveAndGetLinks(tabInformationSource);
			runLinkTask(2, urlList,tabInformationSource.getSiteName(), keyword);
			logger.info("此线程爬虫结束:"+tabInformationSource.getUrl());

		} catch (Exception e) {
			e.printStackTrace();
			logger.info("此线程爬虫结束[异常]:;"+e);
		}
	}

	/**
	 * 爬取每一次
	 * 
	 * @param level
	 *            当前层数(从2开始)
	 * @param urlList
	 *            从上一层获取的总链接
	 * @param keyword
	 * @param url
	 *            上一层网站的地址
	 * @throws InterruptedException
	 */

	private List<String> runLinkTask(int level, List<String> urlList, String siteName, String keyword)  {
		// boolean toSleep = true;
		List<String> urls1 = new ArrayList<String>();
		List<String> links = new ArrayList<String>();
		// List<String> urls2 =null;
		if(urlList !=null)
		{
			for (int i = 0; i < urlList.size(); i++) {//urlList.size()
				String urlString = urlList.get(i);
				if (urlString != null && !urlString.trim().equals("")) 
				{
					if (links != null) {
						links.clear();
					}
					try{
						links = informationService.saveAndGetLinksByProject(urlString,siteName, keyword, this.textinfoService);
						if( (i%5) == 0 || (i==urlList.size()-1))
						{
						//logger.debug("i=" + i +"[共 "+urlList.size()+"]"+"第" + level  + "层(" + urlString + "),此层连接数:"
						//		+ (links == null ? 0 : links.size()));
						}
						if (links != null && links.size() != 0) {
							urls1.addAll(links);
						}
					}catch (Exception e) {
						// TODO: handle exception
						e.printStackTrace();
					}
				}

			}
		}
		return urls1;
	}

	/**
	 * 根据上层连接与该层连接获到直实连接地址
	 * 
	 * @param url
	 *            上层url
	 * @param urlString
	 *            本层url
	 * @return
	 */
	public static String generateUrl(String url, String urlString) {
		try {
			// logger.debug("开始：自动为turl("+url+")和curl("+urlString+")生成url连接");
			ReadPageData readPageData = new ReadPageData();
			String generateUrl = "";
			String tempturl = "";// 上层
			String tempcurl = "";// 本层
			String website = "";
			if (url.indexOf("/") == -1) {
				website = url;
			}
			if (url.toLowerCase().indexOf("http") == -1) {// 上一层无http头增加头
				url = "http://" + url;
			}
			if (urlString.toLowerCase().indexOf("http") == -1) {// 本层无http头的情况
				if (urlString.startsWith("/")) {// 本层以'/'开始的情况
					if (!website.equals("")) {
						generateUrl = website + urlString;
					} else {
						website = readPageData.getSubStr(url.toLowerCase()
								+ "/", "http://", "/");
						generateUrl = website + urlString;
					}

				} else if (urlString.startsWith("./")) {
					tempturl = url.substring(0, url.lastIndexOf("/"));
					tempcurl = urlString.substring(2);
					generateUrl = generateUrl(tempturl, tempcurl);
				} else if (urlString.startsWith("../")) {
					if (!website.equals("")) {
						tempcurl = urlString.substring(3);
						generateUrl = generateUrl(url, tempcurl);
					} else {
						website = readPageData.getSubStr(url.toLowerCase()
								+ "/", "http://", "/");
						tempcurl = urlString.substring(3);
						generateUrl = generateUrl(website, tempcurl);
					}
				} else {
					website = readPageData.getSubStr(url.toLowerCase() + "/",
							"http://", "/");
					if (urlString.indexOf(website) != -1) {// 有上层站点名直接增加http头
						generateUrl = "http://" + urlString;
					} else {// 上层与下层直接组合
						if (url.endsWith("/")) {// 上层以'/'结尾直接相连
							generateUrl = url + urlString;
						} else if (urlString.indexOf("?") != -1) {
							tempturl = url.substring(0, url.lastIndexOf("?"));
							tempcurl = urlString.substring(urlString
									.lastIndexOf("?"));
							generateUrl = tempturl + tempcurl;
						} else if (url.indexOf("?") != -1) {
							tempturl = url.substring(0, url.lastIndexOf("/"));
							generateUrl = tempturl + "/" + urlString;
						} else {
							generateUrl = url + "/" + urlString;
						}
					}
				}
			} else {// 有的话直接返回本连接
				generateUrl = urlString;
			}
			if(!generateUrl.contains("http://")){
				generateUrl  = "http://" + generateUrl;
			}
			// logger.debug("结束：自动为turl(" + url + ")和curl(" + urlString
			// + ")生成url连接(" + generateUrl + ")");
			return generateUrl;
		} catch (Exception e) {
			// logger.debug("出错：自动为turl(" + url + ")和curl(" + urlString
			// + ")生成url连接出错:" + e.getMessage());
			return "";
		}
	}

	public InformationService getInformationService() {
		return informationService;
	}

	public void setInformationService(InformationService informationService) {
		this.informationService = informationService;
	}

	public TabInformationSource getTabInformationSource() {
		return tabInformationSource;
	}

	public void setTabInformationSource(
			TabInformationSource tabInformationSource) {
		this.tabInformationSource = tabInformationSource;
	}
	
	  public TextInfoService getTextInfoService()
	  {
	      return this.textinfoService;
	  }
	  
	  public void setTextInfoService(TextInfoService textinfoService)
	  {
	      this.textinfoService = textinfoService;
	  }

	public static void main(String[] args) throws InterruptedException {

	}
}
