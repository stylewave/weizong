package action.timer;

import common.ThreadPool;
import common.search.getPage.ReadPageData;
import java.io.PrintStream;
import java.io.UnsupportedEncodingException;
import java.text.Format;
import java.text.SimpleDateFormat;
import java.util.Date;
import org.apache.log4j.Logger;
import service.information.InformationService;
import service.textinfo.TextInfoService;

public class SinaWeibo
{
  private Logger log = Logger.getLogger("yuqinglogger");
  private static int pageDely = 6000;
  private InformationService informationService;
  private TextInfoService textInfoService;
  
  public SinaWeibo(InformationService informationService, TextInfoService textinfoService) {
	  this.informationService = informationService;
	  this.textInfoService = textinfoService;
  }
  
  public SinaWeibo(InformationService informationService) 
  {
    this.informationService = informationService;
  }
  
  public void begin()
  {
    try
    {

      ThreadPool.runMetaThread(new SinaWeiboThread( this.informationService, this.textInfoService));
	  try{
	    	Thread.sleep(pageDely);
	    }catch (InterruptedException e) {
			// TODO: handle exception
	    	e.printStackTrace();
		}
	  return;
    }
    catch (Exception e)
    {
      e.printStackTrace();
      this.log.info("元搜索出错:" + e.getMessage());
    }
  }
  public static void main(String[] args)
    throws UnsupportedEncodingException
  {}
}
