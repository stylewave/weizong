 /**
 * 
 */
package action.timer;

import java.util.List;
import org.apache.log4j.Logger;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Order;
import service.managers.ManagersService;
import service.project.ProjectService;
import service.sitetimewords.SiteTimeWordsService;
import dao.generated.Managers;
import dao.generated.Project;
import dao.generated.SiteTimeWords;

/**
 * @author 黄聪
 * 
 */
public class AutoGetProject extends Thread {
	private ProjectService projectService;
	private ManagersService managersService;
	private SiteTimeWordsService siteTimeWordsService;
	private Logger logger = Logger.getLogger("yuqinglogger");

	public void run() {
		while (true) {
			try {

			//	logger.info("更新专题和过滤条件");
				DetachedCriteria dc = DetachedCriteria.forClass(Project.class);
				dc.addOrder(Order.desc("id"));
				List<Project> list = projectService.findByCriteria(dc);
				ThreadPool.projects.clear();
				ThreadPool.projects.addAll(list);
				
				DetachedCriteria dcs = DetachedCriteria.forClass(Managers.class);
				dcs.addOrder(Order.desc("id"));
				List<Managers> lists = managersService.findByCriteria(dcs);
				ThreadPool.managers.clear();
				ThreadPool.managers.addAll(lists);
				
				DetachedCriteria dct = DetachedCriteria.forClass(SiteTimeWords.class);
				dct.addOrder(Order.desc("id"));
				List<SiteTimeWords> listt = siteTimeWordsService.findByCriteria(dct);
				ThreadPool.siteTimeWords.clear();
				ThreadPool.siteTimeWords.addAll(listt);
				
				sleep(300 * 60 * 1000);//10分钟刷新一次
			} catch (Exception e) {
				e.printStackTrace();
				try {
					sleep(300 * 60 * 1000);
				} catch (InterruptedException e1) {
					e1.printStackTrace();
				}
				logger.error("设置专题队列出错：" + e.getMessage());

			}
		}
	}

	public ProjectService getProjectService() {
		return projectService;
	}

	public void setProjectService(ProjectService projectService) {
		this.projectService = projectService;
	}
	
	  public ManagersService getManagersService()
	  {
	      return this.managersService;
	  }
	  
	  public void setManagersService(ManagersService managersService)
	  {
	      this.managersService = managersService;
	  }
	  public SiteTimeWordsService setSiteTimeWordsService()
	  {
	      return this.siteTimeWordsService;
	  }
	  
	  public void setSiteTimeWordsService(SiteTimeWordsService siteTimeWordsService)
	  {
	      this.siteTimeWordsService = siteTimeWordsService;
	  }
}
