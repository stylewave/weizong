/**
 * 
 */
package action.timer;

import java.util.Queue;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

import dao.generated.Managers;
import dao.generated.Project;
import dao.generated.SiteTimeWords;
import dao.generated.TabInformationSource;
import dao.generated.TextInfo;

/**
 * @author 黄聪   
 * 
 */
public class ThreadPool {
	public static ThreadPoolExecutor threadPoolExecutor = new ThreadPoolExecutor(
			5, 200, 10, TimeUnit.SECONDS, new ArrayBlockingQueue(200), new ThreadPoolExecutor.AbortPolicy());
			
	private static int maxlevel = 200;
	public static Queue<TabInformationSource> tabInformationSource = new ConcurrentLinkedQueue<TabInformationSource>();
	public static Queue<Project> projects = new ConcurrentLinkedQueue<Project>();
	public static Queue<TextInfo> textInfo = new ConcurrentLinkedQueue<TextInfo>();
	public static Queue<Managers> managers = new ConcurrentLinkedQueue<Managers>();
	public static Queue<SiteTimeWords> siteTimeWords = new ConcurrentLinkedQueue<SiteTimeWords>();
	public static int getMaxlevel() {
		return maxlevel;
	}
  
	public static void setMaxlevel(int maxlevel) {
		ThreadPool.maxlevel = maxlevel;
	}

}
