/**
 * 
 */
package action.timer;

import org.apache.log4j.Logger;
import org.apache.xpath.operations.String;

import service.information.InformationService;
import service.textinfo.TextInfoService;

import common.Configuration;

public class AutoReset extends Thread {  
	private InformationService informationService;
	private TextInfoService textinfoService;
	private Logger logger = Logger.getLogger("yuqinglogger");
	private java.lang.String repeatTime = "1200000";
	public void run() {
		while (true) {
			try {
				//logger.info("重置状态");
				int rt = 120000;
				if (repeatTime != null && !repeatTime.trim().equals("")) {
					rt = Integer.parseInt(repeatTime);
				}
				informationService.deleteRepeat();
				sleep(rt);
			} catch (Exception e) {
				e.printStackTrace();
				logger.error("重置状态出错，错误原因：" + e.getMessage());
			}
		}
	}

	public InformationService getInformationService() {
		return informationService;
	}

	public void setInformationService(InformationService informationService) {
		this.informationService = informationService;
	}
	
	  public TextInfoService getTextInfoService()
	  {
	      return this.textinfoService;
	  }
	  
	  public void setTextInfoService(TextInfoService textinfoService)
	  {
	      this.textinfoService = textinfoService;
	  }

}
