package action.timer;

import java.sql.Timestamp;
import java.util.Calendar;
import java.util.Date;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class GetTimeWords {
	static String TimeWords[] = { "time-source","pubtime_baidu","left-time", "pub_time", "left-time", 
		"timeSummary", "p_publishtime", "p_time", "pubTime", "class=\"date\"", "class=\"pubdate\"", 
		 "article-time", "Submit_time", "class=\"art_time\"", "class=\"info\"", "article-infos",
		 "article_info", "发布时间：", "发布时间:", "时间：", "时间:","class=\"time\"","artInfo", "日期：", "日期"};
	
	  public static String matchDateString(String dateStr)
	  {
		String getT1 = "(201)\\d{1}(\\-|年|\\.)\\d{1,2}(\\-|月|\\.)\\d{1,2}([日|号])?(\\s)*\\d{1,2}(\\时)?(\\:)?\\d{1,2}(\\分)?((\\:)?\\d{1,2}(秒)?)?";
		String getT2 = "(\\d{1,4}[-|年|\\.]\\d{1,2}[-|月|\\.]\\d{1,2}([日|号])?(\\s)*(\\d{1,2}([点|时])?((:)?\\d{1,2}(分)?((:)?\\d{1,2}(秒)?)?)?)?(\\s)*(PM|AM)?)";
		try{
	      Pattern p = Pattern.compile(getT1);
	      Matcher matcher = p.matcher(dateStr);
	      if (matcher.find()){
	          return matcher.group();
	      }
	      else{
	    	  p = Pattern.compile(getT2);
	    	  matcher = p.matcher(dateStr);
		      if(matcher.find()){
		    	  return matcher.group();
		      }
	      }
	    }
	    catch (Exception e){
	      return "";
	    }
		return "";
	  }
	  
	  public static Date getNextDay(Date date) {
			Calendar calendar = Calendar.getInstance();
			calendar.setTime(date);
			calendar.add(Calendar.DAY_OF_MONTH, -10);
			date = calendar.getTime();
			return date;
		}
	  
	  public static Timestamp GetPublicTime(String tempget)
	  {
	    
		  Timestamp ts = new Timestamp(System.currentTimeMillis());
		  String TimeStr = tempget.trim();
		  String Timestr2 = "";
		  if ((TimeStr != null) && (!"".equals(TimeStr))) {
			  for (int i = 0; i < TimeStr.length(); i++) {
				  if ((TimeStr.charAt(i) >= '0') && (TimeStr.charAt(i) <= '9')) {
					  Timestr2 = Timestr2 + TimeStr.charAt(i);
				  }
			  }
		  }
		//  System.out.println("获取到的时间值:" + Timestr2);
		  //System.out.println(Timestr2.length());
		  if (Timestr2.length() < 8) {
			  Timestr2 = null;
			  return null;
		  }
		  if (Timestr2.length() == 8) {
	      Timestr2 = Timestr2 + "120809";
		  } 
		  if (Timestr2.length() == 12) {
			  Timestr2 = Timestr2 + "00";
		  } 
		//  System.out.println(Timestr2.length());
		  if (Timestr2.length() == 14)
		  {
			  String yeartime = Timestr2.substring(0, 4).trim();
			  String mouthtime = Timestr2.substring(4, 6).trim();
			  String datetime = Timestr2.substring(6, 8).trim();
			  String hourtime = Timestr2.substring(8, 10).trim();
			  String mimutetime = Timestr2.substring(10, 12).trim();
			  String secondtime = Timestr2.substring(12, 14).trim();
			  Timestr2 = yeartime + "-" + mouthtime + "-" + datetime + " " + hourtime + ":" + mimutetime + ":" + secondtime;
			  System.out.println("获取到的时间:" + Timestr2);
			  if ((GetTimeWords.matchDateString(Timestr2) == null) || (GetTimeWords.matchDateString(Timestr2).length() < 8)) {
				  return null;
			  }
			  try
			  {
				  ts = Timestamp.valueOf(Timestr2);
			  }
			  catch (Exception e)
			  {
				  e.printStackTrace();
			  }
		  }	
		  return ts;
	  }
	
	  public static String GetTimeInString(String InString)
	  {
		  String TimeInString = "";
	  for(int i=0; i<TimeWords.length; i++)
	  {
		  if(InString.contains(TimeWords[i]))
		  {
			  System.out.println(InString.substring(InString.indexOf(TimeWords[i]), InString.indexOf(TimeWords[i])+200));
			  try{
				  TimeInString = InString.substring(InString.indexOf(TimeWords[i]), InString.indexOf(TimeWords[i])+500);
			  }catch(Exception e){
				  TimeInString = InString.substring(InString.indexOf(TimeWords[i]), InString.indexOf(TimeWords[i])+200);
			  }
			  if( matchDateString(TimeInString) ==null ||  matchDateString(TimeInString) =="")
			  {
				  continue;
			  }
			  else
			  {
				  break;
			  }	
		  }
		
	  }
	  return TimeInString;
	}
}
