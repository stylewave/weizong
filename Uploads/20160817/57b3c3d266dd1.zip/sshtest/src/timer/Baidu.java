package action.timer;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.text.Format;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Queue;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.TimeUnit;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.log4j.Logger;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Element;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import common.search.getPage.GetPage;
import common.search.getPage.ReadPageData;
import common.search.getPage.WeiboMessage;
import dao.generated.Managers;
import dao.generated.Project;
import service.information.InformationService;
import service.textinfo.TextInfoService;

/**
 * @author 雷德诚
 * @ 元搜索专用百度新闻
 */
public class Baidu {
	private Logger log = Logger.getLogger("yuqinglogger");
	private String queryString;
	private static int pageNumLimit = 2;//10
	private static int pageDely = 10000;//等待时间
	private InformationService informationService;
	private TextInfoService textInfoService;
	public Baidu() {

	}

	public Baidu(InformationService informationService, TextInfoService textInfoService) {
		this.informationService = informationService;
		this.textInfoService = textInfoService;
	}
	public Baidu( InformationService informationService) {
		this.informationService = informationService;
	}

	public void begin(){
		try 
		{
			Queue<Managers> queues = new ConcurrentLinkedQueue<Managers>();
			queues.addAll(ThreadPool.managers);
			while (!queues.isEmpty())
			{
				Managers manager = (Managers)queues.poll();
				if(manager.getProjectName()!=null)
				{
					try  
					{
						String queryString = URLEncoder.encode(manager.getProjectName(), "utf-8");
						queryString = queryString.replace("%7C", "+%7C+");
						for (int i = 0; i < 5; i++) 
						{
							String url = "http://news.baidu.com/ns?word=" + queryString	+ "&pn=" + i * 10;
							common.ThreadPool.runMetaThread(new BaiduThread(url,this.informationService, this.textInfoService, 1));
							try{
								Thread.sleep(pageDely);
							}catch (Exception e) {
								// TODO: handle exception
								e.printStackTrace();
							}
						}
					}
					catch (Exception e)
					{
						e.printStackTrace();
					}
				}
			}
			
			Queue<Project> queue = new ConcurrentLinkedQueue<Project>();
			queue.addAll(ThreadPool.projects);
			while (!queue.isEmpty()) 
			{
				Project project = queue.poll();
				log.info("开始搜索关键词:"+ project.getConditionalExpression());
				String temp = project.getConditionalExpression();
				temp = temp.replace("(", "");
				temp = temp.replace(")", "");
				temp = temp.replaceAll("[|]", ":;");
				System.out.println(temp);
				if (temp.contains("+"))
			    {
					String[] Expressions = temp.split("[+]");
			        if (Expressions.length == 2)
			        {
			            String[] Exp0 = Expressions[0].split(":;");
			            String[] Exp1 = Expressions[1].split(":;");
			            for (int i = 0; i < Exp0.length; i++) {
			            	for (int j = 0; j < Exp1.length; j++) {
			            		if ((Exp0[i] != null) && (Exp0[i].length() > 0) && (Exp1[j].length() > 0) && (Exp1[j] != null))
			            		{
			            			temp = Exp0[i] + " " + Exp1[j];
			            			System.out.println(temp);
			            			queryString = URLEncoder.encode(temp, "utf-8");
			            			queryString = queryString.replace("%7C", "+%7C+");
			            			for (int s = 0; s < pageNumLimit; s++) 
			            			{
			            				String url = "http://news.baidu.com/ns?word=" + queryString	+ "&pn=" + i * 10;
			            				common.ThreadPool.runMetaThread(new BaiduThread(url,this.informationService, this.textInfoService, 0));
			            				try{
											Thread.sleep(pageDely);
										}catch (Exception e) {
											// TODO: handle exception
											e.printStackTrace();
										}
			            			}
			            		}
			            	}
			            }
			        }
			        if (Expressions.length == 3)
			        {
			            String[] Exp0 = Expressions[0].split(":;");
			            String[] Exp1 = Expressions[1].split(":;");
			            String[] Exp2 = Expressions[2].split(":;");
			            for (int i = 0; i < Exp0.length; i++) {
			                for (int j = 0; j < Exp1.length; j++) {
			                    for (int k = 0; k < Exp2.length; k++)
			                    {
			                    	temp = Exp0[i] + " " + Exp1[j] + " " + Exp2[k];
			                    	System.out.println(temp);
		                    		queryString = URLEncoder.encode(temp, "utf-8");
		                    		queryString = queryString.replace("%7C", "+%7C+");
		                    		String url = "http://search.sina.com.cn/?q=" + queryString + "&range=all&c=news&sort=time";
		                    		for (int s = 0; s < pageNumLimit; s++) 
		                    		{
		                    			String url1 = "http://news.baidu.com/ns?word=" + queryString	+ "&pn=" + i * 10;
		                    			common.ThreadPool.runMetaThread(new BaiduThread(url1,this.informationService, this.textInfoService, 0));
		                    			try{
		    								Thread.sleep(pageDely);
		    							}catch (Exception e) {
		    								// TODO: handle exception
		    								e.printStackTrace();
		    							}
		                    		}
			                  
			                    }
			                }
			            }
			        }
			    }
				else
				{
			        String[] Expressions = temp.split(":;");
			        for (int i = 0; i < Expressions.length; i++)
			        {
			          
			        	if ((Expressions[i] != null) && (Expressions[i].length() > 0))
			        	{
			        		temp = Expressions[i];
			        		System.out.println(temp);
			        		String queryString = URLEncoder.encode(temp, "utf-8");
			        		queryString = queryString.replace("%7C", "+%7C+");
			        		for (int s = 0; s < pageNumLimit; s++) 
                    		{
                    			String url1 = "http://news.baidu.com/ns?word=" + queryString	+ "&pn=" + i * 10;
                    			common.ThreadPool.runMetaThread(new BaiduThread(url1,this.informationService, this.textInfoService, 0));
                    			try{
    								Thread.sleep(pageDely);
    							}catch (Exception e) {
    								// TODO: handle exception
    								e.printStackTrace();
    							}
                    		}
			        	}
			        }
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			log.info("元搜索出错:" + e.getMessage());
		}
	}
	
	public static void LoginTianya(String strUrl)
	{
		System.setProperty("webdriver.chrome.driver", "C:\\Program Files (x86)\\Google\\Chrome\\Application\\chromedriver.exe");
	    WebDriver driver = new ChromeDriver();
	    driver.manage().timeouts().pageLoadTimeout(60L, TimeUnit.SECONDS);
	    String userName = "13631597569";String passWord = "xcz361552933";
	    try
		{
		      driver.get("http://www.tianya.cn/user/logout?returnURl=http%3A%2F%2Fwww.tianya.cn%2F106204650");
			  Thread.sleep(5000);
			  WebElement logDiv = driver.findElement(By.xpath("//*[@id='text1']"));
		      System.out.println(logDiv.getText()+"fgdfvdfbvvcvbv");
		      driver.findElement(By.xpath("//*[@id='text1']")).sendKeys(new CharSequence[] { userName });
		      driver.findElement(By.xpath("//*[@id='password1']")).sendKeys(new CharSequence[] { passWord });
		      driver.findElement(By.xpath("//*[@id='loginForm']/input[3]")).click();
	    }
	    catch (InterruptedException e)
	    {
	    	e.printStackTrace();
	    }
	}
	
	
	public static void LoginTencent(String strUrl)
	{
		System.setProperty("webdriver.chrome.driver", "C:\\Program Files (x86)\\Google\\Chrome\\Application\\chromedriver.exe");
	    WebDriver driver = new ChromeDriver();
	    driver.manage().timeouts().pageLoadTimeout(60L, TimeUnit.SECONDS);
	    String userName = "2224001080";String passWord = "361552933XCZ23";
	    try
		{
	    	driver.get("https://xui.ptlogin2.qq.com/cgi-bin/xlogin?appid=46000101&style=23&lang=&low_login=1&hide_border=1&hide_title_bar=1&hide_close_icon=1&border_radius=1&self_regurl=http%3A//reg.t.qq.com/index.php&proxy_url=http://t.qq.com/proxy_t.html&s_url=http%3A%2F%2Ft.qq.com&daid=6");
		    Thread.sleep(5000);
		    driver.findElement(By.xpath("//*[@id='u']")).sendKeys(new CharSequence[] { userName });
		    Thread.sleep(1000);
		    driver.findElement(By.xpath("//*[@id='p']")).sendKeys(new CharSequence[] { passWord });
		    Thread.sleep(1000);
		    driver.findElement(By.xpath("//*[@id='login_button']")).click();
	    }
	    catch (InterruptedException e)
	    {
	    	e.printStackTrace();
	    }
	}
	
	//http://weibo.com/login?url=http://weibo.com/aerchi
	public static void getStringBuffers(String strUrl)
	  {
	    System.setProperty("webdriver.chrome.driver", "C:\\Program Files (x86)\\Google\\Chrome\\Application\\chromedriver.exe");
	    WebDriver driver = new ChromeDriver();
	    driver.manage().timeouts().pageLoadTimeout(60L, TimeUnit.SECONDS);
	    String userName = "2224001080";String passWord = "361552933XCZ23";
	    try
	    {
	    	driver.get("https://xui.ptlogin2.qq.com/cgi-bin/xlogin?appid=46000101&style=23&lang=&low_login=1&hide_border=1&hide_title_bar=1&hide_close_icon=1&border_radius=1&self_regurl=http%3A//reg.t.qq.com/index.php&proxy_url=http://t.qq.com/proxy_t.html&s_url=http%3A%2F%2Ft.qq.com&daid=6");
		    Thread.sleep(5000);
		    driver.findElement(By.xpath("//*[@id='u']")).sendKeys(new CharSequence[] { userName });
		    Thread.sleep(1000);
		    driver.findElement(By.xpath("//*[@id='p']")).sendKeys(new CharSequence[] { passWord });
		    Thread.sleep(1000);
		    driver.findElement(By.xpath("//*[@id='login_button']")).click();
		    Thread.sleep(6000);
		    try
            {
              String queryString = URLEncoder.encode("检验检疫", "utf-8");
              queryString = queryString.replace("%7C", "+%7C+");
              String url = "http://search.t.qq.com/index.php?k=" + queryString + "&pos=201";
              driver.get(url);
              Thread.sleep(3000);
            }
            catch (Exception e)
            {
              e.printStackTrace();
            }
		    System.out.println(driver.getPageSource().toString());
	    }
	    catch (InterruptedException e)
	    {
	      e.printStackTrace();
	    }
	  }
	
	  public static String matchDateString()
	  {
		String getT1 = "(layer_)\\d{14}";
		String getT2 = "div><div class=\"Bv6_layer \" node-type=\"outer\" id=\"layer_14473126135361\" stk-mask-key=\"14473126135364\" style=\"top: 101.5px; left: 210px;\" ";
		try
	    {
	      Pattern p = Pattern.compile(getT1);
	      Matcher matcher = p.matcher(getT2);
	      if (matcher.find())
	      {
	          return matcher.group();
	      }
	    }
	    catch (Exception e)
	    {
	      return "";
	    }
		return "";
	  }
	  
	  public static String matchPatternString(String str, String pat)
	  {
		String getT1 = pat;
		try
	    {
	      Pattern p = Pattern.compile(getT1);
	      Matcher matcher = p.matcher(str);
	      if (matcher.find())
	      {
	          return matcher.group();
	      }
	    }
	    catch (Exception e)
	    {
	      return "";
	    }
		return "";
	  }

	  public static String getNowDay()
	  {
	    SimpleDateFormat formatter = new SimpleDateFormat("yyyy");
	    return formatter.format(new Date());
	  }
	public static void main(String args[]) throws UnsupportedEncodingException 
	{
		GetPage getPage = new GetPage();
		StringBuffer buffer = getPage.getStringBuffer("http://www.eastobacco.com/gyyd/cjbz/201504/t20150427_364710.html");
        
//		String str = "http://www.tobacco.gov.cn/html/48/4801/4886324_n.html";
//		String getT1 = "[\\S]*www.tobacco.gov.cn[\\S]*html";
//		try
//		{
//			Pattern p = Pattern.compile(getT1);
//			Matcher matcher = p.matcher(str);
//			if (matcher.find())
//			{
//				System.out.println(matcher.group());
//			}
//		}
//		catch (Exception e)
//		{
//			e.printStackTrace();
//		}
//		
		
		
        org.jsoup.nodes.Document doc=null;
        try{
        	doc = Jsoup.connect("http://sn.people.com.cn/BIG5/n2/2016/0330/c190219-28047964.html").get();
        }catch(Exception e)
        {
        	//e.printStackTrace();
        }
        //System.out.println(doc);
        System.out.println(GetTimeWords.GetPublicTime(GetTimeWords.matchDateString(GetTimeWords.GetTimeInString(doc.toString()))));
		
	}
}
