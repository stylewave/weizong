package action.timer;

import java.net.URLEncoder;
import java.util.Queue;
import java.util.concurrent.ConcurrentLinkedQueue;
import org.apache.log4j.Logger;
import dao.generated.Project;
import service.information.InformationService;
import service.textinfo.TextInfoService;

public class SinaNewsSearch {
	private Logger log = Logger.getLogger("yuqinglogger");
	private String queryString;
	private static int pageDely = 3000;//等待时间
	private InformationService informationService;
	private TextInfoService textInfoService;

	public SinaNewsSearch() {

	}

	public SinaNewsSearch(InformationService informationService) {
		this.informationService = informationService;
	}

	public SinaNewsSearch(InformationService informationService, TextInfoService textInfoService) {
		this.informationService = informationService;
		this.textInfoService = textInfoService;
	}
	public void begin()
	{
		try 
		{
			Queue<Project> queue = new ConcurrentLinkedQueue<Project>();
			queue.addAll(ThreadPool.projects);
			while (!queue.isEmpty())
			{
				Project project = queue.poll();
				log.info("开始搜索关键词:"+ project.getConditionalExpression());
				String temp = project.getConditionalExpression();
				queryString = URLEncoder.encode(temp,"utf-8");
				queryString = queryString.replace("%7C", "+%7C+");
				temp = temp.replace("(", "");
				temp = temp.replace(")", "");
				temp = temp.replaceAll("[|]", ":;");
		      	System.out.println(temp);
		      	if (temp.contains("+"))
		      	{
		      		String[] Expressions = temp.split("[+]");
		      		if (Expressions.length == 2)
			        {
		      			String[] Exp0 = Expressions[0].split(":;");
			          	String[] Exp1 = Expressions[1].split(":;");
			          	for (int i = 0; i < Exp0.length; i++) {
			          		for (int j = 0; j < Exp1.length; j++) {
			          			if ((Exp0[i] != null) && (Exp0[i].length() > 0) && (Exp1[j].length() > 0) && (Exp1[j] != null))
			          			{
			          				temp = Exp0[i] + " " + Exp1[j];
			          				System.out.println(temp);
			          				try
			          				{
			          					queryString = URLEncoder.encode(temp, "utf-8");
			          					queryString = queryString.replace("%7C", "+%7C+");
			          					String url = "http://search.sina.com.cn/?q=" + queryString + "&range=all&c=news&sort=time";
			          					common.ThreadPool.runMetaThread(new SinaNewsSearchThread(url,this.informationService, this.textInfoService, 0));
			          					Thread.sleep(pageDely);
			          				}
			          				catch (Exception e)
			          				{
			          					e.printStackTrace();
			          				}
			          			}
			          		}
			          	}
			        	}
		      		if (Expressions.length == 3)
		      		{
		      			String[] Exp0 = Expressions[0].split(":;");
		      			String[] Exp1 = Expressions[1].split(":;");
		      			String[] Exp2 = Expressions[2].split(":;");
		      			for (int i = 0; i < Exp0.length; i++) 
		      			{
		      				for (int j = 0; j < Exp1.length; j++) 
		      				{
		      					for (int k = 0; k < Exp2.length; k++)
		      					{
		      						temp = Exp0[i] + " " + Exp1[j] + " " + Exp2[k];
		      						System.out.println(temp);
		      						try
		      						{
		      							queryString = URLEncoder.encode(temp, "utf-8");
		      							queryString = queryString.replace("%7C", "+%7C+");
		      							String url = "http://search.sina.com.cn/?q=" + queryString + "&range=all&c=news&sort=time";
		      							common.ThreadPool.runMetaThread(new SinaNewsSearchThread(url,this.informationService, this.textInfoService, 0));
		      							Thread.sleep(pageDely);
		      						}
		      						catch (Exception e)
		      						{
		      							e.printStackTrace();
		      						}
		      					}
		      				}
		      			}
		      		}
		      	}	
		      	else
		      	{
		      		String[] Expressions = temp.split(":;");
			        for (int i = 0; i < Expressions.length; i++) 
			        {
			        	if ((Expressions[i] != null) && (Expressions[i].length() > 0))
			        	{
			        		temp = Expressions[i];
				            System.out.println(temp);
				            try
				            {
				            	queryString = URLEncoder.encode(temp, "utf-8");
				            	queryString = queryString.replace("%7C", "+%7C+");
				            	String url = "http://search.sina.com.cn/?q=" + queryString + "&range=all&c=news&sort=time";
				            	System.out.println(url);
				            	common.ThreadPool.runMetaThread(new SinaNewsSearchThread(url,this.informationService, this.textInfoService, 0));
				            	Thread.sleep(pageDely);
			            	}
				            catch (Exception e)
				            {
				            	e.printStackTrace();
				            }
			          	}
			        }
		      	}
			}
	
		} catch (Exception e) {
		e.printStackTrace();
		log.info("元搜索出错:" + e.getMessage());
		}
	}
}