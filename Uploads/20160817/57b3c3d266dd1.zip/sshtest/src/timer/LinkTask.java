/**
 * 
 */
package action.timer;

import java.util.List;
import java.util.concurrent.ThreadPoolExecutor;

import org.apache.log4j.Logger;

import service.information.InformationService;
import dao.generated.Project;
import dao.generated.TabInformationSource;

/**
 * @author 黄聪
 * 
 */
public class LinkTask extends Thread {
	private InformationService informationService;
	private String url;
	private boolean isSleep = true;
	private int level;

	private Logger logger = Logger.getLogger("yuqinglogger");

	public void run() {
		try {
			logger.debug("url线程启动url(" + url + ")");

		} catch (Exception e) {

		}
	}

	public InformationService getInformationService() {
		return informationService;
	}

	public void setInformationService(InformationService informationService) {
		this.informationService = informationService;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public int getLevel() {
		return level;
	}

	public void setLevel(int level) {
		this.level = level;
	}
}
