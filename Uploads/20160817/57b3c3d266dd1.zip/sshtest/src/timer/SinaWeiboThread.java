package action.timer;


import common.search.getPage.WeiboMessage;
import dao.generated.Managers;
import dao.generated.Project;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Queue;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.TimeUnit;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import service.information.ContentExtractor;
import service.information.InformationService;
import service.information.InformationServiceImpl;
import service.textinfo.TextInfoService;

class SinaWeiboThread implements Runnable
{
	  
	private Logger log = Logger.getLogger("yuqinglogger");
	private InformationService informationService;
	private TextInfoService textInfoService;
	private int DelayTime = 300000;
  
	public SinaWeiboThread(InformationService informationService)
 	{	
		this.informationService = informationService;
 	}
  
	public SinaWeiboThread(InformationService informationService, TextInfoService textInfoService)
	{
		this.informationService = informationService;
		this.textInfoService = textInfoService;
	}
  
	public static String matchPatternString(String str, String pat)
	{
		String getT1 = pat;
		try
		{
			Pattern p = Pattern.compile(getT1);
			Matcher matcher = p.matcher(str);
			if (matcher.find())
			{
				return matcher.group();
			}
		}
		catch (Exception e)
		{
			return "";
		}
		return "";
	}
  
	public static ArrayList<WeiboMessage> ToWeiboContent(String sb)
	{
		String WeiboId = "<div mid=\":;\"";
		String WebAddress = "rel=\"nofollow\">:;</a>";
		String WeiboTimeFormat = "title(.*?)date";
		String WeiboUrlFormat = "<div class=\"feed_from W_textb\">:;</div>:;<a href=\":;\"";
		String WeiboTextFormat = "<p class=\"comment_txt\":;</p>";
		String WeiboPlFormat = "评论<em>:;</em>";
		String WeiboZFFormat = "转发<em>:;</em>";
		String WeiboTitle = "<a class=\"W_texta W_fb\" nick-name=\":;\"";
		String HtmlHeader = "<!doctype html><html lang=\"en\"><body><head><meta charset=\"UTF-8\"><title>content</title></head>";
		String HtmlLast = "</body></html>";
		String ContentAll = "<div class=\"WB_cardwrap S_bg2 clearfix\"";
		ArrayList<WeiboMessage> messages = new ArrayList<WeiboMessage>();
		String[] AllWeibo = sb.split("<div class=\"WB_cardwrap S_bg2 clearfix\"");
		int count = AllWeibo.length;
		System.out.println("长度为:" + count);
		for (int i = 0; i < AllWeibo.length; i++) {
			if (AllWeibo[i].contains("mid="))
			{
				String content = ContentExtractor.getContentByHtml("<p class=\"comment_txt\"" + InformationServiceImpl.getFilts1(AllWeibo[i], WeiboTextFormat, ":;") + "</p>");
				String[] con = content.split("\n");
				content = "";
				for (int cnt = 0; cnt < con.length; cnt++) {
					content =  content + con[cnt];
				}
				System.out.println(content);
				String[] cont=content.split("】");
				content=cont[cont.length-1];
				System.out.println(content);
				if (content != null)
				{
					WeiboMessage wm = new WeiboMessage();
					wm.weibocontent = (HtmlHeader + ContentAll + AllWeibo[i] + HtmlLast);
					wm.weibo = content.trim();
					wm.weibotime = GetTimeWords.matchDateString(matchPatternString(AllWeibo[i], WeiboTimeFormat));
					wm.weibourl = InformationServiceImpl.getFilts1(AllWeibo[i], WeiboUrlFormat, ":;");
					wm.mid = InformationServiceImpl.getFilts1(AllWeibo[i], WeiboId, ":;");
					wm.zhuanfa = InformationServiceImpl.getFilts1(AllWeibo[i], WeiboZFFormat, ":;");
					wm.remark = InformationServiceImpl.getFilts1(AllWeibo[i], WeiboPlFormat, ":;");
					wm.weibotitle = InformationServiceImpl.getFilts1(AllWeibo[i], WeiboTitle, ":;");
					wm.ouname = InformationServiceImpl.getFilts1(AllWeibo[i], WeiboTitle, ":;");
					wm.weibosourse = InformationServiceImpl.getFilts1(AllWeibo[i], WebAddress, ":;");   
					messages.add(wm);
				}
			}
		}
		return messages;
	}
  
	public static String matchPageString(String str)
	{
		String getT1 = "(layer_)\\d{14}";
		try
		{
			Pattern p = Pattern.compile(getT1);
			Matcher matcher = p.matcher(str);
			if (matcher.find())
			{
				return matcher.group();
			}
		}
		catch (Exception e)
		{
			return "";
		}
		return "";
	}
  
	public void getSinaWeiboData(String strUrl)
	{
		System.setProperty("webdriver.chrome.driver", "C:\\Program Files (x86)\\Google\\Chrome\\Application\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.manage().timeouts().pageLoadTimeout(60L, TimeUnit.SECONDS);
		// String userName = "1376608305@qq.com";String passWord = "4584083jjjj";
		String userName = "xie361552933@163.com";String passWord = "xcz361552933";
		int keywordcount = 0;
		try
		{
			String loginUrl = "http://s.weibo.com";
			driver.get(loginUrl);
			Thread.sleep(15000);
			driver.findElement(By.xpath("//*[@id='weibo_top_public']/div/div/div[3]/div[2]/ul/li[3]/a")).click();
			Thread.sleep(10000);
			String layid = driver.getPageSource().toString();
			driver.findElement(By.xpath("//*[@id='"+ matchPageString(layid)+"']/div[2]/div[3]/div[1]/a[2]")).click();
			Thread.sleep(1000);
			driver.findElement(By.xpath("//*[@id='"+ matchPageString(layid)+"']/div[2]/div[3]/div[3]/div[1]/input")).sendKeys(new CharSequence[] { userName });
			driver.findElement(By.xpath("//*[@id='"+ matchPageString(layid)+"']/div[2]/div[3]/div[3]/div[2]/input")).sendKeys(new CharSequence[] { passWord });
			Thread.sleep(1000);
			driver.findElement(By.xpath("//*[@id='"+ matchPageString(layid)+"']/div[2]/div[3]/div[3]/div[6]/a")).click();
			Thread.sleep(5000);
		}
		catch (InterruptedException e)
		{
			e.printStackTrace();
		}
		
		 Queue<Managers> queues = new ConcurrentLinkedQueue<Managers>();
		 queues.addAll(ThreadPool.managers);
		 while (!queues.isEmpty())
		 {
		      Managers manager = (Managers)queues.poll();
		      if(manager.getProjectName()!=null)
		      {
		    	  try
		    	  {
		    		  String queryString = URLEncoder.encode(manager.getProjectName(), "utf-8");
		    		  queryString = queryString.replace("%7C", "+%7C+");
		    		  String url = "http://s.weibo.com/weibo/" + queryString + "?topnav=1&wvr=6&b=1";
		    		  driver.get(url);
		    		  Thread.sleep(3000);
		    		  ArrayList<WeiboMessage> messages = ToWeiboContent(driver.getPageSource());
		    		  try
		    		  {
		    			  this.informationService.saveWeibo(messages, this.textInfoService);
		    		  }
		    		  catch (InterruptedException e1)
		    		  {
		    			  e1.printStackTrace();
		    		  }
		    	  }
		    	  catch (Exception e)
		    	  {
		    		  e.printStackTrace();
		    	  }
		      }
	    }
		
		Queue<Project> queue = new ConcurrentLinkedQueue<Project>();
		queue.addAll(ThreadPool.projects);
		while (!queue.isEmpty())
		{
      
			Project project = (Project)queue.poll();
			String temp = project.getConditionalExpression();
			temp = temp.replace("(", "");
			temp = temp.replace(")", "");
	   		temp = temp.replaceAll("[|]", ":;");
	   		System.out.println(temp);
	   		if (temp.contains("+"))
	   		{
	   			String[] Expressions = temp.split("[+]");
	   			if (Expressions.length == 2)
	   			{
	   				String[] Exp0 = Expressions[0].split(":;");
	   				String[] Exp1 = Expressions[1].split(":;");
	   				for (int i = 0; i < Exp0.length; i++) {
	   					for (int j = 0; j < Exp1.length; j++) {
	   						if ((Exp0[i] != null) && (Exp0[i].length() > 0) && (Exp1[j].length() > 0) && (Exp1[j] != null))
	   						{
	   							temp = Exp0[i] + " " + Exp1[j];
	        					System.out.println(temp);
	        					try
	        					{
	        						String queryString = URLEncoder.encode(temp, "utf-8");
	        						queryString = queryString.replace("%7C", "+%7C+");
	        						String url = "http://s.weibo.com/weibo/" + queryString + "?topnav=1&wvr=6&b=1";
	        						driver.get(url);
	        						Thread.sleep(3000L);
	        					}
	        					catch (Exception e)
	        					{
	        						e.printStackTrace();
	        					}
	        					ArrayList<WeiboMessage> messages = ToWeiboContent(driver.getPageSource());
	        					try
	        					{
	        						this.informationService.saveWeibo(messages, this.textInfoService);
	        					}
	        					catch (InterruptedException e1)
	        					{
	        						e1.printStackTrace();
	        					}
	        					keywordcount++;
	        					if (keywordcount % 19 == 0) {
	        						try
	        						{
	        							System.out.println("超过十九条进入等待阶段！！！！");
	        							Thread.sleep(this.DelayTime);
	        						}
	        						catch (InterruptedException e)
	        						{
	        							e.printStackTrace();
	        						}
	        					} else {
	        						try
	        						{
	        							System.out.println("等待十秒！！！！");
	        							Thread.sleep(100L);
	        						}
	        						catch (InterruptedException e)
	        						{
	        							e.printStackTrace();
	        						}
	                
	        					}
	   						}
	   					}
	   				}
	   			}
	   			if (Expressions.length == 3)
	   			{
	   				String[] Exp0 = Expressions[0].split(":;");
	   				String[] Exp1 = Expressions[1].split(":;");
	   				String[] Exp2 = Expressions[2].split(":;");
	   				for (int i = 0; i < Exp0.length; i++) {
	   					for (int j = 0; j < Exp1.length; j++) {
	   						for (int k = 0; k < Exp2.length; k++)
	   						{
	   							temp = Exp0[i] + " " + Exp1[j] + " " + Exp2[k];
	   							System.out.println(temp);
	   							try
	   							{
	   								String queryString = URLEncoder.encode(temp, "utf-8");
	   								queryString = queryString.replace("%7C", "+%7C+");
	   								String url = "http://s.weibo.com/weibo/" + queryString + "?topnav=1&wvr=6&b=1";
	   								driver.get(url);
	   								Thread.sleep(3000L);
	   							}
	   							catch (Exception e)
	   							{
	   								e.printStackTrace();
	   							}
	   							ArrayList<WeiboMessage> messages = ToWeiboContent(driver.getPageSource());
	   							try
	   							{
	   								this.informationService.saveWeibo(messages, this.textInfoService);
	   							}
	   							catch (InterruptedException e1)
	   							{
	   								e1.printStackTrace();
	   							}
	   							keywordcount++;
	   							if (keywordcount % 19 == 0) {
	   								try
	   								{
	   									System.out.println("超过十九条进入等待阶段！！！！");
	   									Thread.sleep(this.DelayTime);
	   								}
	   								catch (InterruptedException e)
	   								{
	   									e.printStackTrace();
	   								}
	   							} else {
	   								try
	   								{
	   									System.out.println("等待十秒！！！！");
	   									Thread.sleep(100L);
	   								}
	   								catch (InterruptedException e)
	   								{
	   									e.printStackTrace();
	   								}
	   							}
	   						}
	   					}
	   				}
	   			}
	   		}
	   		else
	   		{
	   			String[] Expressions = temp.split(":;");
	   			for (int i = 0; i < Expressions.length; i++) {
	   				if ((Expressions[i] != null) && (Expressions[i].length() > 0))
	   				{
	   					temp = Expressions[i];
	   					System.out.println(temp);
	   					try
	   					{
	   						String queryString = URLEncoder.encode(temp, "utf-8");
	   						queryString = queryString.replace("%7C", "+%7C+");
	   						String url = "http://s.weibo.com/weibo/" + queryString + "?topnav=1&wvr=6&b=1";
	   						driver.get(url);
	   						Thread.sleep(3000L);
	   					}
	   					catch (Exception e)
	   					{
	   						e.printStackTrace();
	   					}
	   					ArrayList<WeiboMessage> messages = ToWeiboContent(driver.getPageSource());
	   					try
	   					{
	   						this.informationService.saveWeibo(messages, this.textInfoService);
	   					}
	   					catch (InterruptedException e1)
	   					{
	   						e1.printStackTrace();
	   					}
	   					keywordcount++;
	   					if (keywordcount % 19 == 0) {
	   						try
	   						{
	   							System.out.println("超过十九条进入等待阶段！！！！");
	   							Thread.sleep(this.DelayTime);
	   						}
	   						catch (InterruptedException e)
	   						{
	   							e.printStackTrace();
	   						}
	   					} else {
	   						try
	   						{
	   							System.out.println("等待十秒！！！！");
	   							Thread.sleep(100L);
	   						}
	   						catch (InterruptedException e)
	   						{
	   							e.printStackTrace();
	   						}
	   					}
	   				}
	   			}
	   		}
		}
		driver.close();
		driver.quit();
	}
  
	public void run()
	{
		System.out.println("开始登录微博");
		getSinaWeiboData("s");
	}
}
