package action.timer;

import common.search.getPage.GetPage;
import common.search.getPage.ReadPageData;
import java.net.URL;
import java.util.List;
import org.apache.log4j.Logger;
import service.information.InformationService;
import service.textinfo.TextInfoService;

class BaiduThread implements Runnable
{
  private String url;
  private Logger log = Logger.getLogger("yuqinglogger");
  private InformationService informationService;
  private TextInfoService textInfoService;
  int i;
  public BaiduThread(String url, InformationService informationService, TextInfoService textInfoService, int i)
  {
    this.url = url;
    this.informationService = informationService;
    this.textInfoService = textInfoService;
    this.i=i;
  }
  
  public void run()
  {
    GetPage getPage = new GetPage();
    StringBuffer buffer = getPage.getStringBuffer(this.url);
    if ((buffer != null) && (!buffer.toString().trim().equals("")))
    {

      ReadPageData readPageData = new ReadPageData();
      List<String> result = null;
      try
      {
        result = readPageData.getLinks(buffer, new URL(this.url).getHost(), "kong");
      }catch (Exception e)
      {
        e.printStackTrace();
      }
      for (int i = 0; i < result.size(); i++)
      {
        String s = (String)result.get(i);
        if ((s.contains("htm")) && (!s.contains("baidu.com")) &&  (!s.contains("index.php")))
        {
          try{
				Thread.sleep(1000);
        	   this.informationService.saveAndGetLinks(s, this.textInfoService, i);
          }catch (Exception e) {
			// TODO: handle exception
        	  e.printStackTrace();
		}
         
        }
      }
    }
  }
}
