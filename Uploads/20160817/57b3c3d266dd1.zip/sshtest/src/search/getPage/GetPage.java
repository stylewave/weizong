/**
 * 
 */
package common.search.getPage;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.security.GeneralSecurityException;
import java.security.cert.X509Certificate;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.X509TrustManager;

import org.apache.commons.httpclient.DefaultHttpMethodRetryHandler;
import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.methods.GetMethod;
import org.apache.commons.httpclient.params.HttpMethodParams;
import org.apache.log4j.Logger;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import common.Configuration;
/**
 * @author 明兴网络
 *  
 */
public class GetPage {
	private static String loginUrl = null;
	private static String userName = null;
	private static String password = null;
	private static String userId = null;
	private static String passId = null;
	public static String sessionId = null;
	private String url = "https://202.115.200.183:8080/SUSF/login!logon?sysUser.password=1111&sysUser.usercode=admin";
	private myX509TrustManager xtm = new myX509TrustManager();
	private myHostnameVerifier hnv = new myHostnameVerifier();
	private Logger logger = Logger.getLogger("yuqinglogger");
	

	public GetPage() {
		SSLContext sslContext = null;
		try {
			sslContext = SSLContext.getInstance("SSL"); // 或SSL
			X509TrustManager[] xtmArray = new X509TrustManager[] { xtm };
			sslContext.init(null, xtmArray, new java.security.SecureRandom());
		} catch (GeneralSecurityException e) {
			e.printStackTrace();
		}
		if (sslContext != null) {
			HttpsURLConnection.setDefaultSSLSocketFactory(sslContext
					.getSocketFactory());
		}
		HttpsURLConnection.setDefaultHostnameVerifier(hnv);
	}
	
	public static String GetUserName() {
		return Configuration.getValue("loginName");
	}
	
	public static String GetpassWord() {
		return Configuration.getValue("loginPw");
	}

	public static String sessionId() {
		if (sessionId == null) {
			loginUrl = Configuration.getValue("loginUrl");
			userName = Configuration.getValue("userName");
			password = Configuration.getValue("password");
			userId = Configuration.getValue("userId");
			passId = Configuration.getValue("passId");
			try {
				loginPage();
				// loginPageByhttps();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		if (sessionId == null) {
			try {
				throw new Exception("用户名密码有误，请修改配置文件");
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		// System.out.println(sessionId);
		return sessionId;
	}

	/**
	 * 登录页面保存cookie信息
	 * 
	 * @author 明兴网络
	 * @return
	 * @throws IOException
	 */
	private static void loginPage() throws IOException {
		// 从登录页登录
		HttpURLConnection urlcon;
		URL url = new URL(loginUrl);
		urlcon = (HttpURLConnection) url.openConnection();
		// 设置登录信息
		urlcon.setDoOutput(true);
		urlcon.setRequestMethod("GET");
		urlcon.setRequestProperty("User-Agent",
				"Mozilla/4.0 (compatible; MSIE 6.0; Windows 2000)");
		StringBuffer sb = new StringBuffer();
		if (userId != null && !userId.trim().equals("")) {
			sb.append(userId + "=" + userName);
		} else {
			sb.append("username=" + userName);
		}
		if (passId != null && !passId.trim().equals("")) {
			sb.append("&" + passId + "=" + password);
		} else {
			sb.append("&password=" + password);
		}
		sb.append("&temppass=" + "123456");
		// System.out.println(sb);
		OutputStream os = urlcon.getOutputStream();
		os.write(sb.toString().getBytes("utf-8"));
		os.close();

		// 取得cookie
		urlcon.getInputStream();
		String cookieVal = urlcon.getHeaderField("Set-Cookie");
		if (cookieVal != null) {
			sessionId = cookieVal.substring(0, cookieVal.indexOf(";"));
		}
		BufferedReader br = new BufferedReader(new InputStreamReader(
				urlcon.getInputStream()));
		urlcon.connect();
	}

	/**
	 * 登录页面保存cookie信息https
	 * 
	 * @author 明兴网络
	 * @return
	 * @throws IOException
	 */
	static void loginPageByhttps() throws IOException {
		// 从登录页登录
		HttpsURLConnection urlcon;
		URL url = new URL(loginUrl);
		urlcon = (HttpsURLConnection) url.openConnection();
		// 设置登录信息
		urlcon.setDoOutput(true);
		urlcon.setRequestMethod("GET");
		urlcon.setRequestProperty("User-Agent",
				"Mozilla/4.0 (compatible; MSIE 6.0; Windows 2000)");
		StringBuffer sb = new StringBuffer();
		if (userId != null && !userId.trim().equals("")) {
			sb.append(userId + "=" + userName);
		} else {
			sb.append("username=" + userName);
		}
		if (passId != null && !passId.trim().equals("")) {
			sb.append("&" + passId + "=" + password);
		} else {
			sb.append("&password=" + password);
		}
		sb.append("&temppass=" + "123456");
		// System.out.println(sb);
		OutputStream os = urlcon.getOutputStream();
		os.write(sb.toString().getBytes("GBK"));
		os.close();

		// 取得cookie
		urlcon.getInputStream();
		String cookieVal = urlcon.getHeaderField("Set-Cookie");
		if (cookieVal != null) {
			sessionId = cookieVal.substring(0, cookieVal.indexOf(";"));
		}
		BufferedReader br = new BufferedReader(new InputStreamReader(
				urlcon.getInputStream()));
		String line;
		while ((line = br.readLine()) != null) {
		//	System.out.println(line);
		}
		urlcon.connect();
	}

	/**
	 * 获取指定页面源码
	 * 
	 * @param strUrl
	 * @return
	 * @author 明兴网络
	 */
	public static BufferedReader getPageSource(String strUrl)
			throws IOException {
		URL url = new URL(strUrl);
		// System.out.println(strUrl);
		// 发送设置cookie:
		HttpURLConnection urlcon = (HttpURLConnection) url.openConnection();
		if (Configuration.getValue("loginUrl") != null
				&& !Configuration.getValue("loginUrl").trim().equals("")) {
			urlcon.addRequestProperty("Cookie", sessionId());
		}
		BufferedReader br = new BufferedReader(new InputStreamReader(
				urlcon.getInputStream(), "UTF-8"));
		urlcon.connect();
		return br;
	}

	public static BufferedReader getPageSourceWithOutLogin(String strUrl)
			throws IOException {
		URL url = new URL(strUrl);
		// System.out.println(strUrl);
		// 发送设置cookie:
		HttpURLConnection urlcon = (HttpURLConnection) url.openConnection();
		BufferedReader br = new BufferedReader(new InputStreamReader(
				urlcon.getInputStream()));
		urlcon.connect();
		return br;
	}

	//旧版本获取网页源码，只能获取静态的
	public StringBuffer getStringBuffer(String strUrl) {
		try {
			/*
			 * HttpClient hc = new HttpClient(); GetMethod gm = new
			 * GetMethod(strUrl);
			 * gm.getParams().setParameter(HttpMethodParams.SO_TIMEOUT,5000);
			 * gm.getParams().setParameter(HttpMethodParams.RETRY_HANDLER,new
			 * DefaultHttpMethodRetryHandler());
			 * gm.setRequestHeader("User-Agent",
			 * "Mozilla/4.0 (compatible; MSIE 6.0; Windows 2000)");
			 * gm.setRequestHeader("Accept",
			 * "text/html,application/xhtml+xml,application/xml;q=0.9,*
			 * /*;q=0.8"); int statusCode = hc.executeMethod(gm); BufferedReader
			 * br = new BufferedReader(new
			 * InputStreamReader(gm.getResponseBodyAsStream(),"UTF-8"));
			 */
			String cookie = "";
			URL url = new URL(strUrl);
			HttpURLConnection urlcon = (HttpURLConnection) url.openConnection();
			HttpURLConnection.setFollowRedirects(true);
			urlcon.setConnectTimeout(5000);
			urlcon.setReadTimeout(30000);
			urlcon.setRequestMethod("GET");
			urlcon.setRequestProperty("User-Agent",
					"Mozilla/4.0 (compatible; MSIE 6.0; Windows 2000)");
			urlcon.setRequestProperty("Accept",
					"text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8");
			if(!cookie.equals("")){
				urlcon.setRequestProperty("Cookie", cookie);
			}
			BufferedReader br = new BufferedReader(new InputStreamReader(
					urlcon.getInputStream(),"UTF-8"));
			StringBuffer returnBuffer = new StringBuffer();
			String line;
			while ((line = br.readLine()) != null) {
				returnBuffer.append(line);
			}
			
			return returnBuffer;
		} catch (Exception e) {
			//printf("获取连接(" + strUrl + ")出错:" + e.getMessage());
			return new StringBuffer("");
		}
	}
	
	//雷德诚添加，可以获取加载js后的网页源码，非常有用
//	public StringBuffer getStringBuffer1(String strUrl)
//	{
//		  String url = strUrl;
//		  System.out.println("getStringBuffer1:"+strUrl);
//
//		    WebClient webClient =  new WebClient(BrowserVersion.CHROME); 
//	        webClient.getOptions().setThrowExceptionOnScriptError(false);  
//	        webClient.getOptions().setThrowExceptionOnFailingStatusCode(false);  
//	        webClient.getOptions().setJavaScriptEnabled(true);  
//	        webClient.getOptions().setActiveXNative(true);  
//	        webClient.getOptions().setCssEnabled(false);  
//	        webClient.getOptions().setTimeout(5000);
//	        webClient.waitForBackgroundJavaScript(5000);  
//	        webClient.setAjaxController(new NicelyResynchronizingAjaxController());  
//	         //追加内容
//	         new InterceptWebConnection(webClient); 
//	        
//	        HtmlPage page = null;
//			try {
//				//long startTime = System.currentTimeMillis();
//				page = (HtmlPage) webClient.getPage(url);
//				//这个很重要,不同的页面加载时间不同
//		        webClient.waitForBackgroundJavaScript(5000);
//		        webClient.setJavaScriptTimeout(5000);  
//				//long endTime = System.currentTimeMillis();
//				//System.out.println(page.asXml());
//				//long time=endTime-startTime; 
//				////花费时间:18393,16651
//				//System.out.println("花费时间:"+time);
//		        
//			} catch (FailingHttpStatusCodeException e) {
//				// TODO Auto-generated catch block
//				e.printStackTrace();
//				System.out.println("FailingHttpStatusCodeException错误链接:"+strUrl);
//				return new StringBuffer("");
//				
//			} catch (MalformedURLException e) {
//				// TODO Auto-generated catch block
//				e.printStackTrace();
//				System.out.println("MalformedURLException错误链接:"+strUrl);
//				return new StringBuffer("");
//			} catch (IOException e) {
//				// TODO Auto-generated catch block
//				e.printStackTrace();
//				System.out.println("IOException错误链接:"+strUrl);
//				return new StringBuffer("");
//			}
//			 
//			
//			 return new StringBuffer(page.asXml()); 
//	
//	}
	public StringBuffer getStringBuffer2(String strUrl)
	{
		
		System.setProperty("webdriver.chrome.driver", "C:\\Program Files (x86)\\Google\\Chrome\\Application\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();//FirefoxDriverC:\Program Files (x86)\Google\Chrome\Application
		String temp = ""; 	
		try {
		//WebDriver driver = new FirefoxDriver();//FirefoxDriver
		//driver.manage().window().maximize();
		driver.manage().timeouts().pageLoadTimeout(60, TimeUnit.SECONDS);
		driver.manage().window().setSize(new Dimension(0,0));
		driver.get(strUrl);
		Thread.sleep(2000);
		
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		catch(Exception e)
		{
			e.printStackTrace();

		}finally
		{
			temp = driver.getPageSource();	
			driver.close();
			driver.quit();
		}

		return new StringBuffer(temp); 
	}
	/**
	 * 获取指定页面源码
	 * 
	 * @param strUrl
	 * @return
	 * @author 明兴网络
	 */
	public static BufferedReader getPageSourceByhttps(String strUrl)
			throws IOException {
		URL url = new URL(strUrl);
		// System.out.println(strUrl);
		// 发送设置cookie:
		HttpsURLConnection urlcon = (HttpsURLConnection) url.openConnection();
		// if(Configuration.getValue("loginUrl")!=null&&!Configuration.getValue("loginUrl").trim().equals("")){
		// //urlcon.addRequestProperty("Cookie", sessionId());
		// }
		BufferedReader br = new BufferedReader(new InputStreamReader(
				urlcon.getInputStream()));
		urlcon.connect();
		return br;
	}

	class myX509TrustManager implements X509TrustManager {

		public void checkClientTrusted(X509Certificate[] chain, String authType) {
		}

		public void checkServerTrusted(X509Certificate[] chain, String authType) {
		}

		public X509Certificate[] getAcceptedIssuers() {
			return null;
		}
	}

	class myHostnameVerifier implements HostnameVerifier {

		public boolean verify(String hostname, SSLSession session) {
			System.out.println("Warning: URL Host: " + hostname + " vs. "
					+ session.getPeerHost());
			return true;
		}
	}

	public void run() {
		HttpsURLConnection urlCon = null;
		try {
			urlCon = (HttpsURLConnection) (new URL(url)).openConnection();
			urlCon.setDoOutput(true);
			urlCon.setRequestMethod("POST");
			urlCon.setRequestProperty("Content-Length", "1024");
			urlCon.setUseCaches(false);
			urlCon.setDoInput(true);
			urlCon.getOutputStream().write("request content".getBytes("gbk"));
			urlCon.getOutputStream().flush();
			urlCon.getOutputStream().close();
			BufferedReader in = new BufferedReader(new InputStreamReader(
					urlCon.getInputStream()));
			String line;
			while ((line = in.readLine()) != null) {
		//		System.out.println(line);
			}
			// 增加自己的代码
		} catch (MalformedURLException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static void main(String[] args) {
		try {
			String url = "http://www.cnnvd.org.cn/news/jklbz/id/CNNVD Situation Report";
			String host = new URL(url).getHost();
			System.out.println(host);
			GetPage getPage = new GetPage();
			//读取页面源码 
			StringBuffer sb = getPage.getStringBuffer2(url);
			ReadPageData readPageData = new ReadPageData();

			int charcheck=sb.indexOf("charset=")+8;
			System.out.println("charStr:"+charcheck);
			String charStr = sb.substring(charcheck,charcheck+ 10);
			System.out.println("charStr:"+charStr);
			
			if (charStr.contains("GBK") 
					|| charStr.contains("gbk") 
					|| charStr.contains("\"GBK\"") 
					|| charStr.contains("\"gbk\"") 
					|| charStr.contains("\"gb2312\"") 
					|| charStr.contains("\"GB2312\"") 
					|| charStr.contains("GB2312") 
					|| charStr.contains("gb2312") ) {
				sb = getPage.getStringBuffer(url.trim(), "GBK");
				//System.out.println("GBK连接"+url+readPageData.getTitle(sb));
			}
			else if (charStr.contains("BIG5"))
			{
				sb = getPage.getStringBuffer(url.trim(), "BIG5");
				//System.out.println("BIG5"+url+readPageData.getTitle(sb));
			}
			
			System.out.println( readPageData.getTitle(sb));

			
			String temp=readPageData.getSubStr(sb.toString(), "<span id=\"views\">", "<");
			if(temp!="" && temp!=null)
				System.out.println(temp);
			
			temp=readPageData.getSubStr(sb.toString(), "来源：", " ");
			if(temp!=""&& temp!=null)
				System.out.println(temp);
//			ArrayList<String> arrayList2 = readPageData.getLinks(sb,host,"[\\S]*qq.com[\\S]*htm");
//			
//			System.out.println( "可用连接数:"+arrayList2.size());
//			for (int i = 0; i < arrayList2.size(); i++) {
//				
//				//	System.out.println("url(" + url + ")中的连接:(" + arrayList2.get(i)	+ ")");
//					
//				}
			
		
		}catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * 需要代理服务器
	 * 
	 * @param strUrl
	 * @return
	 * @throws Exception
	 */
	public StringBuffer getStringBufferBydl(String strUrl) throws Exception {
		URL url = new URL(strUrl);
		Properties prop = System.getProperties();
		// 设置http访问要使用的代理服务器的地址
		prop.setProperty("http.proxyHost", "10.0.0.200");
		// 设置http访问要使用的代理服务器的端口
		prop.setProperty("http.proxyPort", "80");
		HttpURLConnection urlcon = (HttpURLConnection) url.openConnection();

		BufferedReader br = new BufferedReader(new InputStreamReader(
				urlcon.getInputStream(), "utf-8"));
		StringBuffer returnBuffer = new StringBuffer();
		String line;
		while ((line = br.readLine()) != null) {
			returnBuffer.append(line);
		}
		urlcon.disconnect();
		urlcon = null;
		return returnBuffer;
	}

	public StringBuffer getStringBuffer(String strUrl, String string) {
		try {
			HttpClient hc = new HttpClient();
			GetMethod gm = new GetMethod(strUrl);
			gm.getParams().setParameter(HttpMethodParams.SO_TIMEOUT, 5000);
			gm.getParams().setParameter(HttpMethodParams.RETRY_HANDLER,
					new DefaultHttpMethodRetryHandler());
			gm.setRequestHeader("User-Agent",
					"Mozilla/4.0 (compatible; MSIE 6.0; Windows 2000)");
			gm.setRequestHeader("Accept",
					"text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8");
			int statusCode = hc.executeMethod(gm);
			BufferedReader br = new BufferedReader(new InputStreamReader(
					gm.getResponseBodyAsStream(), string));
			StringBuffer returnBuffer = new StringBuffer();
			String line;
			while ((line = br.readLine()) != null) {
				returnBuffer.append(line);
			}
			// urlcon.disconnect();
			// urlcon = null;
			gm.releaseConnection();
			return returnBuffer;
		} catch (Exception e) {
			//printf("获取连接(" + strUrl + ")出错:" + e.getMessage());
			return new StringBuffer("");
		}
	}

	public static String getRealUrl(String s) {
		GetPage gp = new GetPage();
		StringBuffer sb = gp.getStringBuffer(s);
		//System.out.println(sb.toString());
		if(!(sb.indexOf("a href=")==-1)){
			String locationUrl = sb.substring(sb
				.indexOf("a href=") + "a href=".length() + 1);
			locationUrl = locationUrl.substring(0, locationUrl.indexOf("\"") );
			return locationUrl;
		}
			//System.out.println(locationUrl);
		else{
			return null;
		}
		
	}

}
