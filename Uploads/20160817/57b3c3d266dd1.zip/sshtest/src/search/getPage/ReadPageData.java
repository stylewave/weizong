package common.search.getPage;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.sql.Date;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashSet;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.log4j.Logger;
import org.jfree.util.Log;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;

import action.timer.IsTask;

import common.CommonMethod;

public class ReadPageData {
	 private Logger logger = Logger.getLogger("yuqinglogger");
	/**
	 * 获取某个table所包含的所有字符
	 * 
	 * @param tableIndex
	 *            第几个table
	 * @param sbPage
	 *            页面源代码
	 * @return StringBuffer
	 */
	public StringBuffer getTableStr(int tableIndex, StringBuffer sbPage) {
		StringBuffer sbTempPage = sbPage;
		int fromIndex;
		for (int i = 0; i < tableIndex; i++) {
			fromIndex = sbTempPage.indexOf("<TABLE") != -1 ? sbTempPage
					.indexOf("<TABLE") : sbTempPage.indexOf("<table");
			sbTempPage = new StringBuffer(sbTempPage.substring(fromIndex + 1));
		}
		System.out.println("ReadPageData:"+sbTempPage);//++
		return sbTempPage;
	}

	/**
	 * 从整个TABLE中获取某个TD中的值
	 * 
	 * @param tdIndex
	 *            td序号
	 * @param sbTable
	 *            整个table的源码
	 * @return
	 */
	private StringBuffer getTdStr(int tdIndex, StringBuffer sbTable) {
		StringBuffer sbTempValue = sbTable;
		int startIndex;
		int endIndex;
		for (int i = 0; i < tdIndex; i++) {
			startIndex = sbTempValue.indexOf("<TD") != -1 ? sbTempValue
					.indexOf("<TD") : sbTempValue.indexOf("<td");
			sbTempValue = new StringBuffer(
					sbTempValue.substring(startIndex + 1));
		}
		startIndex = sbTempValue.indexOf(">");
		endIndex = sbTempValue.indexOf("</TD>") != -1 ? sbTempValue
				.indexOf("</TD>") : sbTempValue.indexOf("</td>");
		sbTempValue = new StringBuffer(sbTempValue.substring(startIndex + 1,
				endIndex));
		sbTempValue = trimValue(sbTempValue);
		System.out.println("ReadPageData:"+sbTempValue);//++
		return sbTempValue;
	}

	/**
	 * 循环每行,取出每行偶数TD中的值
	 * 
	 * @param type
	 *            类型,jy为简易程序;yb为一般程序
	 * @param allValue
	 *            存放值
	 * @param sbTable
	 *            初始的字符串
	 * @return
	 */
	public void getEvenTdStr(String type, ArrayList<String> allValue,
			StringBuffer sbTable) {
		StringBuffer sbTempValue = null;
		StringBuffer sbLeave = sbTable;
		int trSize = 0;
		int startIndex;
		int endIndex;
		int eventTd = 0;
		if (type.equals("yb")) {
			trSize = 19;
		} else {
			trSize = 16;
		}
		for (int i = 0; i < trSize; i++) {
			startIndex = sbLeave.indexOf("<TR") != -1 ? sbLeave.indexOf("<TR")
					: sbLeave.indexOf("<tr");
			sbLeave = new StringBuffer(sbLeave.substring(startIndex));
			endIndex = sbLeave.indexOf("</TR>") != -1 ? sbLeave
					.indexOf("</TR>") : sbLeave.indexOf("</tr>");
			sbTempValue = new StringBuffer(sbLeave.substring(0, endIndex));
			sbLeave = new StringBuffer(sbLeave.substring(endIndex));
			startIndex = sbTempValue.indexOf("<TD") != -1 ? sbTempValue
					.indexOf("<TD") : sbTempValue.indexOf("<td");
			while (startIndex != -1) {
				eventTd++;
				if (eventTd % 2 == 0) {
					allValue.add(getTdStrChange(sbTempValue).toString());
				}
				sbTempValue = getSubChange(sbTempValue);
				startIndex = sbTempValue.indexOf("<TD") != -1 ? sbTempValue
						.indexOf("<TD") : sbTempValue.indexOf("<td");
			}
			eventTd = 0;
		}
	}

	/**
	 * 截取字符串,去掉第一个TD所及所包含的内容
	 * 
	 * @param sbTempValue
	 */
	private StringBuffer getSubChange(StringBuffer sbTempValue) {
		StringBuffer tdValue = null;
		int startIndex;
		int endIndex;
		startIndex = sbTempValue.indexOf("<TD") != -1 ? sbTempValue
				.indexOf("<TD") : sbTempValue.indexOf("<td");
		sbTempValue = new StringBuffer(sbTempValue.substring(startIndex + 1));
		startIndex = sbTempValue.indexOf(">");
		endIndex = sbTempValue.indexOf("</TD") != -1 ? sbTempValue
				.indexOf("</TD") : sbTempValue.indexOf("</td");
		tdValue = new StringBuffer(sbTempValue.substring(endIndex));
		return tdValue;
	}

	/**
	 * 取首个TD中的值,并改变字符
	 * 
	 * @param sbTempValue
	 *            初始字符串,经过本方法后将改变
	 * @return
	 */
	private Object getTdStrChange(StringBuffer sbTempValue) {
		StringBuffer tdValue = null;
		int startIndex;
		int endIndex;
		startIndex = sbTempValue.indexOf("<TD") != -1 ? sbTempValue
				.indexOf("<TD") : sbTempValue.indexOf("<td");
		sbTempValue = new StringBuffer(sbTempValue.substring(startIndex + 1));
		startIndex = sbTempValue.indexOf(">");
		endIndex = sbTempValue.indexOf("</TD>") != -1 ? sbTempValue
				.indexOf("</TD>") : sbTempValue.indexOf("</td>");
		tdValue = new StringBuffer(sbTempValue.substring(startIndex + 1,
				endIndex));
		tdValue = trimValue(tdValue);
		return tdValue;
	}

	/**
	 * 处理获取的数据,转化各种特殊格式
	 * 
	 * @param sbTempValue
	 * @return
	 */
	private StringBuffer trimValue(StringBuffer sbTempValue) {
		StringBuffer sbValue = sbTempValue;
		StringBuffer tempValue = new StringBuffer();
		int start = sbValue.indexOf("value=\"");
		int end = 0;
		if (start != -1) {
			sbValue = new StringBuffer(sbValue.substring(start
					+ "value=\"".length()));
			sbValue = new StringBuffer(sbValue.substring(0,
					sbValue.indexOf("\"")));
		}
		start = sbValue.indexOf("'");
		if (start != -1 && sbValue.indexOf("'>") != -1) {
			sbValue = getSubStr(sbValue, "'", "'>");
		}
		start = sbValue.indexOf("value=");
		if (start != -1) {
			sbValue = new StringBuffer(sbValue.substring(start
					+ "value=".length()));
			sbValue = new StringBuffer(sbValue.substring(0,
					sbValue.indexOf(" ")));
		}
		start = sbValue.indexOf("<FONT") != -1 ? sbValue.indexOf("<FONT")
				: sbValue.indexOf("<font");
		if (start != -1) {
			sbValue = new StringBuffer(
					sbValue.substring(sbValue.indexOf(">") + 1));
			sbValue = new StringBuffer(sbValue.substring(0,
					sbValue.indexOf("<")));
		}
		start = sbValue.indexOf("&nbsp;");
		while (start != -1) {
			tempValue = new StringBuffer(sbValue.substring(0, start));
			tempValue = tempValue.append(""
					+ sbValue.substring(start + "&nbsp;".length()));
			sbValue = new StringBuffer(tempValue);
			start = sbValue.indexOf("&nbsp;");
		}
		if (sbValue.indexOf("<INPUT id=wfxw") != -1
				&& sbValue.indexOf(">") != -1) {
			sbValue = new StringBuffer();
		}
		start = sbValue.indexOf("CHECKED") != -1 ? sbValue.indexOf("CHECKED")
				: sbValue.indexOf("checked");
		tempValue = sbValue;
		if (start != -1) {
			sbValue = new StringBuffer();
		}
		while (start != -1) {
			tempValue = new StringBuffer(tempValue.substring(start));
			start = tempValue.indexOf(">");
			end = tempValue.indexOf("<");
			sbValue.append(new StringBuffer(tempValue.substring(start + 1, end))
					.toString().trim());
			tempValue = new StringBuffer(tempValue.substring(end));
			start = tempValue.indexOf("CHECKED") != -1 ? tempValue
					.indexOf("CHECKED") : tempValue.indexOf("checked");
			if (start != -1) {
				sbValue.append(",");
			}
		}
		return sbValue;
	}

	/**
	 * 获取违法行为数据
	 * 
	 * @param tableStr
	 * @return
	 */
	public ArrayList<ArrayList<String>> getLineActionValue(
			ArrayList<ArrayList<String>> alAllValue, StringBuffer tableStr) {
		ArrayList<String> alStr = null;
		int tdIndex = 0;
		int fromIndex = 0;
		int endIndex = 0;
		StringBuffer tempTableStr = new StringBuffer();
		endIndex = tableStr.indexOf("</TABLE>") != -1 ? tableStr
				.indexOf("</TABLE>") : tableStr.indexOf("</table>");
		tempTableStr = tempTableStr.append(tableStr.substring(0, endIndex));
		while (fromIndex != -1) {
			alStr = new ArrayList<String>();
			fromIndex = tempTableStr.indexOf("<TR") != -1 ? tempTableStr
					.indexOf("<TR") : tempTableStr.indexOf("<tr");
			tdIndex++;
			tempTableStr = new StringBuffer(
					tempTableStr.substring(fromIndex + 1));
			fromIndex = tempTableStr.indexOf("<TR") != -1 ? tempTableStr
					.indexOf("<TR") : tempTableStr.indexOf("<tr");
			if (tdIndex > 1) {
				for (int i = 1; i <= 7; i++) {
					alStr.add(getTdStr(i, tempTableStr).toString());
				}
				alAllValue.add(alStr);
			}
		}
		return alAllValue;
	}

	/**
	 * 获取某两个字符间的数据
	 * 
	 * @param sbPage
	 *            原字符串
	 */
	public StringBuffer getSubStr(StringBuffer sbPage, String startStr,
			String endStr) {
		try {
			int start = sbPage.indexOf(startStr);
			StringBuffer tempSb = null;
			if (start != -1) {
				tempSb = new StringBuffer(sbPage.substring(start
						+ startStr.length()));
				int end = tempSb.indexOf(endStr);
				tempSb = new StringBuffer(tempSb.substring(0, end));
			}
			return tempSb;
		} catch (Exception e) {
			return new StringBuffer("");
		}
	}

	/**
	 * 获取某两个字符间的数据
	 * 
	 * @param sbPage
	 *            原字符串
	 */
	public String getSubStr(String sbPage, String startStr, String endStr) {
		try {
			int start = sbPage.indexOf(startStr);
			String tempSb = null;
			if (start != -1) {
				tempSb = sbPage.substring(start + startStr.length());
				int end = tempSb.indexOf(endStr);
				tempSb = tempSb.substring(0, end);
			}
			//长度限制
//			if(tempSb.length()>50)
//				tempSb=tempSb.substring(0,49);
			
			return tempSb;
		} catch (Exception e) {
			return "";
		}
	}

	/**
	 * 循环取出某两个字符间的字符
	 * 
	 * @param alAllUrls
	 *            存放循环取出的字符串
	 * @param sbPage
	 *            原字符串
	 */
	public void getPageLineUrls(ArrayList<String> alAllUrls,
			StringBuffer sbPage, String startStr, String endStr) {
		int start = 0;
		StringBuffer sbTemp = null;
		while (sbPage.indexOf(startStr) != -1) {
			start = sbPage.indexOf(startStr);
			sbPage = new StringBuffer(sbPage.substring(start
					+ startStr.length()));
			int end = sbPage.indexOf(endStr);
			if (end != -1) {
				sbTemp = new StringBuffer(sbPage.substring(0, end));
				alAllUrls.add(sbTemp.toString());
				sbPage = new StringBuffer(sbPage.substring(end));
			} else {
				break;
			}
		}
	}

	/**
	 * 循环取出某两个字符间的字符
	 * 
	 * @param alAllUrls
	 *            存放循环取出的字符串,去重复
	 * @param sbPage
	 *            原字符串
	 * @return 
	 */
	public ArrayList<String> getPageLines( StringBuffer sbPage,
			String startStr, String endStr) {
		//这个可放重复
		HashSet<String>  has=new HashSet<String>(); 
		int start = 0;
		StringBuffer sbTemp = null;
		while (sbPage.indexOf(startStr) != -1) {
			start = sbPage.indexOf(startStr);
			sbPage = new StringBuffer(sbPage.substring(start
					+ startStr.length()));
			int end = sbPage.indexOf(endStr);
			if (end != -1) {
				sbTemp = new StringBuffer(sbPage.substring(0, end));
				if (sbTemp.indexOf("#") == -1
						&& sbTemp.indexOf("javascript") == -1) {
					//alAllUrls.add(sbTemp.toString());
					has.add(sbTemp.toString());
				}
				sbPage = new StringBuffer(sbPage.substring(end));
			} else {
				break;
			}
		}
		
		return new ArrayList<String>(has); 
	}

	/**
	 * 通过页面源码，获取所有链接
	 * 
	 * @param sb
	 * @return
	 * @throws Exception
	 */
	public ArrayList<String> getLinks(StringBuffer sb) throws Exception {
		ReadPageData readPageData = new ReadPageData();
		ArrayList<String> listStr = new ArrayList<String>();
		listStr.addAll(readPageData.getPageLines( sb, "href='", "'"));
		listStr.addAll(readPageData.getPageLines( sb, "href=\"", "\""));
		listStr.addAll(readPageData.getPageLines( sb, "HREF=\"", "\""));
		listStr.addAll(readPageData.getPageLines( sb, "href=\\\"", "\\\""));
		return listStr;
	}
	/**
	 * 通过页面源码，获取所有链接，更具关键词过滤链接
	 * 
	 * @param sb
	 * @return
	 * @throws Exception
	 */
	public ArrayList<String> getLinks(StringBuffer sb, String urlStr,
			String keyword) throws MalformedURLException {
		//追加前缀,只能http
		if (urlStr.indexOf("http://") == -1 && urlStr.indexOf("HTTP://") == -1) {
			urlStr = "http://" + urlStr;
		}
		/*
		 * URL url=new URL(urlStr); String str = url.getHost(); String[]
		 * str2=str.split("\\."); //System.out.println(str2.length);
		 * str=str2[str2.length-2]+"."+str2[str2.length-1];
		 */
		ReadPageData readPageData = new ReadPageData();
		ArrayList<String> listStr = new ArrayList<String>();
		ArrayList<String> finalStr = new ArrayList<String>();

		listStr.addAll(readPageData.getPageLines( sb, "href='", "'"));
		listStr.addAll(readPageData.getPageLines( sb, "href=\"", "\""));
		listStr.addAll(readPageData.getPageLines( sb, "HREF=\"", "\""));
		listStr.addAll(readPageData.getPageLines( sb, "href=\\\"", "\\\""));
		for (int i = 0; i < listStr.size(); i++) {

			String tempUrl = listStr.get(i);
			// logger.debug("获取到连接："+tempUrl);
			if(tempUrl.startsWith("//")){
				tempUrl = "http:" + tempUrl;
			}
			else if (tempUrl.startsWith("/")) {
				tempUrl = IsTask.generateUrl(urlStr, tempUrl);
			}
			// logger.debug("keyword:"+keyword );
			//Log.debug(keyword.equals("kong"))
			if(keyword != null)
			{
				if (!keyword.equals("kong")) {
					// if (tempUrl.contains(keyword))//使用包含
				     if(tempUrl.matches(keyword)) //使用正则 
					 {
						finalStr.add(tempUrl);
					}
				} else {
					finalStr.add(tempUrl);
				}
			}

		}
		return finalStr;

	}

	/**
	 * 根据关键字，检索页面源码
	 * 
	 * @param sb
	 *            源码
	 * @param keys
	 *            关键字组成关系
	 * @return true为含有关键字，false无关键字
	 * @throws Exception
	 */
	public boolean isMatching(StringBuffer sb, ArrayList<String[]> keys)
			throws Exception {
		boolean returnBl = false;
		if (keys != null && keys.size() > 0 && sb != null && sb.length() > 0) {// 页面源码及关键字不能为空
			for (int i = 0; i < keys.size(); i++) {
				String[] strs = keys.get(i);
		
				if (strs != null && strs.length >= 2
						&& strs[0].trim().equals("1")) {// 关键字为且关系
					if (sb.indexOf(strs[1]) == -1) {
						return false;
					} else {
						returnBl = true;
					}
				} else if (strs != null && strs.length >= 2
						&& strs[0].trim().equals("0")) {
					if (sb.indexOf(strs[1]) != -1) {
						return true;
					}
				} else {
					return false;
				}
			}
			return returnBl;
		}
		return false;
	}

	/**
	 * 根据关键字，检索页面源码
	 * 
	 * @param sb
	 *            源码
	 * @param keys
	 *            关键字组成关系
	 * @return true为含有关键字，false无关键字
	 * @throws Exception
	 */
	public boolean isMatching(StringBuffer sb, String[] keys) throws Exception {
		if (keys != null && keys.length > 0 && sb != null && sb.length() > 0) {// 页面源码及关键字不能为空
			for (int i = 0; i < keys.length; i++) {
				String strs = keys[i];
				if (sb.indexOf(strs) == -1) {
					return false;
				} else {
					return true;
				}
			}
			return false;
		}
		return false;
	}

	/**
	 * 通过页面源码，获取标题
	 * 
	 * @param sb
	 * @return
	 * @throws Exception
	 */
	public StringBuffer getTitle(StringBuffer sb) {
		try {
			ReadPageData readPageData = new ReadPageData();
			StringBuffer sbTitle = readPageData.getSubStr(sb, "<title>",
					"</title>");
			if (sbTitle == null || sbTitle.toString().trim().length() == 0) {
				sbTitle = readPageData.getSubStr(sb, "<TITLE>", "</TITLE>");
			}
			//删除多余字符
			String temptitle =(CommonMethod.getRealCodeFromHtml(sbTitle
					.toString()));
			Pattern p = Pattern.compile("\\s*|\t|\r|\n");
            Matcher m = p.matcher(temptitle);
            sbTitle = new StringBuffer(m.replaceAll(""));
            temptitle=temptitle.toString().replaceAll("<DIV>", "");
            temptitle=temptitle.toString().replaceAll("</DIV>", "");
            temptitle=temptitle.toString().replaceAll("<div>", "");
            temptitle=temptitle.toString().replaceAll("</div>", "");
            
			return new StringBuffer(temptitle);
		} catch (Exception e) {
			return null;
		}
	}

	/**
	 * 链接URL，获取当前页所有连接及数量
	 * 
	 * @param urlstr
	 *            连接
	 * @param keys
	 *            关键字
	 * @return
	 * @throws Exception
	 */
	public ArrayList<String> getLinks(String urlstr, ArrayList<String[]> keys,
			int Level) throws Exception {
		StringBuffer sb = new StringBuffer();
		GetPage getPage = new GetPage();
		sb = getPage.getStringBuffer(urlstr);
		return getLinks(sb);
	}

	/**
	 * 获取列表页面所有处理编号、警员及日期信息
	 * 
	 * @param alJingYuan
	 *            存放警员信息
	 * @param alCode
	 *            存放处理编号
	 * @param alDate
	 *            存放日期
	 * @param sbPage
	 *            页面代码
	 */
	public void getCodeAndJingYuan(ArrayList<String> alJingYuan,
			ArrayList<String> alCode, ArrayList<String> alDate,
			StringBuffer sbPage) {
		ArrayList<String> alString = new ArrayList<String>();
		// 取出警员和日期信息
		getPageLineUrls(alString, sbPage, "<TD height=\"21\">", "</TD>");
		if (alString.size() == 0) {
			getPageLineUrls(alString, sbPage, "<td height=\"21\">", "</td>");
		}
		for (int i = 0; i < alString.size(); i++) {
			if (i % 7 == 6) {
				alJingYuan.add(alString.get(i));
			}
			if (i % 7 == 4) {
				alDate.add(alString.get(i));
			}
		}
		// 取得处理编号
		ArrayList<String> alTr = new ArrayList<String>();
		getPageLineUrls(alTr, getTableStr(4, sbPage), "<tr", "</tr>");
		if (alCode.size() == 0) {
			getPageLineUrls(alTr, getTableStr(4, sbPage), "<TR", "</TR>");
		}
		for (int i = 0; i < alTr.size(); i++) {
			StringBuffer temSb = getSubStr(new StringBuffer(alTr.get(i)),
					"criteria=", "'\"");
			if (temSb == null) {
				temSb = getSubStr(new StringBuffer(alTr.get(i)), "criteria=",
						"\"'");
			} else if (temSb != null) {
				alCode.add(temSb.toString());
			}
		}
	}

	/**
	 * 通过页面源码，获取帖子发表时间
	 * 
	 * @param sb
	 * @return
	 * @throws Exception
	 */
	public Timestamp getPublishTime(StringBuffer sb) {
		try {
			Document doc = Jsoup.parse(sb.toString());
			String content = doc.text();

			String PublishTime = "";
			Pattern p = Pattern.compile("\\d{4}(\\-|\\/|\\.)\\d{1,2}\\1\\d{1,2}");
			Matcher m = p.matcher(content);// 构造匹配器

			if (m.find()) {
				PublishTime = m.group();// 匹配成功
			} else {
				int year = 0;
				int month = 0;
				int day = 0;
				Calendar c = Calendar.getInstance();// 获得系统当前日期
				year = c.get(Calendar.YEAR);
				month = c.get(Calendar.MONTH) + 1;// 系日期从0开始算起
				day = c.get(Calendar.DAY_OF_MONTH);
				PublishTime = year + "-" + month + "-" + day;
			}
			DateFormat dateFormat;
			dateFormat = new SimpleDateFormat("yyyy-MM-dd");// 设定格式
			dateFormat.setLenient(false);// 严格控制输入 比如2010－02－31，根本没有这一天
											// ，也会认为时间格式不对。
			java.util.Date timeDate = dateFormat.parse(PublishTime);// util类型
			Timestamp dateTime = new Timestamp(timeDate.getTime());// Timestamp类型,timeDate.getTime()返回一个long型
			return dateTime;

		} catch (Exception e) {
			return null;
		}

	}

	public String getSiteName(String url) throws IOException {
		if (url.toLowerCase().indexOf("http://") == -1) {
			url = "http://" + url;
		}
		URL urlstr = new URL(url);
		String str = urlstr.getHost();
		Document doc = Jsoup.connect("http://" + str).get();
		String title = doc.title();
		return title;

	}
	
	//雷德诚，用正则表达式获取网址
	public static void getUrlByString(String inputArgs) {
		String tmpStr = inputArgs;

		String regUrl = "(?<=(href=)[\"]?[\']?)(http|https)[^\\s\"\'\\?]*("
		+ "" + ")[^\\s\"\'>]*";
		System.out.println(regUrl);
		//String test2 = 

		Pattern p = Pattern.compile(regUrl,  Pattern.CASE_INSENSITIVE);
		Matcher m = p.matcher(tmpStr);
		boolean blnp = m.find();
		while (blnp == true) {
		ArrayList<String> allUrls = new ArrayList<String>();	
		if (!allUrls.contains(m.group(0))) {
			allUrls.add(m.group(0));
			System.out.println(m.group(0));
			}
			tmpStr = tmpStr.substring(m.end(), tmpStr.length());
			m = p.matcher(tmpStr);
			blnp = m.find();
			
		}
	}

	public static void main(String[] args) throws Exception {
		String test = "http://news.sznews.com/node_173306.htm";
		String mach="[\\S]*html?";
		if(test.matches(mach))
		{
			System.out.println("yes");
		}
		else
		{
		System.out.println("no");
		}
	}

	}


