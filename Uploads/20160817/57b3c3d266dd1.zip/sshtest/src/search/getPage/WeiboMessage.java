package common.search.getPage;

public class WeiboMessage
{
  public String mid;
  public String ouname;
  public String rouid;
  public String weibo;
  public String weibosourse;
  public String weibotitle;
  public String weibocontent;
  public String zhuanfa;
  public String remark;
  public String shoucang;
  public String weibourl;
  public String weibotime;
  
  void WeiboMessage()
  {
    this.mid = "";
    this.ouname = "";
    this.rouid = "";
    this.weibo = "";
    this.weibosourse = "";
    this.weibotitle = "";
    this.weibocontent = "";
    this.zhuanfa = "";
    this.remark = "";
    this.shoucang = "";
    this.weibourl = "";
    this.weibotime = "";
  }
}
