package common.search.getPage;

import java.io.IOException;

import org.apache.log4j.Logger;

import com.gargoylesoftware.htmlunit.WebClient;
import com.gargoylesoftware.htmlunit.WebRequest;
import com.gargoylesoftware.htmlunit.WebResponse;
import com.gargoylesoftware.htmlunit.util.FalsifyingWebConnection;

//修改js返回内容,可吧错误的延迟的js过滤掉(与爬虫内容无关的)
class InterceptWebConnection extends FalsifyingWebConnection{
	
	private Logger logger = Logger.getLogger("yuqinglogger");
	
    public InterceptWebConnection(WebClient webClient) throws IllegalArgumentException{
        super(webClient);
    }
    
    @Override
    public WebResponse getResponse(WebRequest request) throws IOException {
        WebResponse response=super.getResponse(request);
        String temp = response.getWebRequest().getUrl().toString();
        //System.out.println("加载:"+temp);
        if(   // temp.endsWith(".js") &&
        		(
        		temp.contains("logger.js") || 
        		temp.contains("zonedWord.js") || 
        		temp.contains("viewer.js") ||
        		temp.contains("jquery") ||
        		temp.contains("%") ||
        		temp.contains(".swf") ||
        		temp.contains("collect.js") ||
        		temp.contains("search_suggest.js") ||
        		temp.contains("bootstrap.min.js")
        		))
        {
       //   System.out.println("过滤加载:"+temp);
           return createWebResponse(response.getWebRequest(), "", "application/javascript", 200, "Ok");
        }
      //  System.out.println("加载:"+temp);
        return super.getResponse(request);
    }
}
