package service.textinfo;

import common.service.BaseService;
import dao.generated.TextInfo;

public interface TextInfoService extends BaseService<TextInfo> {

}
