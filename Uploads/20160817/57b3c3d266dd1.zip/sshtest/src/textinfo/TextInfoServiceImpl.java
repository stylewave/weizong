package service.textinfo;

import javax.annotation.Resource;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Order;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import common.action.PaginationSupport;
import common.dao.IBaseDAO;
import common.service.AbstractService;
import dao.TextInfo.ITextInfoDAO;
import dao.generated.TextInfo;

@Service("TextInfoService")
public class TextInfoServiceImpl extends AbstractService<TextInfo> implements TextInfoService {

	@Autowired
	private ITextInfoDAO textInfoDAO;

	@Override
	@Resource(name = "textInfoDAO")
	protected void initBaseDAO(IBaseDAO<TextInfo> baseDAO) {
		setBaseDAO(baseDAO);
	}

	@Override
	public PaginationSupport<TextInfo> findPageByCriteria(PaginationSupport<TextInfo> ps, TextInfo t) {
		DetachedCriteria dc = DetachedCriteria.forClass(TextInfo.class);	
		return textInfoDAO.findPageByCriteria(ps,Order.asc("id"), dc);
	}

	@Override
	public void save(TextInfo t) {
		textInfoDAO.save(t);
	}
}
