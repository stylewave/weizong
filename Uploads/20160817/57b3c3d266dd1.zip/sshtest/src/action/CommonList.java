package common.action;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;

import com.opensymphony.xwork2.util.ValueStack;

public class CommonList {
	public static List<KeyValueBean> returnList;

	public List<KeyValueBean> getRoadTypeList() {
		List<KeyValueBean> list = new ArrayList<KeyValueBean>();
		list.add(new KeyValueBean("2", "·��"));
		list.add(new KeyValueBean("3", "·��"));
		return list;
	}
}
