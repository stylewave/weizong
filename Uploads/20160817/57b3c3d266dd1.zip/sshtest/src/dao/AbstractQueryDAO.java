package common.dao;

import java.lang.reflect.ParameterizedType;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.CriteriaSpecification;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Projection;
import org.hibernate.criterion.Projections;
import org.hibernate.impl.CriteriaImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate3.HibernateCallback;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import common.action.PaginationSupport;

public abstract class AbstractQueryDAO<T> extends HibernateDaoSupport implements
		IBaseDAO<T> {
	private Class<T> persistentClass;
	private Logger log = Logger.getLogger("yuqinglogger");

	@SuppressWarnings("unchecked")
	public AbstractQueryDAO() {
		this.persistentClass = (Class<T>) ((ParameterizedType) getClass()
				.getGenericSuperclass()).getActualTypeArguments()[0];
	}

	public Class<T> getPersistentClass() {
		return persistentClass;
	}

	@Autowired
	public void setSessionFactory0(SessionFactory sessionFactory) {
		super.setSessionFactory(sessionFactory);
	}

	/** 带有分页查询以及排序功能的条件查询 */
	@SuppressWarnings("unchecked")
	public PaginationSupport<T> findPageByCriteria(
			final PaginationSupport<T> page, final Order order,
			final DetachedCriteria detachedCriteria) {
		// TODO Auto-generated method stub
		return (PaginationSupport<T>) this.getHibernateTemplate().execute(
				new HibernateCallback() {
					public Object doInHibernate(Session session)
							throws HibernateException, SQLException {
						try {
							List<T> list = new ArrayList<T>();
							Criteria criteria = detachedCriteria
									.getExecutableCriteria(session);
							// 查询条件
							CriteriaImpl impl = (CriteriaImpl) criteria;

							// 先把Projection和OrderBy条件取出来,清空两者来执行Count操作
							Projection projection = impl.getProjection();
							logger.debug("SQL: " + Projections.rowCount());
							criteria.setProjection(Projections.rowCount());
							int totalCount = ((Integer) criteria.setProjection(
									Projections.rowCount()).uniqueResult())
									.intValue();
							criteria.setProjection(projection);
							if (projection == null) {
								criteria.setResultTransformer(CriteriaSpecification.ROOT_ENTITY);
							}
							page.setTotalRows(totalCount);
							if (page.getTotalRows() % page.getPageSize() == 0) {
								page.setTotalPages(page.getTotalRows()
										/ page.getPageSize());
							} else {
								page.setTotalPages(page.getTotalRows()
										/ page.getPageSize() + 1);
							}
							page.setCurrentPage(page.getViewPage());
							if (page.getTotalPages() > page.getCurrentPage()) {
								page.setHasNext(true);
							} else {
								page.setHasNext(false);
							}
							if (page.getCurrentPage() > 1) {
								page.setHasPrevious(true);
							} else {
								page.setHasPrevious(false);
							}
							if (order != null) {
								criteria.addOrder(order);
							}
							criteria.setFirstResult((page.getViewPage() - 1)
									* page.getPageSize());
							criteria.setMaxResults(page.getPageSize());
							page.setResults(criteria.list());
							return page;
						} catch (HibernateException e) {
							e.printStackTrace();
							throw e;
						}
					}
				});
	}

	public void attachDirty(T t) {
		logger.debug("attaching dirty " + t.getClass().getSimpleName()
				+ " instance");
		try {
			getHibernateTemplate().saveOrUpdate(t);
			logger.debug("attach successful");
		} catch (RuntimeException re) {
			logger.error("attach failed", re);
			throw re;
		}
	}

	public void delete(T t) {
		logger.debug("deleting  " + t.getClass().getSimpleName() + "  instance");
		try {
			getHibernateTemplate().delete(t);
			logger.debug("delete successful");
		} catch (RuntimeException re) {
			logger.error("delete failed", re);
			throw re;
		}
	}

	public List<T> findAll() {
		logger.debug("finding all " + persistentClass.getSimpleName()
				+ " instances");
		try {
			String queryString = "from " + persistentClass.getSimpleName();
			return getHibernateTemplate().find(queryString);
		} catch (RuntimeException re) {
			logger.error("find all failed", re);
			throw re;
		}
	}

	public List<T> findByExample(T t) {
		logger.debug("finding " + persistentClass.getSimpleName()
				+ " instance by example");
		try {
			List<T> results = getHibernateTemplate().findByExample(t);
			logger.debug("find by example successful, result size: "
					+ results.size());
			return results;
		} catch (RuntimeException re) {
			logger.error("find by example failed", re);
			throw re;
		}
	}

	public T findById(Integer id) {
		logger.debug("getting " + persistentClass.getSimpleName()
				+ " instance with id: " + id);
		try {
			T instance = (T) getHibernateTemplate().get(getPersistentClass(),
					id);
			return instance;
		} catch (RuntimeException re) {
			logger.error("get failed", re);
			throw re;
		}
	}

	public List<T> findByProperty(String propertyName, Object value) {
		logger.debug("finding " + persistentClass.getSimpleName()
				+ " instance with property: " + propertyName + ", value: "
				+ value);
		try {
			String queryString = "from " + persistentClass.getSimpleName()
					+ " as model where model." + propertyName + "= ?";
			return getHibernateTemplate().find(queryString, value);
		} catch (RuntimeException re) {
			logger.error("find by property name failed", re);
			throw re;
		}
	}

	public List<T> findByProperty(String propertyName, Object value,
			String orderName) {
		logger.debug("finding " + persistentClass.getSimpleName()
				+ " instance with property: " + propertyName + ", value: "
				+ value + " order by " + orderName);
		try {
			String queryString = "from " + persistentClass.getSimpleName()
					+ " as model where model." + propertyName + "= ?"
					+ " order by " + orderName;
			return getHibernateTemplate().find(queryString, value);
		} catch (RuntimeException re) {
			logger.error("find by property name failed", re);
			throw re;
		}
	}

	public T merge(T t) {
		logger.debug("merging " + persistentClass.getSimpleName() + " instance");
		try {
			T result = (T) getHibernateTemplate().merge(t);
			logger.debug("merge successful");
			return result;
		} catch (RuntimeException re) {
			logger.error("merge failed", re);
			throw re;
		}
	}

	public void save(T t) {
		logger.debug("saving " + persistentClass.getSimpleName() + " instance");
		try {
			getHibernateTemplate().save(t);
			logger.debug("save successful");
		} catch (RuntimeException re) {
			logger.error("save failed", re);
			throw re;
		}
	}

	public List<T> findByCriteria(DetachedCriteria detachedCriteria) {
		return getHibernateTemplate().findByCriteria(detachedCriteria);
	}

	public Session getCurrentSession() {
		Session session = getHibernateTemplate().getSessionFactory()
				.getCurrentSession();
		if (session == null) {
			session = getHibernateTemplate().getSessionFactory().openSession();
		}
		return session;
	}

}
