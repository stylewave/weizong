package common.dao;

public interface ICommonDAO {
}
