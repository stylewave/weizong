package common;

import java.util.List;

import org.aopalliance.intercept.MethodInterceptor;
import org.aopalliance.intercept.MethodInvocation;
public class AuthorityInterceptor implements MethodInterceptor {
	private List<String> methodList;
	public static boolean validateRy = false;

	public List<String> getMethodList() {
		return methodList;
	}

	public void setMethodList(List<String> methodList) {
		this.methodList = methodList;
	}

	public Object invoke(MethodInvocation invocation) throws Throwable {
		// if(!validateRy){ 
		// validateRy = ValidateRy3.validate();
		// if(!validateRy){
		// throw new Exception("请插入授权的USBKEY!");
		// }
		// }
		// String methodName = invocation.getMethod().getName();
		// if(ActionContext.getContext()!=null &&
		// ActionContext.getContext().getSession()!=null &&
		// ActionContext.getContext().getSession().get("type")!=null){
		// Integer type =
		// Integer.parseInt(ActionContext.getContext().getSession().get("type").toString());
		// //普通用户不允许增、删、改
		// if(type.equals(0) ){
		// for (String str : methodList) {
		// if(methodName.trim().equalsIgnoreCase(str)){
		// throw new Exception("对不起，你没有该操作权限",new Throwable("test"));
		// }
		// }
		// }
		// }
		return invocation.proceed();
	}
}
