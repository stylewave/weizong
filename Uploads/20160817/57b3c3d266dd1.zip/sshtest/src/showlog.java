package show;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class showlog {
	   private List<String[]> log = new ArrayList<String[]>();
	   //全国省坐标
	   private   String[][] province = new String[][]{
			   {"0","jiangsu","620","336"},
			   {"1","hangzhou","624","410"},
			   {"2","hefei","600","386"},
			   {"3","zhengzhou","550","350"},
			   {"4","taiyuan","530","280"},
			   {"5","huhehaote","530","180"},
			   {"6","xian","480","300"},
			   {"7","wuchang","510","400"},
			   {"8","nanchang","570","450"},
			   {"9","changsha","550","450"},
			   {"10","guiyang","470","450"},
			   {"11","nanning","470","520"},
			   {"12","chongqing","470","390"},
			   {"13","chengdu","400","390"},
			   {"14","kunming","376","520"},
			   {"15","lanzhou","400","320"},
			   {"16","xining","340","320"},
			   {"17","wulumuqi","200","250"},
			   {"18","shenzhen","572","532"},
			   {"19","guangzhou","566","528"},
			   {"20","shanghai","660","384"},
			   {"21","beijing","574","240"},
			   {"22","hainan","510","600"},
			   {"23","taiwan","676","500"},
			   {"24","jinan","612","300"},
			   {"25","fuzhou","622","480"}
	   };
	   
	   //网址对应省市
	   private   String[][] position =  new String[][]{ 
			   //北京
			   {"sina.com.cn","21"},
			   {"sohu.com","21"},
			   {"china.com","21"},
			   {"people.com.cn","21"},
			   {"news.xinhuanet.com","21"},
			   {"ifeng.com","21"},
			   {"huanqiu.com","21"},
			   {"news.baidu.com","21"},
			   {"huanqiu.com","21"},
			   //深圳
			   {"qq.com","18"},
			   {"news.sznews.com","18"},
			   //广州
			   {"gdjct.gd.gov.cn","19"},
			   {"163.com","19"},
			   //上海
			   {"xinmin.cn","20"},
			   };
	   

	   public showlog()
	   {
		   String logdir;
		   String x="my test";
		   int ram=0;
		   String[] tempadd =  new String[6];
		   logdir=System.getProperty("catalina.home")+"\\mylogs\\yuqing.log";
		  // logdir="C:\\Tomcat\\mylogs\\yuqing.log";
		   System.out.println("log路径:"+logdir);//user.dir指定了当前的路径 
		   BufferedReader yuqinglog;
	        try {
	        	
	        	 yuqinglog = new BufferedReader(new FileReader(logdir));
				while ((x=yuqinglog.readLine()) != null) {
					//System.out.println(x);
					tempadd = x.trim().split(":;");
					if(tempadd.length==4)//符合规格才有坐标
					{
						//new Random().nextInt(5)
						tempadd=(x.trim()+":;0:;0".toString()).split(":;");
						ram = new Random().nextInt(province.length);
						tempadd[4]=String.valueOf((Integer.valueOf(province[ram][2]))+new Random().nextInt(4)-2);//x坐标
						tempadd[5]=String.valueOf((Integer.valueOf(province[ram][3]))+new Random().nextInt(4)-2);//y坐标
						for(int j=0;j<position.length;j++ )
						{
							if(tempadd[2].contains(position[j][0]))
							{
								tempadd[4]=String.valueOf((Integer.valueOf(province[Integer.valueOf(position[j][1])][2]))+new Random().nextInt(4)-2);//x坐标
								tempadd[5]=String.valueOf((Integer.valueOf(province[Integer.valueOf(position[j][1])][3]))+new Random().nextInt(4)-2);//y坐标
								break;
							}
						}
					}
					log.add(tempadd);
					
				}
				yuqinglog.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	        
	        
	    }
	   public static void main(String args[])
	   {
		   new showlog();
	   }
		public List<String[]> getLog() {
			return log;
		}
		public void setLog(List<String[]> log) {
			this.log = log;
		}
		

}
