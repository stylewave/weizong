package common.service;

public interface CommonService {
	public Integer getNextKey(final String tablename, final int count);
}
