package common.service;

import java.util.List;

import org.hibernate.criterion.DetachedCriteria;
import org.springframework.beans.factory.annotation.Autowired;

import common.action.PaginationSupport;
import common.dao.IBaseDAO;

/**
 * @author Administrator
 * 
 * @param <T>
 */
public abstract class AbstractService<T> implements BaseService<T> {
	private IBaseDAO<T> baseDAO;
	@Autowired
	private CommonService commonService;

	public Integer getNextKey(final String tablename, final int count) {
		return commonService.getNextKey(tablename, count);
	}

	public void attachDirty(T t) {
		// TODO Auto-generated method stub
		baseDAO.attachDirty(t);
	}

	public void deletes(String[] IDS) {
		// TODO Auto-generated method stub
		for (String id : IDS) {
			getBaseDAO().delete(getBaseDAO().findById(Integer.parseInt(id)));
		}
	}

	public List<T> findAll() {
		// TODO Auto-generated method stub
		return getBaseDAO().findAll();
	}

	public List<T> findByExample(T t) {
		// TODO Auto-generated method stub
		return getBaseDAO().findByExample(t);
	}

	public T findById(Integer id) {
		// TODO Auto-generated method stub
		return getBaseDAO().findById(id);
	}

	public List<T> findByProperty(String propertyName, Object propertyValue) {
		// TODO Auto-generated method stub
		return getBaseDAO().findByProperty(propertyName, propertyValue);
	}

	public List<T> findByProperty(String propertyName, Object propertyValue,
			String orderPropertyName) {
		return getBaseDAO().findByProperty(propertyName, propertyValue,
				orderPropertyName);
	}

	public PaginationSupport<T> findPageByCriteria(PaginationSupport<T> ps, T t) {
		// TODO Auto-generated method stub
		throw new RuntimeException("请重写findPageByCriteria方法");
	}

	public void save(T t) {
		// TODO Auto-generated method stub
		getBaseDAO().save(t);
	}

	public void delete(T t) {
		getBaseDAO().delete(t);
	}

	public void initList(T t) {
		throw new RuntimeException("请重写initList方法");
	}

	protected void initBaseDAO(IBaseDAO<T> baseDAO) {
		setBaseDAO(baseDAO);
	}

	public IBaseDAO<T> getBaseDAO() {
		return baseDAO;
	}

	public void setBaseDAO(IBaseDAO<T> baseDAO) {
		this.baseDAO = baseDAO;
	}

	public List<T> findByCriteria(DetachedCriteria detachedCriteria) {
		return baseDAO.findByCriteria(detachedCriteria);
	}
}
