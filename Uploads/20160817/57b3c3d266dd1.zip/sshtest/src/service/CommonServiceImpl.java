package common.service;

import org.springframework.beans.factory.annotation.Autowired;

import common.dao.ICommonDAO;

public class CommonServiceImpl implements CommonService {
	@Autowired
	private ICommonDAO commonDAO;

	public Integer getNextKey(String tablename, int count) {
		return null;
	}
}
