package dao.information;

import java.sql.SQLException;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.springframework.orm.hibernate3.HibernateCallback;
import org.springframework.stereotype.Repository;
import common.dao.AbstractQueryDAO;
import dao.generated.Information;

@Repository("informationDAO")
public class InformationExtendDAO extends AbstractQueryDAO<Information>
		implements IInformationDAO {

	@Override
	public void deleteRepeat() {
		getHibernateTemplate().execute(new HibernateCallback() {
			@Override
			public Object doInHibernate(Session session)
					throws HibernateException, SQLException {
				//去重
				String sql = "delete from Information where id not in (select max(id) from Information t1 group by t1.url)";
				// String sql2 =
				// "delete from post_information where id not in (select max(postId) from post_information t1 group by t1.url,t1.projectId)";
				Query query = session.createQuery(sql);
				// Query query2 = session.createQuery(sql2);
				query.executeUpdate();
//				try{
//				String sql1 = "select Top 10 * FROM information";
//				Query query1 = session.createQuery(sql1);
//				query1.executeUpdate();
//				}catch (Exception e) {
//					// TODO: handle exception
//					e.printStackTrace();
//				}
				return null;
			}
		});
	}
}