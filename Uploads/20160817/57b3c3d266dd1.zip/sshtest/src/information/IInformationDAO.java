package dao.information;

import common.dao.IBaseDAO;
import dao.generated.Information;

public interface IInformationDAO extends IBaseDAO<Information> {

	void deleteRepeat();

}