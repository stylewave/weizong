package service.information;

import java.util.ArrayList;
import java.util.List;

import service.textinfo.TextInfoService;
import common.search.getPage.WeiboMessage;
import common.service.BaseService;
import dao.generated.Information;
import dao.generated.Project;
import dao.generated.TabInformationSource;

public interface InformationService extends BaseService<Information> {

	List<String> saveAndGetLinks(TabInformationSource tabInformationSource);
	void saveAndGetLinks(String s, TextInfoService textInfoService, int m);

	List<String> saveAndGetLinksByProject(String url, String siteName,
			String keyword, TextInfoService textinfoService);
	public void saveWeibo(ArrayList<WeiboMessage> paramArrayList, TextInfoService textInfoService)
		    throws InterruptedException;
	void deleteRepeat();
}