package service.information;

import action.timer.ThreadPool;
import action.timer.GetTimeWords;
import com.gargoylesoftware.htmlunit.FailingHttpStatusCodeException;
import com.ibm.icu.text.SimpleDateFormat;
import common.action.PaginationSupport;
import common.dao.IBaseDAO;
import common.search.getPage.GetPage;
import common.search.getPage.ReadPageData;
import common.search.getPage.WeiboMessage;
import common.service.AbstractService;
import dao.generated.Information;
import dao.generated.Managers;
import dao.generated.Project;
import dao.generated.SiteTimeWords;
import dao.generated.TabInformationSource;
import dao.generated.TextInfo;
import dao.information.IInformationDAO;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Queue;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.annotation.Resource;
import org.apache.log4j.Logger;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import service.textinfo.TextInfoService;

@Service("informationService")
public class InformationServiceImpl extends AbstractService<Information>
implements InformationService
{

	private static int GTL = 10;
	private static int GTLS = 30;
	@Autowired
	private IInformationDAO informationDAO;
	private Logger logger = Logger.getLogger("yuqinglogger");
	@Resource(name="informationDAO")
	protected void initBaseDAO(IBaseDAO<Information> baseDAO)
	{
		setBaseDAO(baseDAO);
	}
  
	public PaginationSupport<Information> findPageByCriteria(PaginationSupport<Information> ps, Information t)
	{
		DetachedCriteria dc = DetachedCriteria.forClass(Information.class);
		return this.informationDAO.findPageByCriteria(ps, Order.asc("informationId"), dc);
	}
  
	public void save(Information t)
	{
		System.out.println("public void save(Information t)");
		if ((t != null) && (t.getTextContent() != null) && 
				(!t.getTextContent().trim().equals(""))) {
			this.informationDAO.save(t);
		}
	}

	public List<String> saveAndGetLinks(TabInformationSource tabInformationSource)
	{
		System.out.println("public List<String> saveAndGetLinks");
		try
		{
			String url = tabInformationSource.getUrl();
			if ((url != null) && (!url.trim().equals("")))
			{
				if (url.toLowerCase().indexOf("http") == -1) 
				{
					url = "http://" + url;
				}
				GetPage getPage = new GetPage();
				StringBuffer sb = getPage.getStringBuffer2(url.trim());
				ReadPageData readPageData = new ReadPageData();
				System.out.println("源地址:" + url);
				System.out.println("getKeyword:" + tabInformationSource.getKeyword());
				ArrayList<String> arrayList2 = readPageData.getLinks(sb, url, tabInformationSource.getKeyword());
				this.logger.debug("获取起点url中所有连接(" + url + ")共" + arrayList2.size() + "个");
				return arrayList2;
			}
			return null;
		}
		catch (Exception e)
		{
     	 e.printStackTrace();
		}
		return null;
	}
  
	public static ArrayList<String[]> getKeys(String keyStr)
	{
		if ((keyStr != null) && (!keyStr.trim().equals("")))
		{
			ArrayList<String[]> arrayList = new ArrayList<String[]>();
			keyStr = keyStr.replace("(", "");
			keyStr = keyStr.replace(")", "");
      
			String tempStr = "";
			int tempAnd = keyStr.indexOf("+");
			int tempOr = keyStr.indexOf("|");
			if ((!keyStr.startsWith("+")) && (!keyStr.startsWith("|"))) {
				if (tempAnd > tempOr) {
					keyStr = "+" + keyStr;
				} else {
					keyStr = "|" + keyStr;
				}
			}
			boolean isread = true;
			while (isread)
			{
				int and = keyStr.indexOf("+");
				int or = keyStr.indexOf("|");
				String[] keys = new String[2];
				if ((and == -1) && (or == -1))
				{
					keys[0] = "1";
					keys[1] = keyStr;
					if ((keys == null) || (keys[1] == null) || 
							(keys[1].trim().equals(""))) {
						break;
					}
					arrayList.add(keys);
					break;
				}
				if (and == 0)
				{
					keys[0] = "1";
					tempStr = keyStr.substring(1);
					tempAnd = tempStr.indexOf("+");
					tempOr = tempStr.indexOf("|");
					if ((tempAnd == -1) && (tempOr == -1))
					{
						keys[1] = tempStr;
						keyStr = "";
					}
					else if (tempAnd == -1)
					{
						keys[1] = tempStr.substring(0, tempOr);
						keyStr = tempStr.substring(tempOr);
					}
					else if (tempOr == -1)
					{
						keys[1] = tempStr.substring(0, tempAnd);
						keyStr = tempStr.substring(tempAnd);
					}
					else if (tempAnd < tempOr)
					{
						keys[1] = tempStr.substring(0, tempAnd);
						keyStr = tempStr.substring(tempAnd);
					}
					else
					{
						keys[1] = tempStr.substring(0, tempOr);
						keyStr = tempStr.substring(tempOr);
					}
				}
				else
				{
					keys[0] = "0";
					tempStr = keyStr.substring(1);
					tempAnd = tempStr.indexOf("+");
					tempOr = tempStr.indexOf("|");
					if ((tempAnd == -1) && (tempOr == -1))
					{
						keys[1] = tempStr;
						keyStr = "";
					}
					else if (tempAnd == -1)
					{
						keys[1] = tempStr.substring(0, tempOr);
						keyStr = tempStr.substring(tempOr);
					}
					else if (tempOr == -1)
					{
						keys[1] = tempStr.substring(0, tempAnd);
						keyStr = tempStr.substring(tempAnd);
					}
					else if (tempAnd < tempOr)
					{
						keys[1] = tempStr.substring(0, tempAnd);
						keyStr = tempStr.substring(tempAnd);
					}
					else
					{
						keys[1] = tempStr.substring(0, tempOr);
						keyStr = tempStr.substring(tempOr);
					}
				}
				if ((keys != null) && (keys[1] != null) && 
						(!keys[1].trim().equals(""))) {
					arrayList.add(keys);
				}
			}
			return arrayList;
		}
		return null;
	}
  
	public static void main(String[] args) {
//		try
//		{
//		  	String url = "http://www.foodmate.net/law/dongtai/187767.html";
//		  	String content = "";
//	        org.jsoup.nodes.Document doc = Jsoup.connect(url).get();
//	        try{
//	        		doc = Jsoup.connect(url).get();
//	        		Element singerListDiv = doc.getElementsByAttributeValue("class", "info").first();  
//	        	// String elements2 = singerListDiv.select("a").first().text();
//	        	// String str = matchDateString(singerListDiv.text().toString());
//	        	 //System.out.println(elements2);
//	        	// System.out.println(singerListDiv.text().replace("来源：", "").replace("参与互动", "").replace(str, ""));
//	        		if(singerListDiv.toString().contains("作者"))
//	        		System.out.println(singerListDiv.text().substring(singerListDiv.text().indexOf("来源："), singerListDiv.text().indexOf("作者：")).replace("来源：", "").trim());
//	        	 else
//	        		 System.out.println(singerListDiv.text().substring(singerListDiv.text().indexOf("来源："), singerListDiv.text().indexOf("浏览：")).replace("来源：", "").trim());
//	        }catch (Exception e) {
//				// TODO: handle exception
//			}
//	    	//System.out.println(content);
//	    }catch (Exception e) {
//			// TODO: handle exception
//	    	e.printStackTrace();
//		}
		
		/***********************测试转载量*****************************************/
		 Date dateN = new Date();
		 System.out.println(dateN.getDay());
		 System.out.println(GetTimeWords.GetPublicTime("20160316").getDay());
		System.out.println((dateN.getTime()-GetTimeWords.GetPublicTime("20160316").getTime()) / (1000 * 60 * 60 * 24));
		
		/*********************************************************************************************/		
	}
  
	public boolean isMatchingbody(StringBuffer sb, ArrayList<String[]> keys) throws Exception
	{
		boolean returnBl = false;
		if ((keys != null) && (keys.size() > 0) && (sb != null) && (sb.length() > 0))
		{
			for (int i = 0; i < keys.size(); i++)
			{
				String[] strs = (String[])keys.get(i);
				if ((strs != null) && (strs.length >= 2) && (strs[0].trim().equals("1")))
				{
					if (sb.indexOf(strs[1]) == -1) {
						return false;
					}
					returnBl = true;
				}
				else if ((strs != null) && (strs.length >= 2) && 
						(strs[0].trim().equals("0")))
				{
					if (sb.indexOf(strs[1]) != -1) {
						return true;
					}
				}
				else
				{
					return false;
				}
			}
			return returnBl;
		}
		return false;
	}
  
	public String GetPageBody(StringBuffer sb)
	{
		String content = "";
		content = ContentExtractor.getContentByHtml(sb.toString());
		return content;
	}
  
	public List<String> saveAndGetLinks(String url, Project project)
	{
		//System.out.println("public List<String> saveAndGetLinks(String url, Project project)");
		try
		{
			String conditionalExpression = project.getConditionalExpression();
			ArrayList<String[]> arrayList = getKeys(conditionalExpression);
			if ((url != null) && (!url.trim().equals("")) && (arrayList != null) && (arrayList.size() > 0))
			{
				if (url.toLowerCase().indexOf("http") == -1) {
					url = "http://" + url;
				}
				GetPage getPage = new GetPage();
				StringBuffer sb = getPage.getStringBuffer(url.trim());
				int charcheck = sb.indexOf("charset=") + 8;
				String charStr = sb.substring(charcheck, charcheck + 10);
				System.out.println("charStr:" + charStr);
				if ((charStr.contains("GBK")) || 
						(charStr.contains("gbk")) || 
						(charStr.contains("\"GBK\"")) || 
						(charStr.contains("\"gbk\"")) || 
						(charStr.contains("\"gb2312\"")) || 
						(charStr.contains("\"GB2312\"")) || 
						(charStr.contains("GB2312")) || 
						(charStr.contains("gb2312"))) 
				{
					sb = getPage.getStringBuffer(url.trim(), "GBK");
				} else if (charStr.contains("BIG5")) {
					sb = getPage.getStringBuffer(url.trim(), "BIG5");
				}
				ReadPageData readPageData = new ReadPageData();
        
				String PageBody = GetPageBody(sb);
				if (PageBody != null)
				{
					StringBuffer sb1 = new StringBuffer(PageBody);
					String title = readPageData.getTitle(sb).toString();
					if (title == null) {
						return null;
					}
					if (title.toString().length() > 200) {
						title = title.toString().substring(0, 200);
					}
					if (isMatchingbody(sb1, arrayList))
					{
						List<Information> informations = this.informationDAO.findByProperty("url", url.trim());
						if ((informations != null) && (informations.size() > 0))
						{
							Information t = (Information)informations.get(0);
							Date date = new Date();
							t.setRefreshTime(new Timestamp(date.getTime()));
							t.setTextContent(sb.toString());
							if ((t != null) && (t.getTextContent() != null) && 
									(!t.getTextContent().trim().equals(""))) {
								this.informationDAO.attachDirty(t);
							}
						}
						else
						{
							Information t = new Information();
							t.setUrl(url.trim());
							if (title != null) {
								t.setTitle(title.toString());
							}
							Date date = new Date();
							t.setRefreshTime(new Timestamp(date.getTime()));
							t.setTextContent(sb.toString());
							if ((t != null) && (t.getTextContent() != null) && 
									(!t.getTextContent().trim().equals(""))) {
								this.informationDAO.save(t);
							}
						}
					}
					return readPageData.getLinks(sb);
				}
			}
			else
			{
				return null;
			}
		}
		catch (Exception e)
		{
			return null;
		}
		return null;
	}
  
  public int IsManager(String title, String sitename)//判断舆情内容是否包含有领导信息
  {
	  try{
		  Queue<Managers> queues = new ConcurrentLinkedQueue<Managers>();
		  queues.addAll(ThreadPool.managers);
		  while (!queues.isEmpty())
		  {
		      Managers manager = (Managers)queues.poll();
		      if(title.contains(manager.getProjectName()) || sitename.contains(manager.getProjectName()))
		      {
		    	  return 0;
		      }
		  }		  
		  
	  }catch (Exception e) {
		// TODO: handle exception
		  e.printStackTrace();
	  }
	  	return 1;
  }

  /*******************************************************************************************************************/
  //获取元搜索爬虫的网页内容
  /*******************************************************************************************************************/
  @SuppressWarnings("unused")
  public void saveAndGetLinks(String url, TextInfoService textInfoService, int m)
  {
	  try
	  {
		  if ((url != null) && (!url.trim().equals("")))
		  {
			  if (url.toLowerCase().indexOf("http") == -1)
			  {
				  url = "http://" + url;
			  }
			  System.out.println(url);
			  org.jsoup.nodes.Document doc=null;
			  ReadPageData readPageData = new ReadPageData();
			  try{
				  doc = Jsoup.connect(url).get();
			  }catch(Exception e)
			  {
				  //e.printStackTrace();
			  }
			  if(doc==null)
				  return;
			  StringBuffer sb = new StringBuffer(doc.toString());
			  if( sb == null )
				  return;
			  String title = readPageData.getTitle(sb).toString().trim();
			  if(title == null)
				  return;
			  title = title.replaceAll("&nbsp", " ");
			  String PageBody = GetPageBody(sb);
			  String[] Abstracts = PageBody.split("\n");
			  PageBody="";
			  for(int i=0; i<= Abstracts.length*2/3; i++){
				  PageBody += Abstracts[i];
			  }
			  String content = GetAbstract(sb.toString());
			  StringBuffer sb1 = new StringBuffer(title+PageBody);
			  System.out.println("摘要："+content);
			  if(!url.contains("blog.sina.com.cn")){
				  if (PanduanUrl(url) == null) {
        			return;
				  }
			  }
			  if (title.toString().length() > 200) {
				  return;
			  }
			  //  System.out.println("标题："+title);
			  String WebClass = "";
			  if ((url.contains("opinion")) || (url.contains("/pl/")) || (url.contains("pinglun"))||(url.contains("zhsd"))||
					  (url.contains("view.")) || (url.contains("star.")) || (url.contains("comments"))) {
				  WebClass = "评论";
			  }else if ((url.contains("tieba")) || (url.contains("bbs")) || (url.contains("blog")) || (url.contains("forum")) || (url.contains("club"))) {
				  WebClass = "博客";
			  }else if ((url.contains("weibo")) || (url.contains("t.qq.com"))) {
				  WebClass = "微博";
			  } else if ((url.contains("news")) || (url.contains("roll")) || (url.contains("gdjct.gd.gov.cn"))) {
				  WebClass = "新闻";
			  } else {
				  WebClass = "其他";
			  }
      
			  /********************************获取 新闻时间****************************************/
			  String gettime = GetTimeWords.matchDateString(GetTimeWords.GetTimeInString(doc.toString()));
			  if(gettime==null || gettime=="")
			  {
				  gettime = GetTimeWords.matchDateString(doc.toString());
				  if(gettime!=null || gettime!="")
				  {
					  Date date1 = new Date();
					  if(GetTimeWords.GetPublicTime(gettime)==null)
						  return;
					  if((date1.getTime()-GetTimeWords.GetPublicTime(gettime).getTime())/(1000*60*60) <2)
						  return;
				  }
				  else
				  {
					  return;
				  }
			  }
			  if(gettime==null || gettime=="")
			  {
				  return;
			  }
			  System.out.println("获取到的时间："+gettime);
			
			  /************************************************************************************/  
			  
			  /********************获取领导舆情信息***************************************************/
			  if(IsManager(title, content)==0)//如果是领导信息，就进行保存
	          {
	          	 GetManagerMsg( url,  title,  content,  PageBody,  WebClass, GetTimeWords.GetPublicTime(gettime), textInfoService);
	          	// return;
	          }
			  /************************************************************************************/
			  
			  Queue<Project> queue = new ConcurrentLinkedQueue<Project>();
			  queue.addAll(ThreadPool.projects);
			  while (!queue.isEmpty())
			  {
				  Project project = (Project)queue.poll();
				  String conditionalExpression = project.getConditionalExpression();
				  ArrayList<String[]> arrayList = getKeys(conditionalExpression);
				  if ((arrayList != null) && (arrayList.size() > 0) && isMatchingbody(sb1, arrayList))
				  {         
					  List<Information> informations = this.informationDAO.findByProperty("url", url.trim());
					  if ((informations != null) && (informations.size() > 0))
					  {
						  this.logger.info("修改链接:;" + url.trim() + ":;" + title.toString());
						  Date dateN = new Date();
						  long DivTime = (dateN.getTime()-GetTimeWords.GetPublicTime(gettime).getTime()) / (1000 * 60 * 60 * 24);
						  if(DivTime > GTLS)//获取七天以内的数据
						  {
							  return;
						  }
						  Information t = (Information)informations.get(0);
						  String tempget = GetZhuanzailiang(title);//获取转载量
						  if (tempget != null)
						  {
							  t.setIsCheck(Integer.valueOf(tempget.trim()));
						  } 
						  t.setTextContent(sb.toString());
						  Date date = new Date();
						  t.setRefreshTime(new Timestamp(date.getTime()));
						  if ((t != null) && (t.getTextContent() != null) && (!t.getTextContent().trim().equals(""))) {
							  this.informationDAO.attachDirty(t);
						  }
					  }
					  else
					  {
						  Information t = new Information();
						  t.setUrl(url.trim());
						  if (title != null) {
							  t.setTitle(title.toString());
						  }
						 
						  Date date = new Date();
						  if(GetTimeWords.GetPublicTime(gettime)==null)
							  return;
						  /*****************判断舆情信息发布时间是否在限制的时间范围之外********************************/
						  long DivTime = (date.getTime()-GetTimeWords.GetPublicTime(gettime).getTime()) / (1000 * 60 * 60 * 24);
						  if(DivTime > GTL)//获取七天以内的数据
						  {
							  return;
						  }
						  if(GetTimeWords.GetPublicTime(gettime).compareTo(date)>0)
						  {
							  return;
						  }
						  
						  /****************************************************************************************/
						  String tempget = GetZhuanzailiang(title);//获取转载量
						  if (tempget != null)
						  {
							  t.setIsCheck(Integer.valueOf(tempget.trim()));
						  } 
				          Timestamp t1 = GetTimeWords.GetPublicTime(gettime);
				          t.setSubmissionTime(t1);
				          t.setPublishTime(t1);
				          t.setRefreshTime(new Timestamp(date.getTime()));
				          t.setGetTime(new Timestamp(date.getTime()));
				          t.setTextContent(sb.toString());
				          t.setSitename(content);
				          t.setTextAddress(WebClass);
				          String MediaBroadcast = title.replaceAll("[|]", "-");
				          MediaBroadcast = MediaBroadcast.replaceAll("--", "-");
				          MediaBroadcast = MediaBroadcast.replaceAll("_", "-");
				          String[] MediaBroadcasts = MediaBroadcast.split("-");
				          this.logger.info("增加链接:;" + url.trim() + ":;" + title);
				          if(MediaBroadcasts[(MediaBroadcasts.length - 1)].length()>8)
					      {
				        	  if(MediaBroadcasts.length<2)
				        		  return;
				        	  else
				        		  t.setWebsiteAddress(MediaBroadcasts[(MediaBroadcasts.length - 2)]);//媒体来源
					      }
				          else 
				          {
				          		t.setWebsiteAddress(MediaBroadcasts[(MediaBroadcasts.length - 1)]);
				          }
				          if ((t != null) && (t.getTextContent() != null) && (!t.getTextContent().trim().equals("")) &&
				            (t.getSubmissionTime() != null) && t.getWebsiteAddress().length()<8 && Integer.valueOf(tempget.trim())>0)
				          {
				        	  if(sb1.toString().contains("广东")||sb1.toString().contains("深圳")||sb1.toString().contains("检验检疫")
				        			  ||sb1.toString().contains("违法") ||sb1.toString().contains("被查") ||sb1.toString().contains("违纪")||sb1.toString().contains("质检"))
				        	  {
				        		  this.logger.info("增加链接:;" + url.trim() + ":;" + title);
				        		  this.informationDAO.save(t);
				        	  }
				        	  
				          }
					  }
				  }
			  } 
		  }
	  }
	  catch (Exception e) 
	  {
		  e.printStackTrace();
	  }
  }
  
  public static String getFilts(String html, String MyString, String Myregex)
  {
	  String Nextregex = ";;";
	  String NextStr = "";
	  String foundSt = "";String foundSt2 = "";
	  if (!MyString.contains(Myregex)) {
		  return "";
	  }
	  ReadPageData readPageData = new ReadPageData();
	  String[] spltsNext = MyString.split(Nextregex);
	  System.out.println("spltsNext.length=" + spltsNext.length);
	  for (int i = 0; i < spltsNext.length; i++)
	  {
		  NextStr = spltsNext[i];
		  String[] splts = NextStr.split(Myregex);
		  foundSt = "";
		  foundSt2 = "";
		  if (splts.length >= 2) {
			  foundSt = readPageData.getSubStr(html, splts[0], splts[1]);
		  }
		  if (splts.length == 4)
		  {
			  foundSt2 = readPageData.getSubStr(foundSt, splts[2], splts[3]).trim();
			  if ((foundSt2 != null) && (foundSt2.length() > 0)) {
				  foundSt = foundSt2;
			  }
		  }
		  if ((foundSt != null) && (foundSt.length() > 0)) {
			  break;
		  }
	  }
	  if (foundSt == null) {
		  foundSt = "";
	  }
	  if (foundSt.trim().length() > 50) {
		  foundSt = "";
	  }
	  System.out.println("foundSt=" + foundSt.length() + "|" + foundSt);
	  return foundSt.trim();
  }
  
  public static String getFilts1(String html, String MyString, String Myregex)
  {
	  String Nextregex = ";;";
	  String NextStr = "";
	  String foundSt = "";String foundSt2 = "";
	  ReadPageData readPageData = new ReadPageData();
	  String[] spltsNext = MyString.split(Nextregex);
	  for (int i = 0; i < spltsNext.length; i++)
	  {
		  NextStr = spltsNext[i];
		  String[] splts = NextStr.split(Myregex);
		  foundSt = "";
		  foundSt2 = "";
		  if (splts.length >= 2) {
			  foundSt = readPageData.getSubStr(html, splts[0], splts[1]);
		  }
		  if (splts.length == 4)
		  {
			  foundSt2 = readPageData.getSubStr(foundSt, splts[2], splts[3]);
			  if ((foundSt2 != null) && (foundSt2.length() > 0)) {
				  foundSt = foundSt2;
			  } else {
				  foundSt = null;
			  }
		  }
		  if ((foundSt != null) && (foundSt.length() > 0)) {
			  break;
		  }
	  }
	  if (foundSt == null) {
		  foundSt = "";
	  }
	  return foundSt;
  }
  
  public void GetManagerMsg(String url, String title, String sitename, String textContent, String WebClass, Timestamp time, TextInfoService textInfoService)
  {
	  try{
		  String tempget = GetZhuanzailiang(title);//获取转载量
		  DetachedCriteria dc = DetachedCriteria.forClass(TextInfo.class);
	      dc.add(Restrictions.eq("url", url));
	      List<TextInfo> textinfos = textInfoService.findByCriteria(dc);
	      if(textinfos !=null && textinfos.size() > 0)
	      {
	    	 // System.out.println(textinfos.get(0).getUrl());
	    	  Date dateN = new Date();
			  long DivTime = (dateN.getTime()-time.getTime()) / (1000 * 60 * 60 * 24);
			  if(DivTime > GTLS)//获取七天以内的数据
			  {
				  return;
			  }
	    	  TextInfo t = textinfos.get(0);
	    	  Date date = new Date();
			  t.setRefreshTime(new Timestamp(date.getTime()));
			  if (tempget != null)
			  {
				  t.setIsCheck(Integer.valueOf(tempget.trim()));//写入转载量
			  } 
			  if ((t != null) && (t.getTextContent() != null) && (!t.getTextContent().trim().equals(""))) 
			  {
				  textInfoService.attachDirty(t);
			  }
	      }
	      else
	      {
	    	  TextInfo t=new TextInfo(); 
			  Date date = new Date();
			  long DivTime = (date.getTime()-time.getTime()) / (1000 * 60 * 60 * 24);
			  if(DivTime > GTL)//获取七天以内的数据
			  {
				  return;
			  }
			  t.setRefreshTime(new Timestamp(date.getTime()));
			  t.setGetTime(time);
			  t.setSubmissionTime(time);
			  if (tempget != null)
			  {
				  t.setIsCheck(Integer.valueOf(tempget.trim()));
			  } 
			  String MediaBroadcast = title.replaceAll("[|]", "-");
			  MediaBroadcast = MediaBroadcast.replaceAll("--", "-");
			  MediaBroadcast = MediaBroadcast.replaceAll("_", "-");
			  String[] MediaBroadcasts = MediaBroadcast.split("-");
		      if(MediaBroadcasts[(MediaBroadcasts.length - 1)].length()>8)
		      {
		    	  if(MediaBroadcasts.length<2)
		    		  return;
		    	  else
		    		  t.setWebsiteAddress(MediaBroadcasts[(MediaBroadcasts.length - 2)]);//媒体来源
		        }
		        else
		        	t.setWebsiteAddress(MediaBroadcasts[(MediaBroadcasts.length - 1)]);
		      
		      t.setUrl(url);
		      t.setTitle(title);//标题
		      t.setTextContent(textContent);//正文
		      if (sitename.length() >= 1000)  
		    	  t.setSitename(sitename.substring(0, 600).trim() + "……");
		      else  
		    	  t.setSitename(sitename.trim());
		      t.setTextAddress(WebClass);//类型
		      if ((t != null) && (t.getTextContent() != null) && (!t.getTextContent().trim().equals("")) 
		        		&&  (t.getSubmissionTime() != null) && t.getWebsiteAddress().length()<8)
		      {
		    	  textInfoService.save(t);
		      }
	      }
	  }catch (Exception e) {
		  // TODO: handle exception
		  e.printStackTrace();
	  }
  }

  public static String GetZhuanzailiang(String title)
    throws UnsupportedEncodingException
  {
	  String[] names = title.split("[|]");
	  names = names[0].split("--");
	  names = names[0].split("_");
	  names = names[0].split("-");
	  title = names[0];
	  String queryString = URLEncoder.encode(title, "utf-8");
	  queryString = queryString.replace("%7C", "+%7C+");
	  String tempget = "0";
	  try
	  {
		  String urls = "http://news.haosou.com/ns?q=" + queryString;
		  GetPage getPages = new GetPage();
		  StringBuffer buffers = getPages.getStringBuffer(urls);
		  String sbStrs = buffers.toString();
      
		  String ZhuanzaiLiang = "<ul class=\"result\" id=\"news\">:;class=\"comment\">加入讨论:;[相关新闻：:;]";
		  if ((ZhuanzaiLiang != null) && 
				  ((tempget = getFilts1(sbStrs, ZhuanzaiLiang, ":;").trim()).length() > 0))
		  {
			  System.out.println("开始元搜索，关键词2:" + tempget.toString());
			  return tempget;
		  }
	  }
	  catch (FailingHttpStatusCodeException e)
	  {
		  e.printStackTrace();
		  return "0";
	  }
    return "0";
  }
  
  public String GetAbstract(String str)
  {
	  String content = "";
	  content = ContentExtractor.getContentByHtml(str);
	  content = content + "\n" + "。";
	  String[] Abstract3 = content.split("\n");
	  for (int i = 0; i < Abstract3.length; i++) {
		  Pattern p = Pattern.compile("\\s+");
		  Matcher m = p.matcher(Abstract3[i]);
		  Abstract3[i]= m.replaceAll(" ");
		  if (Abstract3[i].trim().length() > 25)
		  {
			  content = Abstract3[i];
			  String endtag = Abstract3[i].substring(Abstract3[i].length()-2, Abstract3[i].length());
			  if(!endtag.contains("。"))
			  {
				  for(int n=i+1; n<i+5; n++ )
				  {
					  if(Abstract3[n].contains("。"))
					  {
						  content += Abstract3[n];
						  break;
					  }
					  else
					  {
						  content += Abstract3[n];
					  }
				  }
			  }
			  break;
		  }
	  }
	  content = content.replaceAll("[?][?][?][?][?]", "");
	  content = content.replaceAll("[?][?][?][?]", "");
	  content = content.replaceAll("[?][?][?]", "");
	  content = content.replaceAll("[?][?]", "");
	  return content;
  }
  
  public String getNowDay()
  {
	  SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
	  return formatter.format(new Date());
  }
  
  public String PanduanUrl(String url)
  {
    if (url.contains("news.163.com"))
    {
      String[] MediaBroadcasts = url.split("[/]");
      if (MediaBroadcasts.length < 6) {
        return null;
      }
      for (int i = 0; i < MediaBroadcasts.length; i++)
      {
        if (MediaBroadcasts[i].equals("news.163.com"))
        {
          String Times = "20" + MediaBroadcasts[(i + 1)] + "-" + MediaBroadcasts[(i + 2)].substring(0, 2) + "-" + 
            MediaBroadcasts[(i + 2)].substring(2, 4);
          if ((GetTimeWords.matchDateString(Times) != null) && (GetTimeWords.matchDateString(Times).length() > 0)) {
            return "有效";
          }
          return null;
        }
      }
    }
    if (url.contains("gdjct.gd.gov.cn"))
    {
      if (url.contains("index")) {
        return null;
      }
      if ((url.contains("ffkb")) || (url.contains("zhyw"))) {
        return "有效";
      }
    }
    if (((url.contains("201")) && (getNowDay().contains("201"))) || ((url.contains("202")) && (getNowDay().contains("202")))) {
      return "有效";
    }
    return null;
  }
  /*******************************************************************************************************************/
  //获取专题爬虫的网页内容
  /*******************************************************************************************************************/
  @SuppressWarnings("unused")
  public List<String> saveAndGetLinksByProject(String url, String siteName, String keyword, TextInfoService textInfoService)
  {
	  try
	  {
		  if ((url != null) && (!url.trim().equals("")))
		  {
			  if (url.toLowerCase().indexOf("http") == -1) {
				  url = "http://" + url; 
			  }
			  System.out.println("链接："+ url);
			  org.jsoup.nodes.Document doc = null;
			  try{
				  doc = Jsoup.connect(url).get();//获取网页内容
			  }catch (Exception e) {
				  return null;
				  //e.printStackTrace();
				  // TODO: handle exception
			  }
			  if(doc==null)
			  {
				  return null;
			  }
			  StringBuffer sb = new StringBuffer(doc.toString());
			  String PageBody = ContentExtractor.getContentByHtml(sb.toString());//获取正文内容
			  String[] Abstracts = PageBody.split("\n");
			  PageBody="";
			  for(int i=0; i<= Abstracts.length*3/4; i++){
				  PageBody += Abstracts[i];
			  }
			  ReadPageData readPageData = new ReadPageData();
			  String title = readPageData.getTitle(sb).toString().trim();
			  System.out.println("正文内容："+PageBody);
			  if (PageBody != null && PageBody.length()>20)
			  {
				  StringBuffer sb1 = new StringBuffer(title+PageBody);
				  if (PanduanUrl(url) == null) {
					  return null;
				  }
				  if (title.toString().length() > 200) {
					  return null;
				  }
				  String Sitename = GetAbstract(sb.toString());//获取摘要
				  if(Sitename.contains("href")||Sitename.length()<10){
					  return null;
				  }
				  /********************************获取 新闻时间****************************************/
				  String gettime = GetTimeWords.matchDateString(GetTimeWords.GetTimeInString(doc.toString()));
				  if(gettime==null || gettime=="")
				  {
					  gettime = GetTimeWords.matchDateString(doc.toString());
					  if(gettime!=null || gettime!="")
					  {
						  Date date1 = new Date();
						  if(GetTimeWords.GetPublicTime(gettime)==null)
							  return null;
						  if((date1.getTime()-GetTimeWords.GetPublicTime(gettime).getTime())/(1000*60*60) <2)
							  return null;
					  }
					  else
					  {
						  return null;
					  }
				  }
				  if(gettime==null || gettime=="")
					  return null;
				 // System.out.println("获取到的时间："+gettime);
				  /************************************************************************************/  
				  String WebClass = "";//舆情信息的类型
				  if ((url.contains("opinion")) || (url.contains("/pl/")) || (url.contains("pinglun")) || (url.contains("zhsd"))||
						  (url.contains("view")) || (url.contains("star")) || (url.contains("comments"))) {
					  WebClass = "评论";
				  } else if ((url.contains("weibo")) || (url.contains("t.qq.com"))) {
					  WebClass = "微博";
				  } else if ((url.contains("tieba")) || (url.contains("bbs")) || (url.contains("forum")) || (url.contains("club"))) {
					  WebClass = "博客";
				  } else if ((url.contains("news")) || (url.contains("roll")) || (url.contains("gdjct.gd.gov.cn"))) {
					  WebClass = "新闻";
				  }  
				  else {
					  WebClass = "其他";
				  }
				  /********************获取领导舆情信息***************************************************/
				  if(IsManager(title, Sitename)==0)//如果是领导信息，就进行保存
		          {
		          	 GetManagerMsg( url,  title,  Sitename,  PageBody,  WebClass, GetTimeWords.GetPublicTime(gettime), textInfoService);
		          	 return null;
		          }
				  /************************************************************************************/
				  
				  Queue<Project> queue = new ConcurrentLinkedQueue<Project>();
				  queue.addAll(ThreadPool.projects);
				  while (!queue.isEmpty())//进入判断舆情信息是否符合专题要求
				  {
					  Project project = (Project)queue.poll();
					  String conditionalExpression = project.getConditionalExpression();
					  String projectID = project.getId();
					  ArrayList<String[]> arrayList = getKeys(conditionalExpression);
					  String tempget = "";
					  if ((arrayList != null) && (arrayList.size() > 0) && (isMatchingbody(sb1, arrayList)))
					  {
						  DetachedCriteria dc = DetachedCriteria.forClass(Information.class);
						  dc.add(Restrictions.eq("url", url.trim()));
						  dc.addOrder(Order.desc("id"));
						  List<Information> informations = this.informationDAO.findByCriteria(dc);
						  if ((informations != null) && (informations.size() > 0))
						  {
							  this.logger.info("修改链接:;" + url.trim() + ":;" + title.toString());
							  Date date = new Date();
							  long DivTime = (date.getTime()-GetTimeWords.GetPublicTime(gettime).getTime()) / (1000 * 60 * 60 * 24);
							  if(DivTime > GTLS)//获取七天以内的数据
							  {
								  return null;
							  }
							  Information t = (Information)informations.get(0);
							  tempget = GetZhuanzailiang(title);
							  if (tempget != null)
							  {
								  t.setIsCheck(Integer.valueOf(tempget.trim()));
							  } 
							  t.setTitle(title.toString());
							
							  t.setRefreshTime(new Timestamp(date.getTime()));
							  if ((t != null) && (t.getTextContent() != null) && (!t.getTextContent().trim().equals("")))
							  {
								  this.logger.info("修改链接:;" + url.trim() + ":;" + title.toString());
								  this.informationDAO.attachDirty(t);
								  break;
							  }
						  }
						  else
						  {
							  Information t = new Information();
							  t.setUrl(url.trim());
							  t.setSitename(Sitename);
							  t.setTitle(title.toString());
							  t.setTextAddress(WebClass);
							  this.logger.info("增加链接:;" + url.trim() + ":;" + title.toString());
							  Date date = new Date();
							  if(GetTimeWords.GetPublicTime(gettime).compareTo(date)>0)//去掉比超前的时间
							  {
								  return null;
							  }
							  long DivTime = (date.getTime()-GetTimeWords.GetPublicTime(gettime).getTime()) / (1000 * 60 * 60 * 24);
							  if(DivTime > GTL)//获取七天以内的数据
							  {
								  return null;
							  }
							  tempget = GetZhuanzailiang(title);//获取转载量
							  if (tempget != null)
							  {
								  t.setIsCheck(Integer.valueOf(tempget.trim()));
							  } 
							  Timestamp t1 = GetTimeWords.GetPublicTime(gettime);
							  t.setSubmissionTime(t1);
							  t.setPublishTime(t1);
							  t.setRefreshTime(new Timestamp(date.getTime()));
							  t.setTextContent(sb.toString());
							  t.setProjectId(projectID);
							  t.setGetTime(new Timestamp(date.getTime()));
							  String MediaBroadcast = title.replaceAll("[|]", "-");
							  MediaBroadcast = MediaBroadcast.replaceAll("--", "-");
							  MediaBroadcast = MediaBroadcast.replaceAll("_", "-");
							  String[] MediaBroadcasts = MediaBroadcast.split("-");
							  if(MediaBroadcasts[(MediaBroadcasts.length - 1)].length()>8)
							  {
								  if(MediaBroadcasts.length<2)
									  return null;
								  else
									  t.setWebsiteAddress(MediaBroadcasts[(MediaBroadcasts.length - 2)]);//媒体来源
							  }
							  else
								  t.setWebsiteAddress(MediaBroadcasts[(MediaBroadcasts.length - 1)]);
							  if ((t != null) && (t.getTextContent() != null) && (!t.getTextContent().trim().equals("")) 
									  &&  (t.getSubmissionTime() != null) && t.getWebsiteAddress().length()<8
									  && Integer.valueOf(tempget.trim())>0)
							  {
								  if(sb1.toString().contains("广东")||sb1.toString().contains("深圳")||sb1.toString().contains("检验检疫")||sb1.toString().contains("香港")
					        			  ||sb1.toString().contains("违法") ||sb1.toString().contains("被查") ||sb1.toString().contains("违纪")||sb1.toString().contains("质检"))
					        	  {
					        		  this.logger.info("增加链接:;" + url.trim() + ":;" + title);
					        		  this.informationDAO.save(t);
					        		  break;
					        	  }
							  }
						  }
					  }
				  }
				  return readPageData.getLinks(sb, url, keyword);
			  }
		  }
		  else
		  {
			  return null;
		  }
	  }
	  catch (Exception e)
	  {
		  System.out.println(e);
		  return null;
	  }
	  return null;
  }
  

  	public void deleteRepeat()
  	{
  		try
  		{
  			this.informationDAO.deleteRepeat();
  		}
  		catch (Exception e)
  		{
  			this.logger.debug("去掉重复url出错:" + e.getMessage());
  		}
  	} 
  
  public void saveWeibo(ArrayList<WeiboMessage> messages, TextInfoService textInfoService) throws InterruptedException
  {
    
    System.out.println("通过数据：" + messages.size());
    for (int i = 0; i < messages.size(); i++)
    {
      WeiboMessage value = (WeiboMessage)messages.get(i);
      if(IsManager(value.weibotitle, value.weibo)==0)//如果是领导信息，就进行保存
      {
      	 GetManagerMsg( value.weibourl,  value.weibotitle,  value.weibo,  value.weibo,  "新浪微博", GetTimeWords.GetPublicTime(value.weibotime), textInfoService);
      	 continue;
      }
      StringBuffer sb1 = new StringBuffer(value.weibotitle+value.weibo);
      Queue<Project> queue = new ConcurrentLinkedQueue<Project>();
      queue.addAll(ThreadPool.projects);
      while (!queue.isEmpty())
      {
        Project project = (Project)queue.poll();
        String conditionalExpression = project.getConditionalExpression();
        ArrayList<String[]> arrayList = getKeys(conditionalExpression);
        try {
			if ((arrayList != null) && (arrayList.size() > 0) && isMatchingbody(sb1, arrayList))
			{
				if ((value.weibourl != null) && (value.weibourl.trim().length() > 0) && (value.zhuanfa != null) && 
				        (value.weibotime != null) && (value.weibotime.trim().length() > 0))
				    {
						DetachedCriteria dc = DetachedCriteria.forClass(Information.class);
				        dc.add(Restrictions.eq("url", value.weibourl.trim()));
				        List<Information> informations = this.informationDAO.findByCriteria(dc);
				        if ((informations != null) && (informations.size() > 0))
				        {
				          System.out.println("Url存在");
				          Information t = (Information)informations.get(0);
				          t.setCommentCount(value.remark);
				          Date date = new Date();
				          long DivTime = (date.getTime()-GetTimeWords.GetPublicTime(value.weibotime).getTime()) / (1000 * 60 * 60 * 24);
						  if(DivTime > GTLS)//获取七天以内的数据
						  {
							  return;
						  }
				          t.setRefreshTime(new Timestamp(date.getTime()));
				          if ((t != null) && (t.getTextContent() != null) && (!t.getTextContent().trim().equals(""))) 
				          {
				            try
				            {
				              this.informationDAO.attachDirty(t);
				            }
				            catch (Exception e)
				            {
				              e.printStackTrace();
				            }
				          }
				        }
				        else
				        {
				          System.out.println("Url不存在");
				         // System.out.println("微博时间："+value.weibotime);
				          Information t = new Information();
				          Date date = new Date();
				          long DivTime = (date.getTime()-GetTimeWords.GetPublicTime(value.weibotime).getTime()) / (1000 * 60 * 60 * 24);
						  if(DivTime > GTL)//获取七天以内的数据
						  {
							  return;
						  }
				          t.setRefreshTime(new Timestamp(date.getTime()));
				          t.setGetTime(GetTimeWords.GetPublicTime(value.weibotime));
				          t.setSubmissionTime(GetTimeWords.GetPublicTime(value.weibotime));
				          t.setPublishTime(GetTimeWords.GetPublicTime(value.weibotime));
				          t.setUrl(value.weibourl);
				          t.setIsCheck(Integer.valueOf(value.zhuanfa.trim()));
				          
				          if (value.weibo.length() >= 1000) {
				            t.setSitename(value.weibo.substring(0, 300).trim() + "……");
				          } 
				          else 
				          {
				            t.setSitename(value.weibo.trim());
				          }
				          t.setCommentCount(value.remark);
				          t.setReprintCount(value.zhuanfa);
				          t.setTextContent(value.weibocontent);
				          t.setWebsiteAddress("新浪微博");
				          if(t.getSitename().length()>30)
				          {
				        	  t.setTitle(t.getSitename().substring(0, 30)+ "……--"+value.weibotitle);
				          }
				          else
				          {
				        	  t.setTitle(t.getSitename()+ "--"+value.weibotitle);
				          }
				          t.setTextAddress("微博");
				          //System.out.println(t.getTextContent());
				          System.out.println("weiboTime"+t.getSubmissionTime());
				          System.out.println(t.getIsCheck());
				          if ((t != null) && (t.getTextContent() != null) && (!t.getTextContent().trim().equals("")) &&  (t.getSubmissionTime() != null) ) {
				            try
				            {
				              this.informationDAO.save(t);
				            }
				            catch (Exception e)
				            {
				              e.printStackTrace();
				            }
				          }
				      }
				  }
			}
		}
        catch (Exception e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
      }
    }
  }
}
