package show;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class showsele {
	   private List<String[]> log = new ArrayList<String[]>();
	   

	   public showsele()
	   {
		   String logdir;
		   String x="my test";
		   String[] tempadd =  new String[4];
		  // logdir=System.getProperty("catalina.home")+"\\mylogs\\yuqing.log";
		   logdir="C:\\Tomcat\\mylogs\\yuqing.log";
		   System.out.println("log路径:"+logdir);//user.dir指定了当前的路径 
		   RandomAccessFile yuqinglog = null;
		   
		   	File file = new File(logdir);
	        if (!file.exists() || file.isDirectory() || !file.canRead())
	        {
	            return ;
	        }
	        else
	        {
	        	 
					//开始读取
					try {
						yuqinglog = new RandomAccessFile(file,"r");
			        	 long length = yuqinglog.length();
		                 long pos = length - 1;
		                 int count=0;
	                     int numRead=10;
			        
			      
			        	
			        	
			        	
			             //如果是0，代表是空文件，直接返回空结果
			             if (length == 0L)
			             {
			                 return ;
			             }
						while (pos > 0) {
							pos--;
							yuqinglog.seek(pos);
							if (yuqinglog.readByte() == '\n')
							{
						//保存结果

		                  //使用readLine获取当前行
		                    String line = yuqinglog.readLine();
		                    
		                    //打印当前行
		                    System.out.println(line);
							tempadd = line.trim().split(":;");
							if(tempadd.length==4)
							{
								tempadd[2]=String.valueOf((new Random()).nextInt(500)+50);
								tempadd[3]=String.valueOf((new Random()).nextInt(300)+50);
								System.out.println(tempadd[3]);
						
							}
						//	System.out.println(tempadd.length);
							log.add(tempadd);
							//System.out.println(tempadd);
							 count++;
							//行数统计，如果到达了numRead指定的行数，就跳出循环
	                        
							if (count == numRead)
	                        {
	                            break;
	                        }
						}
							
					}
						if (pos == 0)
		                {
							yuqinglog.seek(0);
							log.add(yuqinglog.readLine().trim().split(":;"));
		                }
						
						
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					finally
					{
			            if (yuqinglog != null)
			            {
			                try
			                {
			                    //关闭资源
			                	yuqinglog.close();
			                }
			                catch (Exception e)
			                {
			                }
			            }
					}
				}

				
	        
	        
	        
	    }
	   public static void main(String args[])
	   {
		   new showsele();
	   }
		public List<String[]> getLog() {
			return log;
		}
		public void setLog(List<String[]> log) {
			this.log = log;
		}
		

}
