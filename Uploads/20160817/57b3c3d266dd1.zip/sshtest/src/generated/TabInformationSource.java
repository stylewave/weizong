package dao.generated;

import java.sql.Timestamp;

/**
 * TabInformationSource entity. @author MyEclipse Persistence Tools
 */

public class TabInformationSource implements java.io.Serializable {

	// Fields

	private String id;
	private String url;
	private String siteName;
	private Integer state;
	private Integer priority;
	private Timestamp creationTime;
	private Timestamp refreshTime;
	private Integer updateCycle;
	private String creatorId;
	private Integer limitProject;
	private Integer limitSearch;
	private String keyword;

	// Constructors

	public String getKeyword() {
		return keyword;
	}

	public void setKeyword(String keyword) {
		this.keyword = keyword;
	}

	/** default constructor */
	public TabInformationSource() {
	}

	/** full constructor */
	public TabInformationSource(String url, Integer state, Integer priority,
			Timestamp creationTime, Timestamp refreshTime, Integer updateCycle,
			String creatorId, Integer limitProject, Integer limitSearch,
			String keyword) {
		this.url = url;
		this.state = state;
		this.priority = priority;
		this.creationTime = creationTime;
		this.refreshTime = refreshTime;
		this.updateCycle = updateCycle;
		this.creatorId = creatorId;
		this.limitProject = limitProject;
		this.limitSearch = limitSearch;
		this.keyword = keyword;
	}

	// Property accessors

	public String getId() {
		return this.id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getUrl() {
		return this.url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public Integer getState() {
		return this.state;
	}

	public void setState(Integer state) {
		this.state = state;
	}

	public Integer getPriority() {
		return this.priority;
	}

	public void setPriority(Integer priority) {
		this.priority = priority;
	}

	public Timestamp getCreationTime() {
		return this.creationTime;
	}

	public void setCreationTime(Timestamp creationTime) {
		this.creationTime = creationTime;
	}

	public Timestamp getRefreshTime() {
		return this.refreshTime;
	}

	public void setRefreshTime(Timestamp refreshTime) {
		this.refreshTime = refreshTime;
	}

	public Integer getUpdateCycle() {
		return this.updateCycle;
	}

	public void setUpdateCycle(Integer updateCycle) {
		this.updateCycle = updateCycle;
	}

	public String getCreatorId() {
		return this.creatorId;
	}

	public void setCreatorId(String creatorId) {
		this.creatorId = creatorId;
	}

	public Integer getLimitProject() {
		return this.limitProject;
	}

	public void setLimitProject(Integer limitProject) {
		this.limitProject = limitProject;
	}

	public Integer getLimitSearch() {
		return this.limitSearch;
	}

	public void setLimitSearch(Integer limitSearch) {
		this.limitSearch = limitSearch;
	}

	public String getSiteName() {
		return siteName;
	}

	public void setSiteName(String siteName) {
		this.siteName = siteName;
	}

}