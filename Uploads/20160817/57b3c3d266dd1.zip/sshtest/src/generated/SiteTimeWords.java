package dao.generated;

/**
 * SiteTimeWords entity. @author MyEclipse Persistence Tools
 */
public class SiteTimeWords extends AbstractSiteTimeWords implements
		java.io.Serializable {

	// Constructors

	/** default constructor */
	public SiteTimeWords() {
	}

	/** minimal constructor */
	public SiteTimeWords(Integer id) {
		super(id);
	}

	/** full constructor */
	public SiteTimeWords(Integer id, String site, String timeword1,
			String timeword2, String timeword3) {
		super(id, site, timeword1, timeword2, timeword3);
	}

}
