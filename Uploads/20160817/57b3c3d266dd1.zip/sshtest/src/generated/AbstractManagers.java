package dao.generated;

import java.sql.Timestamp;

/**
 * AbstractManagers entity provides the base persistence definition of the
 * Managers entity. @author MyEclipse Persistence Tools
 */

public abstract class AbstractManagers implements java.io.Serializable {

	// Fields

	private String id;
	private String projectName;
	private String conditionalExpression;
	private Timestamp creationTime;
	private String creatorId;
	private Timestamp startTime;
	private Timestamp endTime;
	private String createUserName;
	private String updateUserId;
	private String updateUserName;
	private Timestamp updateDate;

	// Constructors

	/** default constructor */
	public AbstractManagers() {
	}

	/** full constructor */
	public AbstractManagers(String projectName, String conditionalExpression,
			Timestamp creationTime, String creatorId, Timestamp startTime,
			Timestamp endTime, String createUserName, String updateUserId,
			String updateUserName, Timestamp updateDate) {
		this.projectName = projectName;
		this.conditionalExpression = conditionalExpression;
		this.creationTime = creationTime;
		this.creatorId = creatorId;
		this.startTime = startTime;
		this.endTime = endTime;
		this.createUserName = createUserName;
		this.updateUserId = updateUserId;
		this.updateUserName = updateUserName;
		this.updateDate = updateDate;
	}

	// Property accessors

	public String getId() {
		return this.id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getProjectName() {
		return this.projectName;
	}

	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}

	public String getConditionalExpression() {
		return this.conditionalExpression;
	}

	public void setConditionalExpression(String conditionalExpression) {
		this.conditionalExpression = conditionalExpression;
	}

	public Timestamp getCreationTime() {
		return this.creationTime;
	}

	public void setCreationTime(Timestamp creationTime) {
		this.creationTime = creationTime;
	}

	public String getCreatorId() {
		return this.creatorId;
	}

	public void setCreatorId(String creatorId) {
		this.creatorId = creatorId;
	}

	public Timestamp getStartTime() {
		return this.startTime;
	}

	public void setStartTime(Timestamp startTime) {
		this.startTime = startTime;
	}

	public Timestamp getEndTime() {
		return this.endTime;
	}

	public void setEndTime(Timestamp endTime) {
		this.endTime = endTime;
	}

	public String getCreateUserName() {
		return this.createUserName;
	}

	public void setCreateUserName(String createUserName) {
		this.createUserName = createUserName;
	}

	public String getUpdateUserId() {
		return this.updateUserId;
	}

	public void setUpdateUserId(String updateUserId) {
		this.updateUserId = updateUserId;
	}

	public String getUpdateUserName() {
		return this.updateUserName;
	}

	public void setUpdateUserName(String updateUserName) {
		this.updateUserName = updateUserName;
	}

	public Timestamp getUpdateDate() {
		return this.updateDate;
	}

	public void setUpdateDate(Timestamp updateDate) {
		this.updateDate = updateDate;
	}

}