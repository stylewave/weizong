package dao.generated;

import java.sql.Timestamp;

/**
 * TextInfo entity. @author MyEclipse Persistence Tools
 */

public class TextInfo implements java.io.Serializable {

	// Fields

	private String id;
	private String url;
	private String title;
	private String texttitle;
	private String textAddress;
	private String websiteAddress;
	private String textContent;
	private Timestamp refreshTime;
	private Integer isCheck;
	private String checkSubmit;
	private String commentCount;
	private String sitename;
	private Timestamp submissionTime;
	private Timestamp getTime;

	// Constructors

	/** default constructor */
	public TextInfo() {
	}

	/** minimal constructor */
	public TextInfo(String id) {
		this.id = id;
	}

	/** full constructor */
	public TextInfo(String id, String url, String title, String texttitle,
			String textAddress, String websiteAddress, String textContent,
			Timestamp refreshTime, Integer isCheck, String checkSubmit,
			String commentCount, String sitename, Timestamp submissionTime,
			Timestamp getTime) {
		this.id = id;
		this.url = url;
		this.title = title;
		this.texttitle = texttitle;
		this.textAddress = textAddress;
		this.websiteAddress = websiteAddress;
		this.textContent = textContent;
		this.refreshTime = refreshTime;
		this.isCheck = isCheck;
		this.checkSubmit = checkSubmit;
		this.commentCount = commentCount;
		this.sitename = sitename;
		this.submissionTime = submissionTime;
		this.getTime = getTime;
	}

	// Property accessors

	public String getId() {
		return this.id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getUrl() {
		return this.url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public String getTitle() {
		return this.title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getTexttitle() {
		return this.texttitle;
	}

	public void setTexttitle(String texttitle) {
		this.texttitle = texttitle;
	}

	public String getTextAddress() {
		return this.textAddress;
	}

	public void setTextAddress(String textAddress) {
		this.textAddress = textAddress;
	}

	public String getWebsiteAddress() {
		return this.websiteAddress;
	}

	public void setWebsiteAddress(String websiteAddress) {
		this.websiteAddress = websiteAddress;
	}

	public String getTextContent() {
		return this.textContent;
	}

	public void setTextContent(String textContent) {
		this.textContent = textContent;
	}

	public Timestamp getRefreshTime() {
		return this.refreshTime;
	}

	public void setRefreshTime(Timestamp refreshTime) {
		this.refreshTime = refreshTime;
	}

	public Integer getIsCheck() {
		return this.isCheck;
	}

	public void setIsCheck(Integer isCheck) {
		this.isCheck = isCheck;
	}

	public String getCheckSubmit() {
		return this.checkSubmit;
	}

	public void setCheckSubmit(String checkSubmit) {
		this.checkSubmit = checkSubmit;
	}

	public String getCommentCount() {
		return this.commentCount;
	}

	public void setCommentCount(String commentCount) {
		this.commentCount = commentCount;
	}

	public String getSitename() {
		return this.sitename;
	}

	public void setSitename(String sitename) {
		this.sitename = sitename;
	}

	public Timestamp getSubmissionTime() {
		return this.submissionTime;
	}

	public void setSubmissionTime(Timestamp submissionTime) {
		this.submissionTime = submissionTime;
	}

	public Timestamp getGetTime() {
		return this.getTime;
	}

	public void setGetTime(Timestamp getTime) {
		this.getTime = getTime;
	}

}