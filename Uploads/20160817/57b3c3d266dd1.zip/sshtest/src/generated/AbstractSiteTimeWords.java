package dao.generated;

/**
 * AbstractSiteTimeWords entity provides the base persistence definition of the
 * SiteTimeWords entity. @author MyEclipse Persistence Tools
 */

public abstract class AbstractSiteTimeWords implements java.io.Serializable {

	// Fields

	private Integer id;
	private String site;
	private String timeword1;
	private String timeword2;
	private String timeword3;

	// Constructors

	/** default constructor */
	public AbstractSiteTimeWords() {
	}

	/** minimal constructor */
	public AbstractSiteTimeWords(Integer id) {
		this.id = id;
	}

	/** full constructor */
	public AbstractSiteTimeWords(Integer id, String site, String timeword1,
			String timeword2, String timeword3) {
		this.id = id;
		this.site = site;
		this.timeword1 = timeword1;
		this.timeword2 = timeword2;
		this.timeword3 = timeword3;
	}

	// Property accessors

	public Integer getId() {
		return this.id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getSite() {
		return this.site;
	}

	public void setSite(String site) {
		this.site = site;
	}

	public String getTimeword1() {
		return this.timeword1;
	}

	public void setTimeword1(String timeword1) {
		this.timeword1 = timeword1;
	}

	public String getTimeword2() {
		return this.timeword2;
	}

	public void setTimeword2(String timeword2) {
		this.timeword2 = timeword2;
	}

	public String getTimeword3() {
		return this.timeword3;
	}

	public void setTimeword3(String timeword3) {
		this.timeword3 = timeword3;
	}

}