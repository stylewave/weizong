package dao.generated;

import java.sql.Timestamp;

/**
 * TsNews entity. @author MyEclipse Persistence Tools
 */
public class TsNews extends AbstractTsNews implements java.io.Serializable {

	// Constructors

	/** default constructor */
	public TsNews() {
	}

	/** minimal constructor */
	public TsNews(String typeId, String newsTitle, String state, Boolean isTop,
			Boolean isDiscuss, Boolean isPic, Integer numPic,
			Integer numDiscuss, String createUserId, String createUserName,
			Timestamp createDate) {
		super(typeId, newsTitle, state, isTop, isDiscuss, isPic, numPic,
				numDiscuss, createUserId, createUserName, createDate);
	}

	/** full constructor */
	public TsNews(String typeId, String newsTitle, String intro,
			String contents, String mainPic, Integer clickNum, String state,
			Boolean isTop, Boolean isDiscuss, Boolean isPic, Integer numPic,
			Integer numDiscuss, String createUserId, String createUserName,
			Timestamp createDate, String updateUserId, String updateUserName,
			Timestamp updateDate) {
		super(typeId, newsTitle, intro, contents, mainPic, clickNum, state,
				isTop, isDiscuss, isPic, numPic, numDiscuss, createUserId,
				createUserName, createDate, updateUserId, updateUserName,
				updateDate);
	}

}
