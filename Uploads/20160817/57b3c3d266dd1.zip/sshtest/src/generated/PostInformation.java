package dao.generated;

import java.sql.Timestamp;

/**
 * PostInformation entity. @author MyEclipse Persistence Tools
 */

public class PostInformation implements java.io.Serializable {

	// Fields

	private Integer id;
	private String postId;
	private Integer type;
	private String title;
	private String textContent;
	private String projectId;
	private Timestamp publishTime;
	private String publishUser;
	private String publishIp;
	private String publishAdd;
	private String publishSource;
	private String informationId;
	private String url;
	private Integer replies;
	private Integer clicks;
	private Integer transmit;
	private Timestamp getTime;
	private String checkState;
	private Integer fristReader;
	private Integer lastReader;
	private Integer level;
	private Integer hot;

	// Constructors

	/** default constructor */
	public PostInformation() {
	}

	/** minimal constructor */
	public PostInformation(String postId, Integer type, String title,
			String textContent, String projectId, Timestamp publishTime,
			String publishSource, String informationId, String url,
			Timestamp getTime) {
		this.postId = postId;
		this.type = type;
		this.title = title;
		this.textContent = textContent;
		this.projectId = projectId;
		this.publishTime = publishTime;
		this.publishSource = publishSource;
		this.informationId = informationId;
		this.url = url;
		this.getTime = getTime;
	}

	/** full constructor */
	public PostInformation(String postId, Integer type, String title,
			String textContent, String projectId, Timestamp publishTime,
			String publishUser, String publishIp, String publishAdd,
			String publishSource, String informationId, String url,
			Integer replies, Integer clicks, Integer transmit,
			Timestamp getTime, String checkState, Integer fristReader,
			Integer lastReader, Integer level, Integer hot) {
		this.postId = postId;
		this.type = type;
		this.title = title;
		this.textContent = textContent;
		this.projectId = projectId;
		this.publishTime = publishTime;
		this.publishUser = publishUser;
		this.publishIp = publishIp;
		this.publishAdd = publishAdd;
		this.publishSource = publishSource;
		this.informationId = informationId;
		this.url = url;
		this.replies = replies;
		this.clicks = clicks;
		this.transmit = transmit;
		this.getTime = getTime;
		this.checkState = checkState;
		this.fristReader = fristReader;
		this.lastReader = lastReader;
		this.level = level;
		this.hot = hot;
	}

	// Property accessors

	public Integer getId() {
		return this.id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getPostId() {
		return this.postId;
	}

	public void setPostId(String postId) {
		this.postId = postId;
	}

	public Integer getType() {
		return this.type;
	}

	public void setType(Integer type) {
		this.type = type;
	}

	public String getTitle() {
		return this.title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getTextContent() {
		return this.textContent;
	}

	public void setTextContent(String textContent) {
		this.textContent = textContent;
	}

	public String getProjectId() {
		return this.projectId;
	}

	public void setProjectId(String projectId) {
		this.projectId = projectId;
	}

	public Timestamp getPublishTime() {
		return this.publishTime;
	}

	public void setPublishTime(Timestamp publishTime) {
		this.publishTime = publishTime;
	}

	public String getPublishUser() {
		return this.publishUser;
	}

	public void setPublishUser(String publishUser) {
		this.publishUser = publishUser;
	}

	public String getPublishIp() {
		return this.publishIp;
	}

	public void setPublishIp(String publishIp) {
		this.publishIp = publishIp;
	}

	public String getPublishAdd() {
		return this.publishAdd;
	}

	public void setPublishAdd(String publishAdd) {
		this.publishAdd = publishAdd;
	}

	public String getPublishSource() {
		return this.publishSource;
	}

	public void setPublishSource(String publishSource) {
		this.publishSource = publishSource;
	}

	public String getInformationId() {
		return this.informationId;
	}

	public void setInformationId(String informationId) {
		this.informationId = informationId;
	}

	public String getUrl() {
		return this.url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public Integer getReplies() {
		return this.replies;
	}

	public void setReplies(Integer replies) {
		this.replies = replies;
	}

	public Integer getClicks() {
		return this.clicks;
	}

	public void setClicks(Integer clicks) {
		this.clicks = clicks;
	}

	public Integer getTransmit() {
		return this.transmit;
	}

	public void setTransmit(Integer transmit) {
		this.transmit = transmit;
	}

	public Timestamp getGetTime() {
		return this.getTime;
	}

	public void setGetTime(Timestamp getTime) {
		this.getTime = getTime;
	}

	public String getCheckState() {
		return this.checkState;
	}

	public void setCheckState(String checkState) {
		this.checkState = checkState;
	}

	public Integer getFristReader() {
		return this.fristReader;
	}

	public void setFristReader(Integer fristReader) {
		this.fristReader = fristReader;
	}

	public Integer getLastReader() {
		return this.lastReader;
	}

	public void setLastReader(Integer lastReader) {
		this.lastReader = lastReader;
	}

	public Integer getLevel() {
		return this.level;
	}

	public void setLevel(Integer level) {
		this.level = level;
	}

	public Integer getHot() {
		return this.hot;
	}

	public void setHot(Integer hot) {
		this.hot = hot;
	}

}