package dao.generated;

import java.sql.Timestamp;


/**
 * Information entity. @author MyEclipse Persistence Tools
 */

public class Information  implements java.io.Serializable {


    // Fields    

     private String id;
     private String url;
     private String title;
     private String texttitle;
     private String textAddress;
     private String websiteAddress;
     private String textContent;
     private Timestamp refreshTime;
     private Integer isCheck;
     private String checkSubmit;
     private Timestamp submissionTime;
     private String reprintCount;
     private String participateCount;
     private String commentCount;
     private String threadCount;
     private String browseCount;
     private String sitename;
     private String projectId;
     private Timestamp publishTime;
     private Timestamp getTime;


    // Constructors

    /** default constructor */
     
     
    public Information() {
    }

	/** minimal constructor */
    public Information(String id) {
        this.id = id;
    }
    
    /** full constructor */
    public Information(String id, String url, String title, String texttitle, String textAddress, String websiteAddress, String textContent, Timestamp refreshTime, Integer isCheck, String checkSubmit, Timestamp submissionTime, String reprintCount, String participateCount, String commentCount, String threadCount, String browseCount, String sitename, String projectId, Timestamp publishTime, Timestamp getTime) {
        this.id = id;
        this.url = url;
        this.title = title;
        this.texttitle = texttitle;
        this.textAddress = textAddress;
        this.websiteAddress = websiteAddress;
        this.textContent = textContent;
        this.refreshTime = refreshTime;
        this.isCheck = isCheck;
        this.checkSubmit = checkSubmit;
        this.submissionTime = submissionTime;
        this.reprintCount = reprintCount;
        this.participateCount = participateCount;
        this.commentCount = commentCount;
        this.threadCount = threadCount;
        this.browseCount = browseCount;
        this.sitename = sitename;
        this.projectId = projectId;
        this.publishTime = publishTime;
        this.getTime = getTime;
    }

   
    // Property accessors

    public String getId() {
        return this.id;
    }
    
    public void setId(String id) {
        this.id = id;
    }

    public String getUrl() {
        return this.url;
    }
    
    public void setUrl(String url) {
        this.url = url;
    }

    public String getTitle() {
        return this.title;
    }
    
    public void setTitle(String title) {
        this.title = title;
    }

    public String getTexttitle() {
        return this.texttitle;
    }
    
    public void setTexttitle(String texttitle) {
        this.texttitle = texttitle;
    }

    public String getTextAddress() {
        return this.textAddress;
    }
    
    public void setTextAddress(String textAddress) {
        this.textAddress = textAddress;
    }

    public String getWebsiteAddress() {
        return this.websiteAddress;
    }
    
    public void setWebsiteAddress(String websiteAddress) {
        this.websiteAddress = websiteAddress;
    }

    public String getTextContent() {
        return this.textContent;
    }
    
    public void setTextContent(String textContent) {
        this.textContent = textContent;
    }

    public Timestamp getRefreshTime() {
        return this.refreshTime;
    }
    
    public void setRefreshTime(Timestamp refreshTime) {
        this.refreshTime = refreshTime;
    }

    public Integer getIsCheck() {
        return this.isCheck;
    }
    
    public void setIsCheck(Integer isCheck) {
        this.isCheck = isCheck;
    }

    public String getCheckSubmit() {
        return this.checkSubmit;
    }
    
    public void setCheckSubmit(String checkSubmit) {
        this.checkSubmit = checkSubmit;
    }

    public Timestamp getSubmissionTime() {
        return this.submissionTime;
    }
    
    public void setSubmissionTime(Timestamp submissionTime) {
        this.submissionTime = submissionTime;
    }

    public String getReprintCount() {
        return this.reprintCount;
    }
    
    public void setReprintCount(String reprintCount) {
        this.reprintCount = reprintCount;
    }

    public String getParticipateCount() {
        return this.participateCount;
    }
    
    public void setParticipateCount(String participateCount) {
        this.participateCount = participateCount;
    }

    public String getCommentCount() {
        return this.commentCount;
    }
    
    public void setCommentCount(String commentCount) {
        this.commentCount = commentCount;
    }

    public String getThreadCount() {
        return this.threadCount;
    }
    
    public void setThreadCount(String threadCount) {
        this.threadCount = threadCount;
    }

    public String getBrowseCount() {
        return this.browseCount;
    }
    
    public void setBrowseCount(String browseCount) {
        this.browseCount = browseCount;
    }

    public String getSitename() {
        return this.sitename;
    }
    
    public void setSitename(String sitename) {
        this.sitename = sitename;
    }

    public String getProjectId() {
        return this.projectId;
    }
    
    public void setProjectId(String projectId) {
        this.projectId = projectId;
    }

    public Timestamp getPublishTime() {
        return this.publishTime;
    }
    
    public void setPublishTime(Timestamp publishTime) {
        this.publishTime = publishTime;
    }

    public Timestamp getGetTime() {
        return this.getTime;
    }
    
    public void setGetTime(Timestamp getTime) {
        this.getTime = getTime;
    }
   








}