package dao.generated;

import java.sql.Timestamp;

/**
 * AbstractTsNews entity provides the base persistence definition of the TsNews
 * entity. @author MyEclipse Persistence Tools
 */

public abstract class AbstractTsNews implements java.io.Serializable {

	// Fields

	private String newsId;
	private String typeId;
	private String newsTitle;
	private String intro;
	private String contents;
	private String mainPic;
	private Integer clickNum;
	private String state;
	private Boolean isTop;
	private Boolean isDiscuss;
	private Boolean isPic;
	private Integer numPic;
	private Integer numDiscuss;
	private String createUserId;
	private String createUserName;
	private Timestamp createDate;
	private String updateUserId;
	private String updateUserName;
	private Timestamp updateDate;

	// Constructors

	/** default constructor */
	public AbstractTsNews() {
	}

	/** minimal constructor */
	public AbstractTsNews(String typeId, String newsTitle, String state,
			Boolean isTop, Boolean isDiscuss, Boolean isPic, Integer numPic,
			Integer numDiscuss, String createUserId, String createUserName,
			Timestamp createDate) {
		this.typeId = typeId;
		this.newsTitle = newsTitle;
		this.state = state;
		this.isTop = isTop;
		this.isDiscuss = isDiscuss;
		this.isPic = isPic;
		this.numPic = numPic;
		this.numDiscuss = numDiscuss;
		this.createUserId = createUserId;
		this.createUserName = createUserName;
		this.createDate = createDate;
	}

	/** full constructor */
	public AbstractTsNews(String typeId, String newsTitle, String intro,
			String contents, String mainPic, Integer clickNum, String state,
			Boolean isTop, Boolean isDiscuss, Boolean isPic, Integer numPic,
			Integer numDiscuss, String createUserId, String createUserName,
			Timestamp createDate, String updateUserId, String updateUserName,
			Timestamp updateDate) {
		this.typeId = typeId;
		this.newsTitle = newsTitle;
		this.intro = intro;
		this.contents = contents;
		this.mainPic = mainPic;
		this.clickNum = clickNum;
		this.state = state;
		this.isTop = isTop;
		this.isDiscuss = isDiscuss;
		this.isPic = isPic;
		this.numPic = numPic;
		this.numDiscuss = numDiscuss;
		this.createUserId = createUserId;
		this.createUserName = createUserName;
		this.createDate = createDate;
		this.updateUserId = updateUserId;
		this.updateUserName = updateUserName;
		this.updateDate = updateDate;
	}

	// Property accessors

	public String getNewsId() {
		return this.newsId;
	}

	public void setNewsId(String newsId) {
		this.newsId = newsId;
	}

	public String getTypeId() {
		return this.typeId;
	}

	public void setTypeId(String typeId) {
		this.typeId = typeId;
	}

	public String getNewsTitle() {
		return this.newsTitle;
	}

	public void setNewsTitle(String newsTitle) {
		this.newsTitle = newsTitle;
	}

	public String getIntro() {
		return this.intro;
	}

	public void setIntro(String intro) {
		this.intro = intro;
	}

	public String getContents() {
		return this.contents;
	}

	public void setContents(String contents) {
		this.contents = contents;
	}

	public String getMainPic() {
		return this.mainPic;
	}

	public void setMainPic(String mainPic) {
		this.mainPic = mainPic;
	}

	public Integer getClickNum() {
		return this.clickNum;
	}

	public void setClickNum(Integer clickNum) {
		this.clickNum = clickNum;
	}

	public String getState() {
		return this.state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public Boolean getIsTop() {
		return this.isTop;
	}

	public void setIsTop(Boolean isTop) {
		this.isTop = isTop;
	}

	public Boolean getIsDiscuss() {
		return this.isDiscuss;
	}

	public void setIsDiscuss(Boolean isDiscuss) {
		this.isDiscuss = isDiscuss;
	}

	public Boolean getIsPic() {
		return this.isPic;
	}

	public void setIsPic(Boolean isPic) {
		this.isPic = isPic;
	}

	public Integer getNumPic() {
		return this.numPic;
	}

	public void setNumPic(Integer numPic) {
		this.numPic = numPic;
	}

	public Integer getNumDiscuss() {
		return this.numDiscuss;
	}

	public void setNumDiscuss(Integer numDiscuss) {
		this.numDiscuss = numDiscuss;
	}

	public String getCreateUserId() {
		return this.createUserId;
	}

	public void setCreateUserId(String createUserId) {
		this.createUserId = createUserId;
	}

	public String getCreateUserName() {
		return this.createUserName;
	}

	public void setCreateUserName(String createUserName) {
		this.createUserName = createUserName;
	}

	public Timestamp getCreateDate() {
		return this.createDate;
	}

	public void setCreateDate(Timestamp createDate) {
		this.createDate = createDate;
	}

	public String getUpdateUserId() {
		return this.updateUserId;
	}

	public void setUpdateUserId(String updateUserId) {
		this.updateUserId = updateUserId;
	}

	public String getUpdateUserName() {
		return this.updateUserName;
	}

	public void setUpdateUserName(String updateUserName) {
		this.updateUserName = updateUserName;
	}

	public Timestamp getUpdateDate() {
		return this.updateDate;
	}

	public void setUpdateDate(Timestamp updateDate) {
		this.updateDate = updateDate;
	}

}