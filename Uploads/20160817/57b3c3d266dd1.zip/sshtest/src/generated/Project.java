package dao.generated;

import java.sql.Timestamp;

/**
 * Project entity. @author MyEclipse Persistence Tools
 */

public class Project implements java.io.Serializable {

	// Fields

	private String id;
	private String projectName;
	private String projectFather;
	private String conditionalExpression;
	private Timestamp creationTime;
	private String creatorId;
	private Integer limitedWebSite;

	// Constructors

	/** default constructor */
	public Project() {
	}

	/** full constructor */
	public Project(String projectName, String projectFather,
			String conditionalExpression, Timestamp creationTime,
			String creatorId, Integer limitedWebSite) {
		this.projectName = projectName;
		this.projectFather = projectFather;
		this.conditionalExpression = conditionalExpression;
		this.creationTime = creationTime;
		this.creatorId = creatorId;
		this.limitedWebSite = limitedWebSite;
	}

	// Property accessors

	public String getId() {
		return this.id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getProjectName() {
		return this.projectName;
	}

	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}

	public String getConditionalExpression() {
		return this.conditionalExpression;
	}

	public void setConditionalExpression(String conditionalExpression) {
		this.conditionalExpression = conditionalExpression;
	}

	public Timestamp getCreationTime() {
		return this.creationTime;
	}

	public void setCreationTime(Timestamp creationTime) {
		this.creationTime = creationTime;
	}

	public String getCreatorId() {
		return this.creatorId;
	}

	public void setCreatorId(String creatorId) {
		this.creatorId = creatorId;
	}

	public Integer getLimitedWebSite() {
		return this.limitedWebSite;
	}

	public void setLimitedWebSite(Integer limitedWebSite) {
		this.limitedWebSite = limitedWebSite;
	}

	public String getProjectFather() {
		return projectFather;
	}

	public void setProjectFather(String projectFather) {
		this.projectFather = projectFather;
	}

}