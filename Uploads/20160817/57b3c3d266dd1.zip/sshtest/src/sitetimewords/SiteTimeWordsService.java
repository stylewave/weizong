package service.sitetimewords;

import common.service.BaseService;
import dao.generated.SiteTimeWords;
public interface SiteTimeWordsService extends BaseService<SiteTimeWords> {

}