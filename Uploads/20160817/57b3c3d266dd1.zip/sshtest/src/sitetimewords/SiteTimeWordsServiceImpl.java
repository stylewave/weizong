package service.sitetimewords;

import javax.annotation.Resource;

import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Order;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import common.action.PaginationSupport;
import common.dao.IBaseDAO;
import common.service.AbstractService;
import dao.generated.SiteTimeWords;
import dao.sitetimewords.ISiteTimeWordsDAO;

@Service("SiteTimeWordsService")
public class SiteTimeWordsServiceImpl extends AbstractService<SiteTimeWords> implements	SiteTimeWordsService {
	
	@Autowired
	private ISiteTimeWordsDAO SiteTimeWordsDAO;

	@Override
	@Resource(name = "sitetimewordsDAO")
	protected void initBaseDAO(IBaseDAO<SiteTimeWords> baseDAO) {
		setBaseDAO(baseDAO);
	}

	@Override
	public PaginationSupport<SiteTimeWords> findPageByCriteria(
			PaginationSupport<SiteTimeWords> ps, SiteTimeWords t) {
		DetachedCriteria dc = DetachedCriteria.forClass(SiteTimeWords.class);
		return SiteTimeWordsDAO.findPageByCriteria(ps, Order.asc("id"), dc);
	}

	@Override
	public void save(SiteTimeWords t) {
		SiteTimeWordsDAO.save(t);
	}
}