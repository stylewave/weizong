package dao.sitetimewords;

import org.springframework.stereotype.Repository;

import common.dao.AbstractQueryDAO;
import dao.generated.SiteTimeWords;

@Repository("sitetimewordsDAO")
public class SiteTimeWordsExtendDAO extends AbstractQueryDAO<SiteTimeWords> implements ISiteTimeWordsDAO {
		

}