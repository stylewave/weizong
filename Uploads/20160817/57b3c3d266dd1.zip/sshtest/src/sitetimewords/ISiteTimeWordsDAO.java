package dao.sitetimewords;

import common.dao.IBaseDAO;
import dao.generated.SiteTimeWords;
public interface ISiteTimeWordsDAO extends IBaseDAO<SiteTimeWords> {

}