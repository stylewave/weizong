package service.managers;

import common.service.BaseService;
import dao.generated.Managers;

public interface ManagersService extends BaseService<Managers> {

}