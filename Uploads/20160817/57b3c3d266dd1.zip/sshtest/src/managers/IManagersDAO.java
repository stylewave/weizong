package dao.managers;
/**
 * Managers entity. @author MyEclipse Persistence Tools
 */
import common.dao.IBaseDAO;
import dao.generated.Managers;

public interface IManagersDAO extends IBaseDAO<Managers> {
}