package dao.managers;
import java.sql.SQLException;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.springframework.orm.hibernate3.HibernateCallback;
import org.springframework.stereotype.Repository;
import common.dao.AbstractQueryDAO;
import dao.generated.Managers;

@Repository("ManagersDAO")
public class ManagersExtendDAO extends AbstractQueryDAO<Managers> implements IManagersDAO {

}