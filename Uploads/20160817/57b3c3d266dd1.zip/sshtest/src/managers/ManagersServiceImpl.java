package service.managers;

import javax.annotation.Resource;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Order;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import common.action.PaginationSupport;
import common.dao.IBaseDAO;
import common.service.AbstractService;
import dao.generated.Managers;
import dao.managers.IManagersDAO;

@Service("ManagersService")
public class ManagersServiceImpl extends AbstractService<Managers> implements ManagersService {
		
	@Autowired
	private IManagersDAO ManagersDAO;

	@Override
	@Resource(name = "ManagersDAO")
	protected void initBaseDAO(IBaseDAO<Managers> baseDAO) {
		setBaseDAO(baseDAO);
	}
	@Override
	public PaginationSupport<Managers> findPageByCriteria(PaginationSupport<Managers> ps, Managers t) {
			
		DetachedCriteria dc = DetachedCriteria.forClass(Managers.class);
		return ManagersDAO.findPageByCriteria(ps, Order.asc("id"), dc);
	}
	@Override
	public void save(Managers t) {
		ManagersDAO.save(t);
	}
}