package common;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.URL;
import java.util.Properties;

public class Configuration {
	private static Properties propertie;
	private static FileInputStream inputFile;

	/** */
	/**
	 * 初始化Configuration类
	 * 
	 * @param filePath
	 *            要读取的配置文件的路径+名称
	 */
	private Configuration() {
	}

	/** */
	/**
	 * 重载函数，得到key的值
	 * 
	 * @param key
	 *            取得其值的键
	 * @return key的值
	 * @throws FileNotFoundException
	 */
	public static String getValue(String key) {
		if (propertie == null) {
			propertie = new Properties();
		}
		try {
			URL url = Thread.currentThread().getContextClassLoader()
					.getResource("config.properties");
			inputFile = new FileInputStream(url.getFile());
			System.out.println("common.search.getPage:"+inputFile); //++
		} catch (Exception ex) {
			try {
				inputFile = new FileInputStream(
						"../webapps/WebSearch/WEB-INF/classes/config.properties");
				System.out.println("common.search.getPage:"+inputFile); //++
			} catch (FileNotFoundException e) {
				System.out.println("读取属性文件--->失败！- 原因：文件路径错误或者文件不存在");
				ex.printStackTrace();
				e.printStackTrace();
			}
		}
		try {
			propertie.load(inputFile);
			inputFile.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
		if (propertie.containsKey(key)) {
			String value = propertie.getProperty(key);// 得到某一属性的值
			return value;
		} else
			return "";
	}
}