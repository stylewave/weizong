package dao.tabInformationSource;

import org.springframework.stereotype.Repository;
import common.dao.AbstractQueryDAO;
import dao.generated.TabInformationSource;

@Repository("tabInformationSourceDAO")
public class TabInformationSourceExtendDAO extends
		AbstractQueryDAO<TabInformationSource> implements
		ITabInformationSourceDAO {

}