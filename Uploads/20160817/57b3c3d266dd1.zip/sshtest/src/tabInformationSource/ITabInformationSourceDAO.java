package dao.tabInformationSource;

import common.dao.IBaseDAO;
import dao.generated.TabInformationSource;

public interface ITabInformationSourceDAO extends
		IBaseDAO<TabInformationSource> {

}