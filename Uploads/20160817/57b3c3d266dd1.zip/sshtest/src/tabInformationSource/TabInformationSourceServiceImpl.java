package service.tabInformationSource;

import javax.annotation.Resource;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Order;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import common.action.PaginationSupport;
import common.dao.IBaseDAO;
import common.service.AbstractService;
import dao.generated.TabInformationSource;
import dao.tabInformationSource.ITabInformationSourceDAO;

@Service("tabInformationSourceService")
public class TabInformationSourceServiceImpl extends
		AbstractService<TabInformationSource> implements
		TabInformationSourceService {
	@Autowired
	private ITabInformationSourceDAO tabInformationSourceDAO;

	@Override
	@Resource(name = "tabInformationSourceDAO")
	protected void initBaseDAO(IBaseDAO<TabInformationSource> baseDAO) {
		setBaseDAO(baseDAO);
	}

	@Override
	public PaginationSupport<TabInformationSource> findPageByCriteria(
			PaginationSupport<TabInformationSource> ps, TabInformationSource t) {
		DetachedCriteria dc = DetachedCriteria
				.forClass(TabInformationSource.class);
		return tabInformationSourceDAO.findPageByCriteria(ps,
				Order.asc("tabInformationSourceId"), dc);
	}

	@Override
	public void save(TabInformationSource t) {
		tabInformationSourceDAO.save(t);
	}
}