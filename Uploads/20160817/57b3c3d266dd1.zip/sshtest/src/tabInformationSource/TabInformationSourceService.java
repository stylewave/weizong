package service.tabInformationSource;

import common.service.BaseService;
import dao.generated.TabInformationSource;

public interface TabInformationSourceService extends BaseService<TabInformationSource> {	

}