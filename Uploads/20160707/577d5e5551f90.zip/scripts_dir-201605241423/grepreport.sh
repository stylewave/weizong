cat /tmp/arachni_cmd| awk -F" " '{print }' 
for i in `cat /tmp/arachni_cmd`
do
echo $i
done
