URL=$1
PLUGIN=$2
CHECKS=$3
REPORT=$4


CMD="arachni $URL --plugin=$PLUGIN --scope-page-limit=0 --scope-exclude-pattern=logout --checks=$CHECKS --report-save-path=$REPORT"

while true
do
{
if [ $# -ne 4 ];
	then 
	echo "\033[31mParameter is empty or parameter is not 4! \033[0m"
	echo "Please enter the four parameter format for \033[31mURL PLUGIN CHECKS REPORT\033[0m."
	break
fi

	echo $CMD 
	arachni $URL --plugin=$PLUGIN --scope-page-limit=0 --scope-exclude-pattern=logout --checks=$CHECKS --report-save-path=$REPORT > /tmp/arachnirun.log 2>&1 &	

#if [ $? -ne 0 ];
#	then
#	echo "\033[31mParameter Error! \033[0m"
#	echo "Please enter the four parameter format for \033[31mURL PLUGIN CHECKS REPORT\033[0m."
#	break
#fi
	
	sleep 5s

	arpid=`ps -ef|grep arachni|grep $REPORT|sort -n -k5|awk '{print $2}'`
	
	if grep -a "Proxy: Listening on: http://0.0.0.0:8282" /tmp/arachnirun.log ;
		then
		echo  "\033[31mrunning successful! \033[0m"
		break
	else
		kill -s 9 `ps -ef|grep arachni|grep $REPORT|sort -n -k5|awk '{print $2}'` 2>&1
		
	fi

}
done
