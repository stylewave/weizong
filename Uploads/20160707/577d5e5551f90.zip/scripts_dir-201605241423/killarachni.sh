#!/bin/bash

REPORT=$1
ps -ef|grep arachni|grep $REPORT|sort -n -k5|awk '{print $2}' > /tmp/arpidlist
for ids in $(cat /tmp/arpidlist)
do
kill -s 9 $ids > /dev/null 2>&1
done
