#!/bin/bash
CMD="$@"
echo "$@" > /tmp/arachni_cmd


while true
do
{
if [ $# -le 3 ];
	then 
	echo "\033[31mParameter is empty or parameter is < 4! \033[0m"
	echo "Please enter >= 4 parameter format for \033[31mURL PLUGIN CHECKS REPORT\033[0m ..."
	break
#elif [[ "${NO4_REPORT:0:18}" != "--report-save-path" ]];
#echo ${NO4_REPORT:0:18}
#       then
#       echo "No.4 parameter must is '--report-save-path=***'"
#       break
fi

#	echo $CMD 
	arachni --scope-page-limit=0 --scope-exclude-pattern=logout $@ > /tmp/arachnirun.log 2>&1 &	
REPORT=`sh grepreport.sh|sed -n 5p |awk -F'=' '{print $2}'|sed -n 1p`

#if [ $? -ne 0 ];
#	then
#	echo "\033[31mParameter Error! \033[0m"
#	echo "Please enter the four parameter format for \033[31mURL PLUGIN CHECKS REPORT\033[0m."
#	break
#fi
	
	sleep 5s

#	arpid=`ps -ef|grep arachni|grep $REPORT|sort -n -k5|awk '{print $2}'`
arpid=`pidof ruby|awk {'print $1'}`
	
	if grep -a "Proxy: Listening on: http://0.0.0.0:8282" /tmp/arachnirun.log ;
		then
		echo  "\033[31mrunning successful! \033[0m"
		break
	else
#		kill -s 9 `ps -ef|grep arachni|grep $REPORT|sort -n -k5|awk '{print $2}'` 2>&1
		kill -s 9 $arpid
		
	fi

}
done
