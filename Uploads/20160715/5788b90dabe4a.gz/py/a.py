#!/usr/bin/python
#Author: wugengxing

import MySQLdb


conn=MySQLdb.connect(host="127.0.0.1",user="root",passwd="86itsec.",db="appcheckdb")
cur=conn.cursor()


AppIdlist = [ ] 
cur.execute("select appid,realname from at_apppiracy where status = 0;")


for row in cur.fetchall():      
	appid = str(row[0])
	realname = str(row[1])

	cur.execute("select AppName,count(*) from project where AppName = '%s';" %(realname))
	for row in cur.fetchall():
		result = row[1]
		project_AppName = row[0]	
		if project_AppName  == realname:
			AppIdlist.insert(1,appid)
#print AppIdlist

if  result == 0 :
	print '0'
else:
	print '1'
cur.close()
conn.commit()
conn.close()

