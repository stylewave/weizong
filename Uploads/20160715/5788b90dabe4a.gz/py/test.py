#!/usr/bin/python
#Author: wugengxing

import MySQLdb

AppIdlist = [ ] 

conn=MySQLdb.connect(host="127.0.0.1",user="root",passwd="86itsec.",db="appcheckdb")
cur=conn.cursor()
selectsql="select appid,realname from at_apppiracy where status = 0;"
n1=cur.execute(selectsql)


for row in cur.fetchall():      
	appid = str(row[0])
	realname = str(row[1])

	cur.execute("select AppName from project where AppName = '%s';" %(realname))
	for row in cur.fetchall():
		result = cur.fetchall()
		project_AppName = row[0]	
		if project_AppName  == realname:
			AppIdlist.insert(1,appid)
#print AppIdlist

if result == None:
	cur.execute("insert into project (`isTask`, `AppIdlist`, `AppName`) values ('1', \"%s\", '%s');" %(AppIdlist,project_AppName))
else:
	cur.execute("update project set AppIdlist=\"%s\",isTask=1 where AppName = '%s';" %(AppIdlist,project_AppName))

cur.close()
conn.commit()
conn.close()

