#!/usr/bin/python
#Author: wugengxing

import os
import MySQLdb
import requests

conn=MySQLdb.connect(host="127.0.0.1",user="root",passwd="86itsec.",db="appcheckdb")
cur=conn.cursor()
cur.execute("")

cur.close()
conn.commit()
conn.close()

