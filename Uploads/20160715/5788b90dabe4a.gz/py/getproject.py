#!/usr/bin/python

import os
import MySQLdb
import requests

conn=MySQLdb.connect(host="127.0.0.1",user="root",passwd="86itsec.",db="appcheckdb")
cur=conn.cursor()
n1=cur.execute("select realname,appid from at_apppiracy where status = 0;")

for row in cur.fetchall():
        realname=str(row[0])
        appid=str(row[1])
	n2=cur.execute("select AppName from project;")
	for row in cur.fetchall():
	        AppName=str(row[0])
		print AppName

cur.close()
conn.commit()
conn.close()
