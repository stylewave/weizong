#!/usr/bin/python
#Author: wugengxing

import os
import MySQLdb
import Image
import requests
from itertools import izip

conn=MySQLdb.connect(host="127.0.0.1",user="root",passwd="86itsec.",db="appcheckdb")
cur=conn.cursor()
selectsql="select url from information where isCheck=1;"
n1=cur.execute(selectsql)

apk_dir='yuqingtmp'
save_apk='yuqingtmp.apk'
for row in cur.fetchall():      
	#get apk
	url=str(row[0])
	r = requests.get(url)
	with open("%s" %(save_apk), "wb") as code:
	     	code.write(r.content)
	cur.execute("update information set isCheck=0 where url='%s';" %(url))
	
	#get filemd5	
	os.system("md5sum %s > /tmp/md5sum_apk_all" %(save_apk))
	os.system("cat /tmp/md5sum_apk_all |awk  -F ' ' '{print $1}' >/tmp/md5sum_apk")
	md5file = open("/tmp/md5sum_apk")
        comMD5 = md5file.read()
	#cur.execute("update information set appMd5='%s' where url='%s';" %(comMD5,url))
	
	#get logo
	os.system("aapt d badging %s |grep -E 'application:'|awk -F ' ' '{print $3}'|awk -F '=' '{print $2}' | awk -F \"'\" '{print $2}' > /tmp/logo_apk" %(save_apk))
	os.system("unzip -o %s -d /tmp/%s > /dev/null" %(save_apk,apk_dir))
	logofile = open("/tmp/logo_apk")
        logopath = logofile.read().strip()

	#get comcertMD5
	os.system("keytool -printcert -file `find /tmp/%s -name *.RSA`  | grep -oP \"(?<=MD5:)[^']+\"| sed 's/\://g' |sed 's/^[ \t]*//g' > /tmp/certmd5" %(apk_dir))
	certmd5file = open("/tmp/certmd5")
	comcertMD5 = certmd5file.read().strip()
	#cur.execute("update information set certMd5='%s' where url='%s';" %(comcertMD5,url))

	#get compackage
	os.system("aapt d badging %s|head -1| awk  '{print $2}'|awk -F \"'\" '{print $2}' > /tmp/packagename" %(save_apk))
	packagenamefile = open("/tmp/packagename")
	compackage = packagenamefile.read().strip()

	#get comversion
	os.system("aapt d badging %s|head -1| awk  '{print $4}'|awk -F \"'\" '{print $2}' > /tmp/apkversion" %(save_apk))
	apkversionfile = open("/tmp/apkversion")
	comversion = apkversionfile.read().strip()
	
	#comchannel
	cur.execute("select comchannel from information where url='%s';" %(url))
	for row in cur.fetchall():
        	comchannel = str(row[0])

	#comrealname
	os.system("aapt d badging %s |grep 'application-label:'|awk -F \"'\" '{print $2}' > /tmp/comrealname" %(save_apk))
	comrealnamefile = open("/tmp/comrealname")
	comrealname = comrealnamefile.read().strip()

	#logo compare
	def getGray(image_file):
	   tmpls=[]
	   for h in range(0,  image_file.size[1]):
		for w in range(0, image_file.size[0]):
        	 tmpls.append( image_file.getpixel((w,h))  )
	   return tmpls
 
	def getAvg(ls):
	   return sum(ls)/len(ls)
 
	def getMH(a,b):
	   dist = 0;
	   for i in range(0,len(a)):
	      if a[i]==b[i]:
        	 dist=dist+1
	   return dist
 
	def getImgHash(fne):
	   image_file = Image.open(fne)
	   image_file=image_file.resize((12, 12))
	   image_file=image_file.convert("L")
	   Grayls=getGray(image_file)
	   avg=getAvg(Grayls)
	   bitls=''
	   for h in range(1,  image_file.size[1]-1):
	      for w in range(1, image_file.size[0]-1):
        	 if image_file.getpixel((w,h))>=avg:
	            bitls=bitls+'1'
       		 else:
	            bitls=bitls+'0'
	   return bitls

	cur.execute("select package,certMD5,icon from at_apppiracy where status = 0")
	for row in cur.fetchall():
                package = str(row[0])
                certMD5 = str(row[1])
                icon = str(row[2])

		a=getImgHash("%s" %(icon))
		b=getImgHash("/tmp/%s/%s"  %(apk_dir,logopath))
		similarity=getMH(a,b)
		os.system("rm -rf /tmp/%s" %(apk_dir))

		if ( package == compackage and certMD5 == comcertMD5 ):
			result = 0  #(true)
		elif ( package == compackage and certMD5 != comcertMD5 ): 
			result = 1  #(false)
		elif ( package != compackage and similarity > 90 ):
			result = 1  #(false)
		elif ( package != compackage and similarity < 90 ):
			result = 2  #(other)
	
	cur.execute("INSERT INTO `at_apppiracinfo` ( `result`, `comchannel`, `comurl`, `compackage`, `comcertMD5`, `comrealname`, `similarity`, `comversion`, `comMD5`) VALUES ('%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s','%s');" %(result,comchannel,url,compackage,comcertMD5,comrealname,similarity,comversion,comMD5))
	
cur.close()
conn.commit()
conn.close()

